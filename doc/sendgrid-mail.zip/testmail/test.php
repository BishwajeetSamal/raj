<?php

sendmail_function('raj.parihar@reak.in','raj pariahr','one123','user');
function sendmail_function($usermail, $username, $password, $userType)
{
    $subject = "Welcome to MUL8R your Password";
    $mailStatus = sendmail($usermail, $username, $password, $subject, $userType);
    if ($mailStatus) {
        return 'mail send successfully';
    } else {
        return 'mail not to send';
    }
}

function sendmail($toEmail, $toName, $password, $subject,$userType)
{
    require_once('vendor/autoload.php');
    $appUrl ='www.testone.com';
    $fromEmail = 'no-replay@reak.in';
    $fromName = 'MUL8R-WEB-APP';

    // Send Email
    $email = new \SendGrid\Mail\Mail();
    $email->setFrom($fromEmail, $fromName);
    $email->setSubject($subject);
    $email->addTo($toEmail, $toName);

    $body = file_get_contents("function/email-register.html");
    $replaceParams = array(
        "{{name}}" => $toName,
        "{{appUrl}}" => $appUrl,
        "{{fromName}}" => $fromName,
        "{{toMail}}" => $toEmail,
        "{{password}}" => $password,
        "{{userType}}" => $userType,
    );
    $body = strtr($body, $replaceParams);
    $email->addContent(
        "text/html",
        $body
    );
    $sendgrid = new \SendGrid('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');
    try {
        $response = $sendgrid->send($email);
        // print_r($response);
        return true;
    } catch (Exception $e) {
        return false;
    }
}
