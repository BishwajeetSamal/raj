<?php
// print_r($_POST);
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if ($_GET['id'] != '') {
    $id = $_GET['id'];
    try {
      require_once "../config/config.php";
      $conn = initDB();
      // prepare and bind
      // $stmt = $db_mysqli->prepare("SELECT * FROM licence WHERE id = ?");
      $stmt = $conn->prepare("DELETE FROM `customer` WHERE `id` = ?");
      $stmt->bind_param("s", $id);
      if ($stmt->execute()) {
        $output = array('status' => 'success');
      } else {
        $output = array('status' => 'failure');
      }

      echo json_encode($output);
      // $page = $row['page'];
      // echo $page;
    } catch (\Throwable $th) {
      $output = array('status' => 'failure');
      echo json_encode($output);
    }
  }else{
    echo 'null';
  }
}
