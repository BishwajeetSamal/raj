<?php
// print_r($_POST);
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
// print_r($_POST);
// if ($_REQUEST['o']) {
try {
  require_once "../config/config.php";
  $conn = initDB();
  // prepare and bind
  // $stmt = $db_mysqli->prepare("SELECT * FROM licence WHERE id = ?");
  $stmt = $conn->prepare("SELECT * FROM `customer` WHERE `usertype` != 'admin'");
  // $stmt->bind_param("s", $id);
  $stmt->execute();
  $result = $stmt->get_result();
  $row = $result->fetch_all(MYSQLI_ASSOC);
  $output = array('status' => 'success', 'contents' => $row);
  echo json_encode($output);
  // $page = $row['page'];
  // echo $page;
} catch (\Throwable $th) {
  $output = array('status' => 'failure');
  echo json_encode($output);
}
    // }
  // }
