<?php
function sendmail($toEmail, $toName, $password, $subject,$userType)
{
    require_once('vendor/autoload.php');
    require_once('config/config.php');
    $mail = mail_data();
    $appUrl = AppUrl();
    $fromName = $mail['fromName'];
    $fromEmail = $mail['fromEmail'];
    // Send Email
    $email = new \SendGrid\Mail\Mail();
    $email->setFrom($fromEmail, $fromName);
    $email->setSubject($subject);
    $email->addTo($toEmail, $toName);

    $body = file_get_contents("function/email-register.html");
    $replaceParams = array(
        "{{name}}" => $toName,
        "{{appUrl}}" => $appUrl,
        "{{fromName}}" => $fromName,
        "{{toMail}}" => $toEmail,
        "{{password}}" => $password,
        "{{userType}}" => $userType,
    );
    $body = strtr($body, $replaceParams);
    $email->addContent(
        "text/html",
        $body
    );
    $sendgrid = new \SendGrid('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');
    try {
        $response = $sendgrid->send($email);
        // print_r($response);
        return true;
    } catch (Exception $e) {
        return false;
    }
}
