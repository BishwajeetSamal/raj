<?php
// print_r($_POST);
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

  if ($_REQUEST['id'] != '') {
    try {
      require_once "../config/config.php";
      $id = $_REQUEST['id'];
      $conn = initDB();
      $stmt = $conn->prepare("SELECT * FROM `userlicence` WHERE `userid` = ?");
      $stmt->bind_param("s", $id);
      $stmt->execute();
      $result = $stmt->get_result();
      $row = $result->fetch_all(MYSQLI_ASSOC);
      $timestamp = strtotime("now");
      $output = array('status' => 'success', 'contents' => $row, "timestamp" => $timestamp);
      echo json_encode($output);
      // $page = $row['page'];
      // echo $page;
    } catch (\Throwable $th) {
      // echo $th;
      $output = array('status' => 'failure');
      echo json_encode($output);
    }
  } else {
    $output = array('status' => 'failure');
    echo json_encode($output);
  }
}
