package router

import (
	"net/http"
	"reakgo/controllers"
	"reakgo/utility"
	"strings"
)

func Routes(w http.ResponseWriter, r *http.Request) {

	// Trailing slash is a pain in the ass so we just drop it
	route := strings.Trim(r.URL.Path, "/")
	switch route {

	case "", "index":
		utility.CheckACL(w, r, 0)
		controllers.Login(w, r)
	case "dashboard":
		utility.CheckACL(w, r, 1)
		controllers.Dashboard(w, r)
	case "signup":
		controllers.Signup(w, r)
	case "under_progress":
		controllers.UnderProgress(w, r)
	case "email_success":
		controllers.Email_sucess(w, r)
	case "signupAjax":
		controllers.SignupAjax(w, r)
	case "email_check":
		controllers.Check_email(w, r)
	case "forgot_password":
		controllers.ForgotPassword(w, r)
	case "change_password":
		controllers.ChangePassword(w, r)
	case "token_verify":
		controllers.VerifyEmail(w, r)
	case "inventory":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Inventory(w, r)
	case "inventory_timeline":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Inventory_timeline(w, r)
	case "inventory_price_update":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Inventory_update(w, r)
	case "roomType_list":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Room_list(w, r)
	case "get_rooms":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Get_rooms(w, r)
	case "room_type":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.AddRoomType(w, r)
	case "add_room_type":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.AddRoomTypeData(w, r)
	case "guest_list":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Guest_list(w, r)
	case "reservation_collect":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Reservation_collect(w, r)
	case "reservation_confirm":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Reservation_confirm(w, r)
	case "reservation_collect_ajax":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.AjaxforCollect(w, r)
	case "reservation_collect_saveData":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.SaveCollectDetails(w, r)
	case "reservation_guest":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.RenderReservation_guest(w, r)
	case "edit_guest":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.RenderEdit_guest(w, r)
	case "getedit_guest_ajax":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.GetEdit_guestAllData(w, r)
	case "reservation_invoice":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.RenderReservation_invoice(w, r)
	case "editable_invoice":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.RenderEditable_invoice(w, r)
	case "final_invoice_with_service":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.FinalInvoiceWithService(w, r)
	case "fetch_invoice_data":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.FetchInvoiceData(w, r)
	case "save_invoice_table":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.SaveInvoiceTable(w, r)
	case "delete_invoice_data":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.DeleteInvoiceTable(w, r)
	case "update_invoice_table":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.UpdateInvoiceTable(w, r)
	case "reservation_guest_ajax":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.AjaxSaveforGuest(w, r)
	case "update_guest_ajax_edit":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.UpdateEditGuestbyAjax(w, r)
	case "search_guest_ajax":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.AjaxSearchGuest(w, r)
	case "search_guest_ajax_byId":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.GuestDataById(w, r)
	case "reservation_guest_ajax_for_price":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.GetPriceDataInGuestPage(w, r)
	case "roomtape":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.RoomTape(w, r)
	case "roomtape_timeline":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.RoomTape_timeline(w, r)
	case "add_hotel":
		utility.CheckACL(w, r, 1)
		// utility.Check_hotelId(w, r)
		controllers.InsertHotelData(w, r)
	case "update_hotel":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.UpdateHotelData(w, r)
	case "edit_collect":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Edit_collect(w, r)
	case "error_server":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.ErrorServer(w, r)
	case "getedit_collect_data":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.GetEditCollectData(w, r)
	case "getedit_Roomscollect_data":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.AjaxforCollect(w, r)
	case "update_collect_saveData":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.UpdateCollectDetails(w, r)
	case "reservation_list":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.ShowReservations(w, r)
	case "all_reservations":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Get_allReservations(w, r)
	case "all_guest":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Get_allGuests(w, r)
	case "res_to_checkIn":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Get_ResTo_CheckIn(w, r)
	case "res_to_checkOut":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Get_ActiveReservations(w, r)
	case "saveTime":
		utility.CheckACL(w, r, 1)
		controllers.InsertTime(w, r)
	case "active_res":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Get_ActiveReservations(w, r)
	case "manage_activeRes":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.Manage_ActiveRes(w, r)
	case "addguest_only":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.InsertGuestOnly(w, r)
	case "guestdata_ajax":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.FetchGuestByGuestId(w, r)
	case "updateguest_only":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.UpdateGuestOnly(w, r)
	case "delete_guest_Only":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.DeleteGuestOnly(w, r)
	case "delete_reservation_throughId":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.DeleteReservationByID(w, r)
	case "show_roomType_edit":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.ShowRoomTypeEdit(w, r)
	case "update_room_type":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.UpdateRoomTypeData(w, r)
	case "fetchCountry_name":
		controllers.FetchCountry(w, r)
	case "fetchStates_name":
		controllers.FetchAllStates_name(w, r)
	case "fetchcity_name":
		controllers.FetchAllCities_name(w, r)
	case "settings":
		utility.CheckACL(w, r, 1)
		controllers.Settings(w, r)
	case "logout":
		utility.CheckACL(w, r, 1)
		controllers.Logout(w, r)
	case "checkLoginStatus":
		utility.CheckACL(w, r, 1)
		controllers.CheckLoginStatus(w, r)
	case "getdataUserSettings":
		utility.CheckACL(w, r, 1)
		controllers.GetdataUserSettings(w, r)
	case "setdataUserSettings":
		utility.CheckACL(w, r, 1)
		controllers.SetdataUserSettings(w, r)
	case "delete_room_throughId":
		utility.CheckACL(w, r, 1)
		utility.Check_hotelId(w, r)
		controllers.DeleteRooms(w, r)
	}
	
}
