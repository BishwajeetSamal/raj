package controllers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"strconv"
	"strings"
	"time"
	//"reflect"
)

func Dashboard(w http.ResponseWriter, r *http.Request) {
	id := fmt.Sprintf("%v", utility.SessionGet(r, "id"))
	firstName := fmt.Sprintf("%v", utility.SessionGet(r, "first_name"))
	data, _ := Db.hotels.FetchHotel(utility.ConvertToInt64(id))
	data.FirstName = firstName
	data = getDashboardData(r, data)
	utility.RenderTemplate(w, r, "dashboard", data)
}

func InsertHotelData(w http.ResponseWriter, r *http.Request) {
	if (r.Method) == "POST" {
		response := utility.AjaxResponse{
			Status: "failure",
			Data:   "Something went wrong, Please try again",
		}
		var hotel models.Hotels
		tx,
			err := utility.Db.Begin()
		if err != nil {
			log.Fatal(err)
		} else {
			err := r.ParseMultipartForm(10)
			if err != nil {
				log.Println(err)
			} else {
				id := fmt.Sprintf("%v", utility.SessionGet(r, "id"))

				hotel.User_id = utility.ConvertToInt64(id)
				hotel.Hotel_name = sql.NullString{
					String: r.FormValue("hotel_name"), Valid: r.FormValue("hotel_name") != ""}
				hotel.Primary_customer = sql.NullString{
					String: r.FormValue("primary_customer"), Valid: r.FormValue("primary_customer") != ""}
				hotel.Nearest_competitor = sql.NullString{
					String: r.FormValue("nearest_competitor"), Valid: r.FormValue("nearest_competitor") != ""}
				hotel.Years_in_operation = sql.NullInt64{
					Int64: utility.ConvertToInt64(r.FormValue("years_in_operation")), Valid: r.FormValue("years_in_operation") != ""}
				hotel.Hotel_rating = sql.NullInt64{
					Int64: utility.ConvertToInt64(r.FormValue("hotel_rating")), Valid: r.FormValue("hotel_rating") != ""}
				hotel.HotelsUniqueId = sql.NullString{
					String: r.FormValue("hotel_unique_id"), Valid: r.FormValue("hotel_unique_id") != ""}
				hotel.Status = 1
				high_traffic_months := r.FormValue("high_traffic_months")

				if r.FormValue("hotel_unique_id") == "" || r.FormValue("hotel_name") == "" || r.FormValue("primary_customer") == "" || r.FormValue("nearest_competitor") == "" || r.FormValue("years_in_operation") == "" || r.FormValue("hotel_rating") == "" || len(high_traffic_months) == 0 {
					hotel.Status = 0
				}
				hotel_id, _ := Db.hotels.InsertHotel(tx, hotel)

				if hotel_id != 0 {
					HighTrafficMonthInserted := true
					if len(high_traffic_months) > 0 {
						HighTrafficMonthInserted = InserHighTrafficMonthData(tx, high_traffic_months, hotel_id)

					}

					if HighTrafficMonthInserted {
						insertToAuth := Db.hotels.UpdateHotelIdtoAuth(tx, hotel.User_id, hotel_id)
						hotelIdToSession := strconv.Itoa(int(hotel_id))
						if insertToAuth {
							sessionData := []utility.Session{
								{Key: "hotel_id", Value: hotelIdToSession},
							}
							utility.SessionSet(w, r, sessionData)
						}
						err = tx.Commit()

						if err != nil {
							log.Println(err)
						} else {
							response = utility.AjaxResponse{
								Status: "success",
								Data:   "Hotel Is Added Successfully",
							}

						}
					} else {
						tx.Rollback()
					}
				} else {
					tx.Rollback()
				}
			}
		}
		encodingJson,
			err := json.Marshal(response)
		if err != nil {
			log.Println(err)
		}
		w.Write([]byte(encodingJson))
	}
}

func InserHighTrafficMonthData(tx *sql.Tx, months string, hotel_id int64) bool {
	var monthsStruc models.HighTrafficMonth
	months_arr := strings.Split(months, ",")
	for x := 0; x < len(months_arr); x++ {
		monthsStruc.Hotel_id = hotel_id
		monthsStruc.Month = sql.NullString{
			String: months_arr[x], Valid: months_arr[x] != ""}
		HighTrafficMonthInserted, _ := Db.highTrafficMonth.InsertHighTrafficMonth(tx, monthsStruc)
		if !(HighTrafficMonthInserted) {
			return false
		}
	}
	return true
}
func UpdateHotelData(w http.ResponseWriter, r *http.Request) {
	if (r.Method) == "POST" {
		response := utility.AjaxResponse{
			Status: "failure",
			Data:   "Something went wrong, Please try again",
		}
		var hotel models.Hotels
		tx, err := utility.Db.Begin()
		if err != nil {
			log.Fatal(err)
		} else {
			err := r.ParseMultipartForm(10)
			if err != nil {
				log.Println(err)
			} else {
				id := fmt.Sprintf("%v", utility.SessionGet(r, "id"))
				hotel_id := utility.ConvertToInt64(r.FormValue("hotel_id"))
				hotel.Id = hotel_id
				hotel.User_id = utility.ConvertToInt64(id)
				hotel.Hotel_name = sql.NullString{
					String: r.FormValue("hotel_name"), Valid: r.FormValue("hotel_name") != ""}
				hotel.Primary_customer = sql.NullString{
					String: r.FormValue("primary_customer"), Valid: r.FormValue("primary_customer") != ""}
				hotel.Nearest_competitor = sql.NullString{
					String: r.FormValue("nearest_competitor"), Valid: r.FormValue("nearest_competitor") != ""}
				hotel.Years_in_operation = sql.NullInt64{
					Int64: utility.ConvertToInt64(r.FormValue("years_in_operation")), Valid: r.FormValue("years_in_operation") != ""}
				hotel.Hotel_rating = sql.NullInt64{
					Int64: utility.ConvertToInt64(r.FormValue("hotel_rating")), Valid: r.FormValue("hotel_rating") != ""}
				hotel.HotelsUniqueId = sql.NullString{
					String: r.FormValue("hotel_unique_id"), Valid: r.FormValue("hotel_unique_id") != ""}
				hotel.Status = 1
				high_traffic_months := r.FormValue("high_traffic_months")

				if r.FormValue("hotel_unique_id") == "" || r.FormValue("hotel_name") == "" || r.FormValue("primary_customer") == "" || r.FormValue("nearest_competitor") == "" || r.FormValue("years_in_operation") == "" || r.FormValue("hotel_rating") == "" || len(high_traffic_months) == 0 {
					hotel.Status = 0
				}
				hotel_updated, _ := Db.hotels.UpdateHotel(tx, hotel)

				if hotel_updated {
					DeleteHighTrafficMonth, _ := Db.highTrafficMonth.DeleteHighTrafficMonth(tx, hotel_id)
					HighTrafficMonthInserted := true

					if len(high_traffic_months) > 0 {
						HighTrafficMonthInserted = InserHighTrafficMonthData(tx, high_traffic_months, hotel_id)
					}

					if (DeleteHighTrafficMonth) && (HighTrafficMonthInserted) {
						err = tx.Commit()
						if err != nil {
							log.Println(err)
						} else {
							response = utility.AjaxResponse{
								Status: "success",
								Data:   "Hotel Is Updated Successfully",
							}
						}
					} else {
						tx.Rollback()
					}
				} else {
					tx.Rollback()
				}
			}
		}
		encodingJson,
			err := json.Marshal(response)
		if err != nil {
			log.Println(err)
		}
		w.Write([]byte(encodingJson))
	}
}

func getDashboardData(r *http.Request, data models.Hotel) models.Hotel {
	year, month, day := time.Now().Local().Date()
	// calculating today midnight timestamp
	today := time.Date(year, month, day, 0, 0, 0, 0, time.UTC).Unix()
	hotel_id := fmt.Sprintf("%v", utility.SessionGet(r, "hotel_id"))

	data.Dashboard.Reservation_today, _ = Db.utility_model.CalculateReservationToday(today, utility.ConvertToInt64(hotel_id))
	total_rooms, _ := Db.utility_model.CalculateTotalRooms(utility.ConvertToInt64(hotel_id))
	data.Dashboard.Guest_arrival, _ = Db.utility_model.CalculateGuestArrival(today, utility.ConvertToInt64(hotel_id))
	data.Dashboard.Guest_departure, _ = Db.utility_model.CalculateGuestDeparture(today, utility.ConvertToInt64(hotel_id))
	data.Dashboard.Current_occupany = data.Dashboard.Reservation_today
	data.Dashboard.Empty_rooms = total_rooms - data.Dashboard.Current_occupany
	return data
}

func Settings(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "settings", nil)
}
func GetdataUserSettings(w http.ResponseWriter, r *http.Request) {
	dataRooms := Db.usersetting.GetSettings(fmt.Sprintf("%v", utility.SessionGet(r, "id")))
	response := utility.AjaxResponse{Status: "success", Data: dataRooms}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func SetdataUserSettings(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"columnName", "columnValue"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			userid := fmt.Sprintf("%v", utility.SessionGet(r, "id"))
			columnName := formValue["columnName"]
			columnValue := utility.ConvertToInt64(formValue["columnValue"])
			if Db.usersetting.SetSettings(userid, columnName, columnValue) {
				response = utility.AjaxResponse{Status: "success", Data: "Tax value " + columnName + " update successfully."}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Tax value " + columnName + " not update."}
			}
		} else {
			response = utility.AjaxResponse{Status: "failure", Data: "Required filed are missing."}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}
