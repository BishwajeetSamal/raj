package controllers

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"reakgo/models"
	"reakgo/utility"
	"time"

	"golang.org/x/crypto/bcrypt"
)

func ForgotPassword(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {

		fields := make(map[string][]string)
		fields["required"] = []string{"email"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			auth, err := Db.authentication.GetUserByEmail(formValue["email"])
			if err != nil {
				time.Sleep(3 * time.Second) // 3 second delay for fake message
				utility.AddFlash("success", "Email with password reset link has been sent, Please check your inbox.", w, r)
			} else {
				// User returned successfully, Send email
				tokenNew, err := Db.authentication.ForgotPassword(auth.Id)
				if err != nil {
					log.Println(err)
					utility.AddFlash("warning", "Password Reset Email couldn't be sent at the moment, Please try again.", w, r)
				} else {
					// email information set
					data := make(map[string]string)
					data["email"] = formValue["email"]
					data["link_with_parameter"] = "change_password?email=" + formValue["email"] + "&token=" + tokenNew
					to := []string{formValue["email"]}
					data["subject"] = "Password reset request"
					isSuccess, err := utility.SendEmail(to, "email_forgot_password", data)
					if err != nil {
						log.Println(err)
						utility.AddFlash("warning", "Password Reset Email couldn't be sent at the moment, Please try again.", w, r)
					}
					if isSuccess {
						utility.AddFlash("success", "Email with password reset link has been sent, Please check your inbox.", w, r)
					}
				}
			}
		} else {
			// Check Empty required value use this => log.Println("inValid : Empty Required Value =>" + formValue["empty"])
			utility.AddFlash("warning", "Please enter an email address", w, r)
		}
	}
	utility.RenderTemplate(w, r, "forgot_password", nil)
}

func ChangePassword(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		token := r.URL.Query().Get("token")
		email := r.URL.Query().Get("email")

		fields := make(map[string][]string)
		fields["required"] = []string{"new_password", "confirm_password"}

		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid && token != "" && email != "" {
			if formValue["new_password"] != formValue["confirm_password"] {
				utility.AddFlash("success", "Password and confirmation password do not match.", w, r)
			} else {
				resp, expire, err := Db.authentication.TokenVerify(email, token, formValue["new_password"])
				if err != nil {
					log.Println(err)
					//utility.AddFlash("warning", "Password cannot be updated at this moment, Please try again", w, r)
				}
				if resp {
					utility.AddFlash("success", "Password has been changed successfully, Please login.", w, r)
				}
				if expire {
					utility.AddFlash("danger", "This link has been expired, Please try again.", w, r)
				}
			}
		} else {
			if isValid {
				utility.AddFlash("warning", "This link may be incorrect, Please try again.", w, r)
			} else {
				utility.AddFlash("warning", "Please enter the password", w, r)
			}
		}
	}
	utility.RenderTemplate(w, r, "change_password", nil)
}

func VerifyEmail(w http.ResponseWriter, r *http.Request) {
	var data string
	token := r.URL.Query().Get("token")
	email := r.URL.Query().Get("email")
	if email != "" {
		chckStatus := Db.authentication.CheckStatus(email, token)
		if chckStatus != 1 {
			resp, expire, err := Db.authentication.TokenVerify(email, token, "")
			if err != nil {
				log.Println(err)
				utility.AddFlash("warning", "Email cannot be verified at this moment, Please try again", w, r)
			}
			if resp {
				data = "Thankyou, Email Verified Successfully"
				utility.RenderTemplate(w, r, "email_success", data)
			}
			if expire {
				utility.AddFlash("danger", "This link will be expire, Please try again.", w, r)
			}
		} else {
			data = "Email has already been verified, Please login"
			utility.RenderTemplate(w, r, "email_success", data)
		}
	}

}

func Login(w http.ResponseWriter, r *http.Request) {

	if (r.Method) == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			var email string = r.FormValue("email")
			var password string = r.FormValue("password")
			if email == "" || password == "" {
				log.Println("Please Fill all required fields")
			} else {
				auth, err := Db.authentication.GetUserByEmail(email)
				if err != nil {
					log.Println(err)
				} else {
					err := bcrypt.CompareHashAndPassword([]byte(auth.Password), []byte(r.FormValue("password")))
					if err != nil {
						log.Println(err)
						utility.AddFlash("Failure", "The Entered credentials are incorrect.", w, r)
					} else {
						id := fmt.Sprintf("%v", auth.Id)
						hotel_id := fmt.Sprintf("%v", auth.Hotel_id)
						place, err := Db.authentication.GetUserPlace(utility.ParseToInt(id))
						if err != nil {
							utility.AddFlash("Failure", "Something Went Wrong, Please Try Again!", w, r)
							log.Println(err)
						} else {
							sessionData := []utility.Session{
								{Key: "id", Value: id},
								{Key: "username", Value: auth.Email},
								{Key: "type", Value: "user"},
								{Key: "hotel_id", Value: hotel_id},
								{Key: "first_name", Value: auth.First_name},
								{Key: "city", Value: place.City},
								{Key: "country", Value: place.Country},
								{Key: "state", Value: place.State},
							}
							utility.SessionSet(w, r, sessionData)
							utility.RedirectTo(w, r, os.Getenv("APPURL")+"dashboard")
							utility.AddFlash("Success", "Login Successfully !", w, r)
						}
					}
				}
			}
		}
	}
	utility.RenderTemplate(w, r, "index", nil)
}

func Signup(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "signup", nil)
}

func Email_sucess(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "email_success", nil)
}

func UnderProgress(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "under_progress", nil)
}

//Signup function for Registration of new user
func SignupAjax(w http.ResponseWriter, r *http.Request) {
	var insert_for_register models.Authentication
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			utility.AddFlash("danger", "Sorry !, There has been issue creating your account, Please try again in a short while", w, r)
		} else {
			//Email Verify if present or not inside database
			if r.FormValue("signup_email") != "" {
				auth, _ := Db.authentication.CheckExistEmail(r.FormValue("email")) //this func check whether email exist or not
				if auth == true {
					utility.AddFlash("danger", "This Email already exist!", w, r)
				} else {
					insert_for_register.First_name = r.FormValue("signup_fname")
					insert_for_register.Last_name = r.FormValue("signup_lname")
					insert_for_register.Email = r.FormValue("signup_email")
					insert_for_register.Phone = r.FormValue("signup_phone")
					insert_for_register.Password = r.FormValue("signup_password")
					insert_for_register.Hotel_id = ""
					insert_for_register.Token = ""
					insert_for_register.TokenTimestamp = 0
					insert_for_register.CityId = utility.StrToInt64(r.FormValue("signup_city"))
					//test
					tx, err := utility.Db.Begin()
					if err != nil {
						log.Println(err)
					} else {
						resp, userId, err := Db.authentication.InsertDatatoAuthTable(insert_for_register, tx)
						insert_for_register.Id = userId
						//Insertion of data takes place into database
						if err != nil {
							tx.Rollback()
							log.Println(err)
							utility.AddFlash("danger", "There has been issue creating your account!", w, r)
						} else {
							if resp == true {
								resp1, err := Db.authentication.InsertUserPlaceData(insert_for_register, tx)
								if err != nil {
									tx.Rollback()
									log.Println(err)
								} else if resp1 == true {
									err = tx.Commit()
									if err != nil {
										log.Println(err)
									} else {

										// email information set
										tokenNew, err := Db.authentication.GenTokenForVerification(userId)
										if err != nil {
											log.Println(err)
										} else {
											data := make(map[string]string)
											data["email"] = insert_for_register.Email
											data["link_with_parameter"] = "token_verify?email=" + insert_for_register.Email + "&token=" + tokenNew
											to := []string{insert_for_register.Email}
											data["name"] = insert_for_register.First_name + " " + insert_for_register.Last_name
											data["subject"] = "Email Verification Link"

											// Email send for verifying the user
											isSuccess, err := utility.SendEmail(to, "signup_email_verify", data)
											if err != nil {
												log.Println(err)
											}
											if isSuccess {
												data1 := make(map[string]interface{})
												data1["status"] = "success"
												json, _ := json.Marshal(data1)
												w.Write([]byte(json))
												utility.AddFlash("success", "User Added Successfully !", w, r)
											} else {
												utility.AddFlash("warning", "Email verification link couldn't be send at the moment, Please try again.", w, r)
												resp3 := Db.authentication.DelAuthandUserPlace(userId)
												if resp3 {
													data1 := make(map[string]interface{})
													data1["status"] = "failure"
													json, _ := json.Marshal(data1)
													w.Write([]byte(json))

												}
											}
										}
									}
								}
							}
						}
					}

				}

			} else {
				utility.AddFlash("danger", "Sorry !, There has been issue creating your account, Please try again in a short while", w, r)
			}
		}
	}
}

func Check_email(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("register_check_email") != "" {
				form_email := r.FormValue("register_check_email")
				auth, _ := Db.authentication.CheckExistEmail(form_email) //this func check whether email exist or not
				data := make(map[string]interface{})
				if auth == true {
					//returns true to ajax function for the existing email
					data["status"] = "success"
					data["email_present"] = auth
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				} else {
					data["status"] = "failure"
					data["email_present"] = auth
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				}
			}
		}
	}
}

func Logout(w http.ResponseWriter, r *http.Request) {
	res := utility.SessionDestroy(w, r)
	data := make(map[string]string)
	if res {
		data["Status"] = "success"
	} else {
		data["Status"] = "failure"
	}
	log.Println(utility.SessionGet(r, "username"))
	json, _ := json.Marshal(data)
	w.Write([]byte(json))
}
func CheckLoginStatus(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("loggedin"))
}
