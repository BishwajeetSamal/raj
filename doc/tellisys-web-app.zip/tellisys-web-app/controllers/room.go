package controllers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"reakgo/models"
	"reakgo/utility"
	"strings"
)

func AddRoomType(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "room_type", nil)
}

func AddRoomTypeData(w http.ResponseWriter, r *http.Request) {
	if (r.Method) == "POST" {
		response := utility.AjaxResponse{
			Status: "failure",
			Data:   "Something went wrong, Please try again",
		}
		var room_type models.RoomType

		tx, err := utility.Db.Begin()
		if err != nil {
			log.Fatal(err)
		} else {
			fields := make(map[string][]string)
			fields["required"] = []string{"roomType_name", "abbreviation", "max_adult", "max_children", "checkin_hours", "checkin_minu", "checkin_ampm", "checkOut_hours", "checkOut_minu", "checkOut_ampm", "basePrice", "status", "no_of_rooms", "room_nos", "beds", "rooms"}
			fields["other"] = []string{"smoking", "pet", "description", "permit_tax_id", "checkIn_meth", "checkIn_inst", "infant_inst", "cancel_policy"}
			formValue,
				isValid := utility.CheckFormValidation(r, fields, "multiPart")
			if isValid {
				authId := utility.StrToInt64(fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				if err == nil {
					room_type.User_id = authId
					room_type.Name = formValue["roomType_name"]
					room_type.Abbreviation = formValue["abbreviation"]
					room_type.Max_adult = utility.ConvertToInt64(formValue["max_adult"])
					room_type.Max_children = utility.ConvertToInt64(formValue["max_children"])
					room_type.Check_in_hour = utility.ConvertToInt64(formValue["checkin_hours"])
					room_type.Check_in_minu = utility.ConvertToInt64(formValue["checkin_minu"])
					room_type.Check_in_ampm = formValue["checkin_ampm"]
					room_type.Check_out_hour = utility.ConvertToInt64(formValue["checkOut_hours"])
					room_type.Check_out_minu = utility.ConvertToInt64(formValue["checkOut_minu"])
					room_type.Check_out_ampm = formValue["checkOut_ampm"]
					room_type.Base_price = utility.ConvertToInt64(formValue["basePrice"])
					room_type.Pet_allowed = utility.ConvertToInt64(formValue["pet"])
					room_type.Status = utility.ConvertToInt64(formValue["status"])
					room_type.Total_rooms = utility.ConvertToInt64(formValue["no_of_rooms"])
					room_type.Smoking_allowed = utility.ConvertToInt64(formValue["smoking"])
					room_type.Description = formValue["description"]
					room_type.Permit_tax_id = formValue["permit_tax_id"]
					room_type.Check_in_method = formValue["checkIn_meth"]
					room_type.Check_in_instruction = formValue["checkIn_inst"]
					room_type.Children_infant_restriction = formValue["infant_inst"]
					room_type.Cancellation_policy = formValue["cancel_policy"]

					roomTypeID, _ := Db.roomType.InsertRoomType(tx, room_type)

					if roomTypeID != 0 {
						bedInserted := AddBed(tx, formValue["beds"], roomTypeID)
						roomInserted := AddRoom(tx, formValue["rooms"], roomTypeID)
						roomNoInserted := AddRoomNo(tx, r.FormValue("room_nos"), roomTypeID)
						imageInserted := true
						r.ParseMultipartForm(utility.ConvertToInt64(os.Getenv("RAM_FOR_FILE")))
						images := r.MultipartForm.File["images"]
						if len(images) > 0 {
							imageInserted = UploadRoomImages(tx, images, roomTypeID)
						}
						if !(bedInserted) || !(roomInserted) || !(roomNoInserted) || !(imageInserted) {
							tx.Rollback()
						} else {
							err = tx.Commit()
							if err != nil {
								log.Println(err)
							} else {
								response = utility.AjaxResponse{
									Status: "success",
									Data:   "Room Type Is Added Successfully",
								}
							}
						}
					} else {
						tx.Rollback()
					}
				}
			}
		}
		encodingJson,
			err := json.Marshal(response)
		if err != nil {
			log.Println(err)
		}
		w.Write([]byte(encodingJson))
	}
}

func AddBed(tx *sql.Tx, beds string, roomTypeID int64) bool {
	var bedStruc []models.Bed
	bedsBytes := []byte(beds)
	err := json.Unmarshal(bedsBytes, &bedStruc)
	if err != nil {
		log.Println(err)
		return false
	}
	for _, bed := range bedStruc {
		bed.Room_type_id = roomTypeID
		bedInserted, _ := Db.bed.InsertBed(tx, bed)
		if !(bedInserted) {
			return false
		}
	}
	return true
}
func AddRoom(tx *sql.Tx, rooms string, roomTypeID int64) bool {
	var roomStruc []models.Room
	roomsBytes := []byte(rooms)
	err := json.Unmarshal(roomsBytes, &roomStruc)
	if err != nil {
		log.Println(err)
		return false
	}
	for _, room := range roomStruc {
		room.Room_type_id = roomTypeID
		roomInserted, _ := Db.room.InsertRoom(tx, room)
		if !(roomInserted) {
			return false
		}
	}
	return true
}

func AddRoomNo(tx *sql.Tx, roomsNo string, roomTypeID int64) bool {
	var roomNoStruc models.RoomNo
	roomNo_arr := strings.Split(roomsNo, ",")
	for x := 0; x < len(roomNo_arr); x++ {
		roomNoStruc.Room_type_id = roomTypeID
		roomNoStruc.Room_no = roomNo_arr[x]
		roomNoInserted, _ := Db.roomNo.InsertRoomNo(tx, roomNoStruc)
		if !(roomNoInserted) {
			return false
		}
	}
	return true
}

func UploadRoomImages(tx *sql.Tx, images []*multipart.FileHeader, roomTypeID int64) bool {
	var imageInserted bool

	for _, fileHeader := range images {
		buff := make([]byte, 512)
		file, _ := fileHeader.Open()
		defer file.Close()
		_, err := file.Read(buff)
		if err != nil {
			log.Println(err)
			return false
		}
		filetype := http.DetectContentType(buff)
		if filetype == "image/jpeg" || filetype == "image/jpg" || filetype == "image/png" {

			ext := filepath.Ext(fileHeader.Filename)
			ext = utility.MysqlRealEscapeString(ext)
			// Create a temporary file within our upload/room_images directory that follows
			tempFile,
				err := ioutil.TempFile("upload/room_images", "*"+ext+"")
			if err != nil {
				log.Println(err)
				return false
			}
			defer tempFile.Close()
			path := tempFile.Name()
			// read all of the contents of our uploaded file into a byte array
			file, _ = fileHeader.Open()
			defer file.Close()
			fileBytes, err := ioutil.ReadAll(file)
			if err != nil {
				log.Println(err)
				return false
			}
			// write this byte array to our temporary file
			tempFile.Write(fileBytes)
			imageInserted = AddImage(tx, path, roomTypeID)
			if !(imageInserted) {
				return imageInserted
			}
		}
	}
	return imageInserted
}

func AddImage(tx *sql.Tx, path string, roomTypeID int64) bool {
	var image models.Image
	image.Room_type_id = roomTypeID
	image.Path = path
	imageInserted, _ := Db.image.InsertImage(tx, image)
	if !(imageInserted) {
		return false
	}
	return true
}

func Room_list(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "roomType_list", nil)
}

func Get_rooms(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"StartLimit", "LimitRows"}
		// fields["other"] = []string{"toDate"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			hotel_id := fmt.Sprintf("%v", utility.SessionGet(r, "hotel_id"))
			hotel_id = utility.MysqlRealEscapeString(hotel_id)
			var QryDetails models.QueryDetails

			QryDetails.StartLimit = utility.StrToInt64(formValue["StartLimit"])
			QryDetails.LimitRows = utility.StrToInt64(formValue["LimitRows"])
			QryDetails.Schema = "room_type"
			QryDetails.Columns = []string{"rt.room_type_id", "rt.name", "rt.abbreviation", "rt.max_adult_allowed", "rt.max_children_allowed", "rt.base_price", "IfNull((SELECT path from image WHERE image.room_type_id = rt.room_type_id limit 1 ), 0) as image"}
			QryDetails.Middle_Condition = "rt inner join authentication auth on rt.user_id = auth.id && auth.hotel_id=" + hotel_id + ""
			QryDetails.Condition = "1"

			data, err := Db.utility_model.GetPaginationRecords(QryDetails)
			if err != nil {
				log.Println(err)
			}
			if data.QueryDetails.AllRecords != 0 {
				response = utility.AjaxResponse{Status: "success", Data: data}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Data not available in the system"}
			}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}
func ShowRoomTypeEdit(w http.ResponseWriter, r *http.Request) {
	var data models.RoomTypeData
	keys, status := r.URL.Query()["RoomType_id"]

	if !status || len(keys[0]) < 1 {
		log.Println("RoomType Id is not provided")
		utility.RenderTemplate(w, r, "roomType_list", data)
	} else {
		id := keys[0]
		data, _ = Db.roomType.FetchRoomType(utility.ConvertToInt64(id))
		utility.RenderTemplate(w, r, "edit_roomType", data)
	}

}

func UpdateRoomTypeData(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{
		Status: "failure",
		Data:   "Something went wrong, Please try again",
	}
	if (r.Method) == "POST" {
		var room_type models.RoomType
		tx, err := utility.Db.Begin()

		if err != nil {
			log.Println(err)
		} else {
			fields := make(map[string][]string)
			fields["required"] = []string{"id", "roomType_name", "abbreviation", "max_adult", "max_children", "checkin_hours", "checkin_minu", "checkin_ampm", "checkOut_hours", "checkOut_minu", "checkOut_ampm", "basePrice", "status", "no_of_rooms", "room_nos", "beds", "rooms"}
			fields["other"] = []string{"smoking", "pet", "description", "permit_tax_id", "checkIn_meth", "checkIn_inst", "infant_inst", "cancel_policy"}
			formValue, isValid := utility.CheckFormValidation(r, fields, "multiPart")
			if isValid {
				room_type.Room_type_id = utility.ConvertToInt64(formValue["id"])
				room_type.Name = formValue["roomType_name"]
				room_type.Abbreviation = formValue["abbreviation"]
				room_type.Max_adult = utility.ConvertToInt64(formValue["max_adult"])
				room_type.Max_children = utility.ConvertToInt64(formValue["max_children"])
				room_type.Check_in_hour = utility.ConvertToInt64(formValue["checkin_hours"])
				room_type.Check_in_minu = utility.ConvertToInt64(formValue["checkin_minu"])
				room_type.Check_in_ampm = formValue["checkin_ampm"]
				room_type.Check_out_hour = utility.ConvertToInt64(formValue["checkOut_hours"])
				room_type.Check_out_minu = utility.ConvertToInt64(formValue["checkOut_minu"])
				room_type.Check_out_ampm = formValue["checkOut_ampm"]
				room_type.Base_price = utility.ConvertToInt64(formValue["basePrice"])
				room_type.Pet_allowed = utility.ConvertToInt64(formValue["pet"])
				room_type.Status = utility.ConvertToInt64(formValue["status"])
				room_type.Total_rooms = utility.ConvertToInt64(formValue["no_of_rooms"])
				room_type.Smoking_allowed = utility.ConvertToInt64(formValue["smoking"])
				room_type.Description = formValue["description"]
				room_type.Permit_tax_id = formValue["permit_tax_id"]
				room_type.Check_in_method = formValue["checkIn_meth"]
				room_type.Check_in_instruction = formValue["checkIn_inst"]
				room_type.Children_infant_restriction = formValue["infant_inst"]
				room_type.Cancellation_policy = formValue["cancel_policy"]

				roomTypeUpdated, _ := Db.roomType.UpdateRoomType(tx, room_type)
				bedInserted := AddBed(tx, formValue["beds"], room_type.Room_type_id)
				roomInserted := AddRoom(tx, formValue["rooms"], room_type.Room_type_id)
				roomNoInserted := AddRoomNo(tx, r.FormValue("room_nos"), room_type.Room_type_id)
				imageInserted := true
				r.ParseMultipartForm(utility.ConvertToInt64(os.Getenv("RAM_FOR_FILE")))
				images := r.MultipartForm.File["images"]
				if len(images) > 0 {
					imageInserted = UploadRoomImages(tx, images, room_type.Room_type_id)
				}
				if !(roomTypeUpdated) || !(bedInserted) || !(roomInserted) || !(roomNoInserted) || !(imageInserted) {
					tx.Rollback()
				} else {
					err = tx.Commit()
					if err != nil {
						log.Println(err)
					} else {
						response = utility.AjaxResponse{
							Status: "success",
							Data:   "Room Type Is Updated Successfully",
						}
					}
				}
			}
		}
		encodingJson,
			err := json.Marshal(response)
		if err != nil {
			log.Println(err)
		}
		w.Write([]byte(encodingJson))
		//utility.AddFlash("success", "Room Type Is Updated Successfully", w, r)
		//utility.RedirectTo(w, r, os.Getenv("APPURL")+"dashboard")
		//utility.AddFlash(response.Status, fmt.Sprintf("%v", response.Data), w, r)
	}
}

func DeleteRooms (w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{
		Status: "success",
		Data:   "Room Type Is Deleted Successfully",
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))

}