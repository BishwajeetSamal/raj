package controllers

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"strconv"
	"time"

	"github.com/go-sql-driver/mysql"
)

//This unc save the data to reservation_collct table
func SaveCollectDetails(w http.ResponseWriter, r *http.Request) {
	var insert_collect_userData models.Reservation
	if r.Method == "POST" {
		data1 := map[string]interface{}{"status": "success"}

		tx, err := utility.Db.Begin()
		if err != nil {
			log.Panicln(err)
		}
		err = r.ParseForm()
		if err != nil {
			utility.AddFlash("danger", "Sorry !, There has been issue while Saving your data, Please try again in a short while", w, r)
		} else {
			if r.FormValue("selectecd_room_id") != "" {
				checkIndate := utility.DateParser_unix(r.FormValue("collect_checkIn"))
				checkOutdate := utility.DateParser_unix(r.FormValue("collect_checkOut"))
				adult := utility.StrToInt64(r.FormValue("collect_adult"))
				child := utility.StrToInt64(r.FormValue("collect_child"))
				selectecd_room_id := utility.StrToInt64(r.FormValue("selectecd_room_id"))
				user_id := utility.StrToInt64(r.FormValue("user_id"))
				insert_collect_userData.CheckIn = strconv.FormatInt(checkIndate, 10)
				insert_collect_userData.CheckOut = strconv.FormatInt(checkOutdate, 10)
				insert_collect_userData.Adult = adult
				insert_collect_userData.Child = child
				insert_collect_userData.Collect_rack_rate = r.FormValue("collect_rack_rate")
				insert_collect_userData.Room_type_id = selectecd_room_id
				insert_collect_userData.Room_number = r.FormValue("getRoomNo")
				insert_collect_userData.Userid = user_id
				insert_collect_userData.Room_charges = r.FormValue("room_charges")
				insert_collect_userData.Trip_total = r.FormValue("trip_total")
				insert_collect_userData.Due_depo = r.FormValue("due_depo")
				insert_collect_userData.Timestamp = time.Now().Unix()
				resp, collectId, err := Db.reservation.InsertUserCollectData(tx, insert_collect_userData)
				if err != nil {
					log.Println(err)
					tx.Rollback()
				} else {
					if resp {

						RoomTax1 := utility.StrToFloat64(r.FormValue("room_tax_1"))
						RoomTax2 := utility.StrToFloat64(r.FormValue("room_tax_2"))
						VATTax1 := utility.StrToFloat64(r.FormValue("vat_tax_1"))
						VATTax2 := utility.StrToFloat64(r.FormValue("vat_tax_2"))

						statusRoomTax := Db.taxes.SetRoomTax(tx, selectecd_room_id, collectId, RoomTax1, RoomTax2)
						statusVATTax := Db.taxes.SetVATTax(tx, collectId, VATTax1, VATTax2)

						if statusRoomTax && statusVATTax {
							err = tx.Commit()
							if err != nil {
								tx.Rollback()
								log.Println(err)
							} else {
								data1["status"] = "success"
								data1["res_id"] = collectId
							}
						}
					} else {
						tx.Rollback()
					}
				}
			}
		}
		json1, _ := json.Marshal(data1)
		w.Write([]byte(json1))
	}
}

func GetPriceDataInGuestPage(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			if (r.FormValue("res_id")) != "" {
				res_id := utility.StrToInt64(r.FormValue("res_id"))
				AllData, err := Db.reservation.FetchPriceData(res_id)
				priceResp := AllData.Reserv
				if err != nil {
					log.Println(err)
				} else {
					priceResp.CheckIn, _ = utility.EpochToDate(priceResp.CheckIn)
					priceResp.CheckOut, _ = utility.EpochToDate(priceResp.CheckOut)

					data1 := make(map[string]interface{})
					data1["status"] = "success"
					data1["priceData"] = priceResp
					data1["room_tax"] = AllData.Taxes.RoomTax
					data1["vat_tax"] = AllData.Taxes.VatTax
					json1, _ := json.Marshal(data1)
					w.Write([]byte(json1))
				}
			}
		}
	}
}

//This function only to render the template of reservation_collect page
func Reservation_collect(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "reservation_collect", nil)
}

//This function only to render the template of reservation_confirm page
func Reservation_confirm(w http.ResponseWriter, r *http.Request) {
	res_id := r.URL.Query().Get("id")
	log_id := fmt.Sprintf("%v", utility.SessionGet(r, "id"))
	response_data := GetReservationData(res_id, log_id)
	utility.RenderTemplate(w, r, "reservation_confirm", response_data)
}

func GetReservationData(res_id string, log_id string) map[string]interface{} {
	var crrDate string
	resp, err := Db.reservation.GetAllDataFinal(res_id, log_id)
	room_tax := Db.taxes.GetRoomTax(res_id)
	vat_tax := Db.taxes.GetVATTax(res_id)
	if err != nil {
		log.Println(err)
	} else {
		crrDate = time.Now().Format("2006-01-02")
		// using for loop
		resp.CreatedOn = crrDate
	}
	response_data := map[string]interface{}{"Confirm": resp, "Roomtax": room_tax, "VAT": vat_tax}
	return response_data
}

func RoomTape(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "reservationtimeline", nil)
}

func RoomTape_timeline(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "failure", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"fromDate"}
		fields["other"] = []string{"toDate", "adult", "child"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			fromDate := utility.DateParser_unix(formValue["fromDate"])
			adult := utility.StrToInt64(formValue["adult"])
			child := utility.StrToInt64(formValue["child"])
			if fromDate != 0 {
				reservation_filter := models.Reservation{CheckIn: utility.SplitDate(formValue["fromDate"]), CheckOut: utility.SplitDate(formValue["toDate"]), Adult: adult, Child: child}
				roomNumber := Db.utility_model.Get_rooms_data(reservation_filter, "roomno", fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				dataRoomType := Db.utility_model.Get_rooms_data(reservation_filter, "roomtype", fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				allRooms := Db.utility_model.CountAll("roomNo")
				assign := Db.reservation.AssignUnassignRoom(reservation_filter, true)
				reservation := Db.reservation.Reservation_timeline(reservation_filter)
				unassign := Db.reservation.AssignUnassignRoom(reservation_filter, false)
				response = utility.AjaxResponse{Status: "success", Data: map[string]interface{}{"Rooms": roomNumber, "Reserve": reservation, "Statistics": dataRoomType, "Unassign": unassign, "AllocatedRoom": assign, "AllRooms": allRooms}}
			}
		} else {
			response = utility.AjaxResponse{Status: "failure", Data: "Required filed are missing."}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

//This function only to render the template of edit_collect page
func Edit_collect(w http.ResponseWriter, r *http.Request) {
	res_id := r.URL.Query().Get("id")
	utility.RenderTemplate(w, r, "edit_collect", res_id)
}

//This function only to render the template of edit_collect page
func ErrorServer(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "error_server", nil)
}

func GetEditCollectData(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			if (r.FormValue("res_id")) != "" {
				res_id := utility.StrToInt64(r.FormValue("res_id"))
				editResp, err := Db.reservation.GetDataCollectEdit(res_id)
				if err != nil {
					log.Println(err)
				} else {
					editResp.CheckIn, _ = utility.EpochToDate(editResp.CheckIn)
					editResp.CheckOut, _ = utility.EpochToDate(editResp.CheckOut)
					data1 := make(map[string]interface{})
					data1["status"] = "success"
					data1["edit_data"] = editResp
					json1, _ := json.Marshal(data1)
					w.Write([]byte(json1))
				}
			}
		}
	}
}

//Update reservation_collect data by Reservation Id
func UpdateCollectDetails(w http.ResponseWriter, r *http.Request) {
	var insert_collect_userData models.Reservation
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			if r.FormValue("selectecd_room_id") != "" {
				checkIndate := utility.DateParser_unix(r.FormValue("collect_checkIn"))
				checkOutdate := utility.DateParser_unix(r.FormValue("collect_checkOut"))
				adult := utility.StrToInt64(r.FormValue("collect_adult"))
				child := utility.StrToInt64(r.FormValue("collect_child"))
				selectecd_room_id := utility.StrToInt64(r.FormValue("selectecd_room_id"))
				user_id := utility.StrToInt64(r.FormValue("user_id"))
				res_Id := utility.StrToInt64(r.FormValue("resId"))
				insert_collect_userData.CheckIn = strconv.FormatInt(checkIndate, 10)
				insert_collect_userData.CheckOut = strconv.FormatInt(checkOutdate, 10)
				insert_collect_userData.Adult = adult
				insert_collect_userData.Child = child
				insert_collect_userData.Collect_rack_rate = r.FormValue("collect_rack_rate")
				insert_collect_userData.Room_type_id = selectecd_room_id
				insert_collect_userData.Room_number = r.FormValue("getRoomNo")
				insert_collect_userData.Userid = user_id
				insert_collect_userData.Room_charges = r.FormValue("room_charges")
				insert_collect_userData.Trip_total = r.FormValue("trip_total")
				insert_collect_userData.Due_depo = r.FormValue("due_depo")
				insert_collect_userData.Res_Id = res_Id
				resp := Db.reservation.UpdateUserCollectData(insert_collect_userData)
				if err != nil {
					log.Println(err)
				} else {
					if resp {
						data1 := make(map[string]interface{})
						data1["status"] = "success"
						json1, _ := json.Marshal(data1)
						w.Write([]byte(json1))
					} else {
						data1 := make(map[string]interface{})
						data1["status"] = "faliure"
						json1, _ := json.Marshal(data1)
						w.Write([]byte(json1))
					}
				}
			}
		}
	}
}
func ShowReservations(w http.ResponseWriter, r *http.Request) {
	keys, err := r.URL.Query()["page"]

	if !err || len(keys[0]) < 1 {
		utility.RenderTemplate(w, r, "reservation_list", nil)
	} else {
		key := keys[0]
		switch key {
		case "checkIn_list":
			utility.RenderTemplate(w, r, "checkIn_res", nil)
		case "checkOut_list":
			utility.RenderTemplate(w, r, "checkOut_res", nil)
		case "activeRes_list":
			utility.RenderTemplate(w, r, "active_res", nil)
		}
	}
}

// GET_FORMAT(DATE,'JIS') date format YYYY-MM-DD

func Get_allReservations(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		hotel_id := fmt.Sprintf("%v", utility.SessionGet(r, "hotel_id"))
		hotel_id = utility.MysqlRealEscapeString(hotel_id)

		fields := make(map[string][]string)
		fields["required"] = []string{"StartLimit", "LimitRows"}
		fields["other"] = []string{"missCheckin"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			var QryDetails models.QueryDetails

			QryDetails.StartLimit = utility.StrToInt64(formValue["StartLimit"])
			QryDetails.LimitRows = utility.StrToInt64(formValue["LimitRows"])
			QryDetails.Schema = "reservation_collect"
			QryDetails.Columns = []string{"coll.id", "concat(gue.first_name, SPACE(1),gue.last_name) as guest_name", "from_unixtime(coll.timestamp, GET_FORMAT(DATE,'JIS')) as tttime", "from_unixtime(coll.checkIn, GET_FORMAT(DATE,'JIS')) as checkin", "from_unixtime(coll.checkout, GET_FORMAT(DATE,'JIS'))  as checkout", "coll.adult", "coll.child", "room_type.name", "roomNo.room_no", "(CASE WHEN pay.id IS NOT NULL THEN 'Paid' else 'Unpaid' end) as payment_status"}
			QryDetails.Middle_Condition = "coll left join reservation_payment pay on pay.resid = coll.id inner join authentication  auth on coll.userid=auth.id && auth.hotel_id=" + hotel_id + " left join reservation_guest gue on coll.guest_id=gue.id left join roomNo on coll.room_no_id=roomNo.id left join room_type on roomNo.room_type_id=room_type.room_type_id"
			QryDetails.Condition = "1"

			data, err := Db.utility_model.GetPaginationRecords(QryDetails)
			if err != nil {
				log.Println(err)
			}
			if data.QueryDetails.AllRecords != 0 {
				response = utility.AjaxResponse{Status: "success", Data: data}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Data not available in the system"}
			}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func Get_ResTo_CheckIn(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		year, month, day := time.Now().Local().Date()
		//calculating today midnight timestamp
		today := strconv.FormatInt(time.Date(year, month, day, 0, 0, 0, 0, time.UTC).Unix(), 10)
		today = utility.MysqlRealEscapeString(today)
		hotel_id := fmt.Sprintf("%v", utility.SessionGet(r, "hotel_id"))
		hotel_id = utility.MysqlRealEscapeString(hotel_id)

		fields := make(map[string][]string)
		fields["required"] = []string{"StartLimit", "LimitRows"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {

			var QryDetails models.QueryDetails

			QryDetails.StartLimit = utility.StrToInt64(formValue["StartLimit"])
			QryDetails.LimitRows = utility.StrToInt64(formValue["LimitRows"])
			QryDetails.Schema = "reservation_payment"
			QryDetails.Columns = []string{"coll.id", "concat(gue.first_name,' ',gue.last_name) as guest_name", "from_unixtime(coll.timestamp,  GET_FORMAT(DATE,'JIS'))", "from_unixtime(coll.checkIn,  GET_FORMAT(DATE,'JIS'))", "from_unixtime(coll.checkout,  GET_FORMAT(DATE,'JIS'))", "coll.adult, coll.child", "room_type.name", "roomNo.room_no", "from_unixtime(coll.checkin,  GET_FORMAT(DATE,'JIS')) = from_unixtime(" + today + ",  GET_FORMAT(DATE,'JIS')) as checkInMiss"}
			QryDetails.Middle_Condition = "pay inner join reservation_collect coll on pay.resid = coll.id && coll.checkin<=" + today + " left join guest_checkIn_checkOut time on time.res_id=coll.id inner join authentication  auth on coll.userid=auth.id && auth.hotel_id=" + hotel_id + " && time.res_id is NULL inner join reservation_guest gue on coll.guest_id=gue.id inner join roomNo on coll.room_no_id=roomNo.id inner join room_type on roomNo.room_type_id=room_type.room_type_id"

			QryDetails.Condition = "1"

			data, err := Db.utility_model.GetPaginationRecords(QryDetails)
			if err != nil {
				log.Println(err)
			}
			if data.QueryDetails.AllRecords != 0 {
				response = utility.AjaxResponse{Status: "success", Data: data}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Data not available in the system"}
			}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func Get_ActiveReservations(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		hotel_id := fmt.Sprintf("%v", utility.SessionGet(r, "hotel_id"))
		hotel_id = utility.MysqlRealEscapeString(hotel_id)

		fields := make(map[string][]string)
		fields["required"] = []string{"StartLimit", "LimitRows"}
		// fields["other"] = []string{"toDate"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {

			var QryDetails models.QueryDetails

			QryDetails.StartLimit = utility.StrToInt64(formValue["StartLimit"])
			QryDetails.LimitRows = utility.StrToInt64(formValue["LimitRows"])
			QryDetails.Schema = "guest_checkIn_checkOut"
			QryDetails.Columns = []string{"coll.id", "concat(gue.first_name,' ',gue.last_name) as guest_name", "from_unixtime(coll.timestamp,  GET_FORMAT(DATE,'JIS'))", "from_unixtime(coll.checkIn,  GET_FORMAT(DATE,'JIS'))", "from_unixtime(coll.checkout,  GET_FORMAT(DATE,'JIS'))", "coll.adult, coll.child", "room_type.name", "roomNo.room_no", "0 as 'empty'"}
			QryDetails.Middle_Condition = "time inner join reservation_payment pay on time.res_id=pay.resid && time.check_out=0 inner join reservation_collect coll on pay.resid = coll.id  inner join authentication  auth on coll.userid=auth.id && auth.hotel_id=" + hotel_id + " inner join reservation_guest gue on coll.guest_id=gue.id inner join roomNo on coll.room_no_id=roomNo.id inner join room_type on roomNo.room_type_id=room_type.room_type_id"
			//QryDetails.Condition ="coll.checkout="+today+""
			QryDetails.Condition = "1"

			data, err := Db.utility_model.GetPaginationRecords(QryDetails)

			if err != nil {
				log.Println(err)
			}
			if data.QueryDetails.AllRecords != 0 {
				response = utility.AjaxResponse{Status: "success", Data: data}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Data not available in the system"}
			}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func InsertTime(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "failure", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		now := time.Now().Unix()
		fields := make(map[string][]string)
		fields["required"] = []string{"Action", "ResId"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			var time models.GuestCheckInCheckOut
			time.ResId = utility.StrToInt64(formValue["ResId"])
			if formValue["Action"] == "Checked-In" {
				time.CheckIn = now
				done, _ := Db.guestCheckInCheckOut.InsertCheckIn(time)
				if done {
					response = utility.AjaxResponse{Status: "success", Data: "Guest " + utility.MysqlRealEscapeString(formValue["Action"]) + " successfully"}
				}
			} else if formValue["Action"] == "Checked-Out" {
				time.CheckOut = now
				done, _, count := Db.guestCheckInCheckOut.UpdateCheckOut(time)

				if done {
					if count != 0 {
						response = utility.AjaxResponse{Status: "success", Data: "Guest " + utility.MysqlRealEscapeString(formValue["Action"]) + " successfully !"}
					} else {
						response = utility.AjaxResponse{Status: "success", Data: "Guest Has Not checked-In !"}
					}
				}
			}

		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func Manage_ActiveRes(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"ResId"}

		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			log.Println(formValue["ResId"])
		}
	}
}

//Can delete Reservation which are not active with payment or CheckIn/Checkout
func DeleteReservationByID(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			if r.FormValue("reservationId") != "" {
				var reserv models.Reservation
				reserv.Res_Id = utility.StrToInt64(r.FormValue("reservationId"))
				Res_resp, err := Db.reservation.Delete_reservationdataById(reserv)
				if err != nil {
					log.Println(err)
					if driverErr, ok := err.(*mysql.MySQLError); ok {
						if driverErr.Number == 1451 {
							data := make(map[string]interface{})
							data["status"] = "err1451"
							json, _ := json.Marshal(data)
							w.Write([]byte(json))
						}
					}
				} else {
					if Res_resp {
						data := make(map[string]interface{})
						data["status"] = "success"
						json, _ := json.Marshal(data)
						w.Write([]byte(json))
					} else {
						data := make(map[string]interface{})
						data["status"] = "faliure"
						json, _ := json.Marshal(data)
						w.Write([]byte(json))
					}
				}
			}

		}
	}
}
