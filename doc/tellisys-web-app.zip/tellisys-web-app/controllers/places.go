package controllers

import (
	"encoding/json"
	"log"
	"net/http"
	"reakgo/utility"
)

func FetchCountry(w http.ResponseWriter, r *http.Request) {
	resp, CountryYN := Db.places.FetchAllCountry()
	data := make(map[string]interface{})
	if CountryYN == true {

		data["status"] = "success"
		data["country"] = resp

	} else {
		data["status"] = "faliure"
	}
	json, _ := json.Marshal(data)
	w.Write([]byte(json))
}

func FetchAllStates_name(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("countryId") != "" {
				Cid := utility.StrToInt64(r.FormValue("countryId"))
				resp, respYN := Db.places.GetAllStatesByCountry(Cid)
				data := make(map[string]interface{})
				if respYN == true {

					data["status"] = "success"
					data["state"] = resp

				} else {
					data["status"] = "faliure"
				}
				json, _ := json.Marshal(data)
				w.Write([]byte(json))
			}
		}
	}
}

func FetchAllCities_name(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("stateId") != "" {
				Sid := utility.StrToInt64(r.FormValue("stateId"))
				resp, CityYN := Db.places.FetchCities_name(Sid)
				data := make(map[string]interface{})
				if CityYN == true {

					data["status"] = "success"
					data["city"] = resp

				} else {
					data["status"] = "faliure"
				}
				json, _ := json.Marshal(data)
				w.Write([]byte(json))
			}
		}
	}
}
