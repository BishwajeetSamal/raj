package controllers

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"strconv"
)

func Inventory(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "pricingtimeline", nil)
}
func Inventory_timeline(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"fromDate", "ratePlan"}
		fields["other"] = []string{"toDate"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")

		if isValid {
			fromDate := utility.DateParser_unix(formValue["fromDate"])
			toDate := utility.DateParser_unix(formValue["toDate"])
			if fromDate != 0 && toDate != 0 {
				reservation_filter := models.Reservation{CheckIn: utility.SplitDate(formValue["fromDate"]), CheckOut: utility.SplitDate(formValue["toDate"])}
				dataRooms := Db.utility_model.Get_rooms_data(reservation_filter, "roomtypeonly", fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				dataPriceOfRooms, err := Db.roomprice.Inventory_price(reservation_filter, formValue["ratePlan"], fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				dataSystemGenRate := Db.utility_model.GetSystemSuggestedPrice(models.Reservation{CheckIn: formValue["fromDate"], CheckOut: formValue["toDate"]}, utility.SessionGet(r, "id").(string))
				var dataSystemSuggested interface{}
				if dataSystemGenRate["Status"] == "success" {
					dataSystemSuggested = dataSystemGenRate["Data"]
				}
				if err != nil {
					log.Println(err)
				}
				response = utility.AjaxResponse{Status: "success", Data: map[string]interface{}{"Rooms": dataRooms, "Price": dataPriceOfRooms, "SystemSuggested": dataSystemSuggested}}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Required filed are missing."}
			}
		} else {
			response = utility.AjaxResponse{Status: "failure", Data: "Required filed are missing."}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func Inventory_update(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "failure", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"RoomId", "TimeStamp", "Price"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			intRoomTypeid, err := strconv.Atoi(formValue["RoomId"])
			if err != nil {
				log.Println(err)
			}
			intRoomPrice, err := strconv.ParseFloat(formValue["Price"], 64)
			if err != nil {
				log.Println(err)
			}
			dataRequestPrice := models.RoomPrice{RoomTypeId: int64(intRoomTypeid), DateTimeTimeStamp: utility.DateParser_unix(formValue["TimeStamp"]), Price: float64(intRoomPrice), RatePlan: "Rack Rate"}
			isPriceChange, err := Db.roomprice.Inventory_price_set(dataRequestPrice)
			if err != nil {
				log.Println(err)
			}
			if isPriceChange {
				response = utility.AjaxResponse{Status: "success", Data: "Price update successfully"}
			}
		} else {
			response = utility.AjaxResponse{Status: "failure", Data: "Required filed are missing."}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}
