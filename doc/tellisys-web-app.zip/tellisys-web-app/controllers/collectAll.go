package controllers

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"strconv"
	"strings"
)

//Get index of Value inside Array
func indexOfArray(element string, data []string) int {
	for k, v := range data {
		if element == v {
			return k
		}
	}
	return -1 //not found.
}

// This func take data from ajax function return response in json
func AjaxforCollect(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("checkIn") != "" && r.FormValue("checkOut") != "" {
				var roomData1 []models.CollectAll
				fromDate_str := r.FormValue("checkIn")
				toDate_str := r.FormValue("checkOut")
				adult := utility.StrToInt64(r.FormValue("adult"))
				child := utility.StrToInt64(r.FormValue("children"))
				parts1 := strings.Split(fromDate_str, "-")
				parts2 := strings.Split(toDate_str, "-")
				day1, err := strconv.Atoi(parts1[2])
				if err != nil {
					day1 = 0
				}
				month1, err := strconv.Atoi(parts1[1])
				if err != nil {
					month1 = 0
				}
				year1, err := strconv.Atoi(parts1[0])
				if err != nil {
					year1 = 0
				}
				day2, err := strconv.Atoi(parts2[2])
				if err != nil {
					day2 = 0
				}
				month2, err := strconv.Atoi(parts2[1])
				if err != nil {
					month2 = 0
				}
				year2, err := strconv.Atoi(parts2[0])
				if err != nil {
					year2 = 0
				}

				t1 := utility.ReturnDaybyDate(year1, month1, day1)
				t2 := utility.ReturnDaybyDate(year2, month2, day2)
				days := t2.Sub(t1).Hours() / 24
				if days == 0 {
					days = 1
				}
				reservation_filter := models.Reservation{CheckIn: utility.SplitDate(r.FormValue("checkIn")), CheckOut: utility.SplitDate(r.FormValue("checkOut")), Adult: adult, Child: child}
				roomData := Db.collectAll.GetRoomsData()
				chk_reserveData := Db.collectAll.GetReservedData(reservation_filter)
				for _, Res_and_UnresData := range roomData {
					total_rooms := strings.Split(Res_and_UnresData.Room_nos, ",")

					for _, reservData := range chk_reserveData {
						if Res_and_UnresData.RoomTypeId == reservData.RoomTypeId {
							Res_and_UnresData.Totalrooms = Res_and_UnresData.Totalrooms - reservData.Reserv
							reserve_rooms := strings.Split(reservData.Room_nos, ",")

							for _, result := range reserve_rooms {
								final_indexRemove := indexOfArray(result, total_rooms)
								total_rooms = utility.RemoveIndex(total_rooms, final_indexRemove)
							}
						}
					}
					Res_and_UnresData.Room_nos1 = total_rooms
					roomData1 = append(roomData1, Res_and_UnresData)
				}
				if err != nil {
					log.Println(err)
				} else {
					// using for loop
					for index := range roomData {
						roomData1[index].Total = int64(days) * (roomData[index].Base_price)
						// room taxes
					}
				}

				UserSetting := Db.usersetting.GetSettings(fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				data := make(map[string]interface{}) //here inertface is used for every type of data to accept or it is to club all types of data
				data["status"] = "success"
				data["val"] = roomData1
				data["taxes"] = UserSetting
				json, _ := json.Marshal(data)
				w.Write([]byte(json))
			}
		}
	}
}
