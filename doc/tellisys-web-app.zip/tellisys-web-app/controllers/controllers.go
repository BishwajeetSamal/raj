package controllers

import (
	"database/sql"
	"reakgo/models"
	"reakgo/utility"
)

type Env struct {
	authentication interface {
		GetUserByEmail(email string) (models.Authentication, error)
		CheckExistEmail(email string) (bool, error)
		ForgotPassword(id int64) (string, error)
		TokenVerify(email string, token string, newPassword string) (bool, bool, error)
		CheckStatus(email string, token string) int64
		GenTokenForVerification(id int64) (string, error)
		InsertDatatoAuthTable(insert_for_register models.Authentication, tx *sql.Tx) (bool, int64, error)
		InsertUserPlaceData(insert_for_register models.Authentication, tx *sql.Tx) (bool, error)
		GetUserPlace(id int) (models.UserPlace, error)
		DelAuthandUserPlace(user_id int64) bool
	}
	utility_model interface {
		GetPaginationRecords(models.QueryDetails) (models.ResponsePagination, error)
		Get_rooms_data(models.Reservation, string, string) []models.RoomTypeExtra
		GetSystemSuggestedPrice(models.Reservation, string) map[string]interface{}
		CountAll(string) models.AssginUnassignRoom
		CalculateReservationToday(time int64, hotel_id int64) (int64, error)
		CalculateTotalRooms(hotel_id int64) (int64, error)
		CalculateGuestArrival(time int64, hotel_id int64) (int64, error)
		CalculateGuestDeparture(time int64, hotel_id int64) (int64, error)
	}

	roomprice interface {
		Inventory_price(models.Reservation, string, string) ([]models.RoomPrice, error)
		Inventory_price_set(models.RoomPrice) (bool, error)
	}
	reservation interface {
		InsertUserCollectData(tx *sql.Tx, register models.Reservation) (bool, int64, error)
		FetchPriceData(collectId int64) (models.ReservationAndTax, error)
		CheckExistEmailforGuest(email string) (int64, bool)
		GetAllDataFinal(res_id string, log_id string) (models.CollectAll, error)
		UpdateCollect_guestId(gesId int64, resId int64, tx *sql.Tx) bool
		Reservation_timeline(models.Reservation) []models.RoomTypeExtra
		AssignUnassignRoom(models.Reservation, bool) []models.AssginUnassignRoom
		GetDataCollectEdit(resId int64) (models.Reservation, error)
		UpdateUserCollectData(updateData models.Reservation) bool
		Delete_reservationdataById(res models.Reservation) (bool, error)
	}
	guest_reservation interface {
		InsertGuestInfo(guestData models.Guest_reservation) (int64, bool)
		SearchGuestData(search_guest models.Guest_reservation) ([]models.Guest_reservation, error)
		Get_guest_dataById(guest_id string) ([]models.Guest_reservation, error)
		InsertAdditionalname(guestaddData models.Guest_reservation, tx *sql.Tx) bool
		GetEdit_GuestDataById(resId models.Guest_reservation) ([]models.Get_guestinfo, error)
		UpdateGuestInfo(updateGuest models.Get_guestinfo, tx *sql.Tx) bool
		DeleteNamesandInsertForUpdate(addNames models.Guest_reservation) bool
		InsertGuestFromList(guestData models.Guest_reservation) bool
		UpdateGuestIndivdual(guestData models.Guest_reservation) bool
		Delete_guest_dataById(guest models.Guest_reservation) (bool, error)
		Get_guest_dataByResId(string) string
	}
	payment interface {
		InsertCash(payment models.Payments, tx *sql.Tx) bool
		UpdateCollect_dueDepo(payment models.Payments, tx *sql.Tx) bool
	}
	collectAll interface {
		GetRoomsData() []models.CollectAll
		GetReservedData(reservation_filter models.Reservation) []models.CollectAll
	}

	roomType interface {
		InsertRoomType(tx *sql.Tx, room_type models.RoomType) (int64, error)
		FetchRoomType(id int64) (models.RoomTypeData, error)
		UpdateRoomType(tx *sql.Tx, room_type models.RoomType) (bool, error)
	}
	bed interface {
		InsertBed(tx *sql.Tx, bed models.Bed) (bool, error)
	}
	room interface {
		InsertRoom(tx *sql.Tx, room models.Room) (bool, error)
	}
	roomNo interface {
		InsertRoomNo(tx *sql.Tx, roomNo models.RoomNo) (bool, error)
	}
	image interface {
		InsertImage(tx *sql.Tx, image models.Image) (bool, error)
	}
	hotels interface {
		InsertHotel(tx *sql.Tx, hotel models.Hotels) (int64, error)
		FetchHotel(user_id int64) (models.Hotel, error)
		UpdateHotel(tx *sql.Tx, hotel models.Hotels) (bool, error)
		UpdateHotelIdtoAuth(tx *sql.Tx, userId int64, hotelId int64) bool
	}
	highTrafficMonth interface {
		InsertHighTrafficMonth(tx *sql.Tx, months models.HighTrafficMonth) (bool, error)
		DeleteHighTrafficMonth(tx *sql.Tx, hotel_id int64) (bool, error)
	}
	invoice interface {
		InsertInvoiceData(*sql.Tx, models.Invoice) (bool, int64)
		DeleteInvoiceData(*sql.Tx, models.Invoice) bool
		UpdateInvoiceData(*sql.Tx, models.Invoice) bool
		GetInvoiceTable_data(models.Invoice) ([]models.Invoice, error)
		Final_InvoiceData(models.FinalInvoiceStruct) ([]models.FinalInvoiceStruct, error)
	}
	guestCheckInCheckOut interface {
		InsertCheckIn(time models.GuestCheckInCheckOut) (bool, error)
		UpdateCheckOut(time models.GuestCheckInCheckOut) (bool, error, int64)
	}
	places interface {
		FetchAllCountry() ([]models.Places, bool)
		GetAllStatesByCountry(countryId int64) ([]models.Places, bool)
		FetchCities_name(stateId int64) ([]models.Places, bool)
	}
	usersetting interface {
		GetSettings(string) models.UserSetting
		SetSettings(string, string, int64) bool
	}
	taxes interface {
		GetTaxOfUser(string) models.TAX
		SetRoomTax(*sql.Tx, int64, int64, float64, float64) bool
		SetRoomServiceTax(*sql.Tx, int64, int64, float64, float64) bool
		SetVATTax(*sql.Tx, int64, float64, float64) bool
		GetRoomTax(string) models.RoomTax
		GetVATTax(string) models.VATTax
		RemoveTax(*sql.Tx, int64, string) bool
	}
}

var Db *Env

func init() {
	Db = &Env{
		authentication:       models.AuthenticationModel{DB: utility.Db},
		roomprice:            models.RoomPriceModel{DB: utility.Db},
		utility_model:        models.UtilityModel{DB: utility.Db},
		roomType:             models.RoomTypeModel{DB: utility.Db},
		bed:                  models.BedModel{DB: utility.Db},
		room:                 models.RoomModel{DB: utility.Db},
		roomNo:               models.RoomNoModel{DB: utility.Db},
		image:                models.ImageModel{DB: utility.Db},
		reservation:          models.ReservationModel{DB: utility.Db},
		guest_reservation:    models.Guest_ReservationModel{DB: utility.Db},
		payment:              models.PaymentModel{DB: utility.Db},
		collectAll:           models.CollectAllModel{DB: utility.Db},
		hotels:               models.HotelsModel{DB: utility.Db},
		highTrafficMonth:     models.HighTrafficMonthModel{DB: utility.Db},
		invoice:              models.InvoiceModel{DB: utility.Db},
		guestCheckInCheckOut: models.GuestCheckInCheckOutModel{DB: utility.Db},
		places:               models.PlacesModel{DB: utility.Db},
		usersetting:          models.UserSettingModel{DB: utility.Db},
		taxes:                models.TaxesModel{DB: utility.Db},
	}
}
