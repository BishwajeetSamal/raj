package controllers

import (
	"database/sql"
	"encoding/json"
	"log"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"strings"

	"github.com/go-sql-driver/mysql"
)

func RenderReservation_guest(w http.ResponseWriter, r *http.Request) {
	res_id := r.URL.Query().Get("id")
	utility.RenderTemplate(w, r, "reservation_guest", res_id)
}

func Guest_list(w http.ResponseWriter, r *http.Request) {
	utility.RenderTemplate(w, r, "guest_list", nil)
}

func AjaxSaveforGuest(w http.ResponseWriter, r *http.Request) {
	var guest_data models.Guest_reservation
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			tx, err := utility.Db.Begin()
			if err != nil {
				log.Println(err)
			} else {
				if r.FormValue("email") != "" && r.FormValue("getPayType") != "" {
					guest_data.First_name = r.FormValue("fname")
					guest_data.Last_name = r.FormValue("lname")
					guest_data.Email = r.FormValue("email")
					guest_data.Phone = sql.NullString{String: r.FormValue("phone"), Valid: r.FormValue("phone") != ""}
					guest_data.Address = sql.NullString{String: r.FormValue("address"), Valid: r.FormValue("address") != ""}
					guest_data.City = sql.NullString{String: r.FormValue("city"), Valid: r.FormValue("city") != ""}
					guest_data.State = sql.NullString{String: r.FormValue("state"), Valid: r.FormValue("state") != ""}
					guest_data.Country = sql.NullString{String: r.FormValue("country"), Valid: r.FormValue("country") != ""}
					guest_data.Zip_code = sql.NullInt64{Int64: utility.StrToInt64(r.FormValue("zip_code")), Valid: r.FormValue("zip_code") != ""}
					guest_data.User_id = r.FormValue("user_id")
					addGuestLength := utility.StrToInt64(r.FormValue("length_of_extraG"))
					reservation_id := utility.StrToInt64(r.FormValue("reservation_id"))
					//This code is resposible to update guestId to the reservation_collect table if guest is already present
					//and if extra guest are present then InsertAddName(w, r) will insert data
					guest_tableid, auth := Db.reservation.CheckExistEmailforGuest(guest_data.Email)
					// auth over here will be true if email already existed else contain false
					if auth {
						resp1 := Db.reservation.UpdateCollect_guestId(guest_tableid, reservation_id, tx)
						if addGuestLength > 0 {
							res1 := InsertAddName(w, r, guest_tableid, tx) //This func here works to add extra names related to the guest already existed
							if !res1 {
								tx.Rollback()
							}
						}
						payment1 := AddPaymentData(w, r, tx)

						if !resp1 && !payment1 {
							tx.Rollback()
						} else {
							err = tx.Commit()
							if err != nil {
								log.Println(err)
							} else {
								data := make(map[string]string)
								data["status"] = "success"
								json, _ := json.Marshal(data)
								w.Write([]byte(json))
							}
						}

					} else {
						//This else run if new email found
						respId, isTrue := Db.guest_reservation.InsertGuestInfo(guest_data)
						if addGuestLength > 0 {
							res2 := InsertAddName(w, r, respId, tx) //This func here works to add extra names related to the newly inserted guest
							if !res2 {
								tx.Rollback()
							}
						}
						resp3 := Db.reservation.UpdateCollect_guestId(respId, reservation_id, tx)
						payment2 := AddPaymentData(w, r, tx)
						if !isTrue && !payment2 && !resp3 {
							tx.Rollback()
						} else {
							err = tx.Commit()
							if err != nil {
								log.Println(err)
							} else {
								data := make(map[string]string)
								data["status"] = "success"
								json, _ := json.Marshal(data)
								w.Write([]byte(json))
							}
						}
					}
				}
			}
		}
	}
}

func AjaxSearchGuest(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			var split_data models.Guest_reservation
			if r.FormValue("guest_name") != "" {
				Split_search_name := strings.Split(r.FormValue("guest_name"), " ")
				if strings.Contains(r.FormValue("guest_name"), " ") {
					split_data.F_name = Split_search_name[0]
					split_data.L_name = Split_search_name[1]
				} else {
					split_data.F_name = Split_search_name[0]
					split_data.L_name = " "
				}

				resp, err := Db.guest_reservation.SearchGuestData(split_data)
				if err != nil {
					log.Println(err)
				} else {
					data := make(map[string]interface{})
					data["status"] = "success"
					data["guestName_resp"] = resp
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				}
			}
		}
	}
}

func GuestDataById(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("guest_Id") != "" {

				resp, err := Db.guest_reservation.Get_guest_dataById(r.FormValue("guest_Id"))
				if err != nil {
					log.Println(err)
				} else {
					if resp[0].Id != 0 {
						data := make(map[string]interface{})
						data["status"] = "success"
						data["guestData_resp"] = resp
						json, _ := json.Marshal(data)
						w.Write([]byte(json))
					} else {
						data := make(map[string]string)
						data["status"] = "faliure"
						json, _ := json.Marshal(data)
						w.Write([]byte(json))
					}

				}
			} else {
				data := make(map[string]string)
				data["status"] = "faliure"
				json, _ := json.Marshal(data)
				w.Write([]byte(json))
			}
		}
	}
}

//func to save additional guest names
func InsertAddName(w http.ResponseWriter, r *http.Request, Guest_id int64, tx *sql.Tx) bool {
	var guest_add_data models.Guest_reservation
	if r.Method == "POST" {
		err := r.ParseForm()

		if err != nil {
			utility.RenderTemplate(w, r, "error_server", nil)
		} else {
			if err != nil {
				log.Println(err)
			} else {
				if Guest_id == 0 {
					data := make(map[string]string)
					data["status"] = "faliure"
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				} else {
					var extra_name []models.AddName
					json.Unmarshal([]byte(r.Form["extra_name"][0]), &extra_name)
					reservation_id := utility.StrToInt64(r.FormValue("reservation_id"))
					for index, name := range extra_name {
						guest_add_data.F_name = name.Fname
						guest_add_data.L_name = name.LName
						guest_add_data.Guest_id = Guest_id
						guest_add_data.Res_Id = reservation_id
						isInserted := Db.guest_reservation.InsertAdditionalname(guest_add_data, tx)
						if !isInserted {
							return false
						}
						if index == (len(extra_name) - 1) {
							return true
						}
					}
				}
			}
		}
	}
	return false
}

func RenderEdit_guest(w http.ResponseWriter, r *http.Request) {
	guest := r.URL.Query().Get("guest")
	id := r.URL.Query().Get("id")
	if guest != "" {
		guest = guest + "-guest"
		utility.RenderTemplate(w, r, "edit_guest", guest)
	} else {
		if id != "" {
			id = id + "-reservation"
			utility.RenderTemplate(w, r, "edit_guest", id)
		}
	}
}

func GetEdit_guestAllData(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {

		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("res_id") != "" {
				var sendResId models.Guest_reservation
				sendResId.Res_Id = utility.StrToInt64(r.FormValue("res_id"))
				guestResp, err := Db.guest_reservation.GetEdit_GuestDataById(sendResId)
				if err == nil {
					data := make(map[string]interface{})
					data["status"] = "success"
					data["guestData"] = guestResp
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				}
			}

		}
	}
}

func UpdateEditGuestbyAjax(w http.ResponseWriter, r *http.Request) {
	var edit_guest models.Get_guestinfo
	var guest_add_data models.Guest_reservation
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			tx, err := utility.Db.Begin()
			if err != nil {
				log.Println(err)
			} else {
				if r.FormValue("email") != "" {
					edit_guest.First_name = r.FormValue("fname")
					edit_guest.Last_name = r.FormValue("lname")
					edit_guest.Email = r.FormValue("email")
					edit_guest.Phone = sql.NullString{String: r.FormValue("phone"), Valid: r.FormValue("phone") != ""}
					edit_guest.Address = sql.NullString{String: r.FormValue("address"), Valid: r.FormValue("address") != ""}
					edit_guest.City = sql.NullString{String: r.FormValue("city"), Valid: r.FormValue("city") != ""}
					edit_guest.State = sql.NullString{String: r.FormValue("state"), Valid: r.FormValue("state") != ""}
					edit_guest.Country = sql.NullString{String: r.FormValue("country"), Valid: r.FormValue("country") != ""}
					edit_guest.Zip_code = sql.NullInt64{Int64: utility.StrToInt64(r.FormValue("zip_code")), Valid: r.FormValue("zip_code") != ""}
					edit_guest.User_id = r.FormValue("user_id")
					addGuestLength := utility.StrToInt64(r.FormValue("length_of_extraG"))
					edit_guest.Reservation_Id = utility.StrToInt64(r.FormValue("reservation_id"))
					edit_guest.GuestId = utility.StrToInt64(r.FormValue("guest_id"))
					update_successBool := Db.guest_reservation.UpdateGuestInfo(edit_guest, tx)
					var extra_name []models.AddName
					json.Unmarshal([]byte(r.Form["extra_name"][0]), &extra_name)
					guest_add_data.Guest_id = utility.StrToInt64(r.FormValue("guest_id"))
					guest_add_data.Res_Id = utility.StrToInt64(r.FormValue("reservation_id"))
					Delete_addGuest := Db.guest_reservation.DeleteNamesandInsertForUpdate(guest_add_data)
					if Delete_addGuest {
						if addGuestLength > 0 {
							for _, name := range extra_name {
								guest_add_data.F_name = name.Fname
								guest_add_data.L_name = name.LName
								update_addGuest := Db.guest_reservation.InsertAdditionalname(guest_add_data, tx)
								if !update_addGuest {
									tx.Rollback()
								}
							}
						}
					}
					if !update_successBool {
						tx.Rollback()
					} else {
						err = tx.Commit()
						if err != nil {
							log.Println(err)
						} else {
							data := make(map[string]string)
							data["status"] = "success"
							json, _ := json.Marshal(data)
							w.Write([]byte(json))
						}
					}
				}
			}
		}
	}
}

func Get_allGuests(w http.ResponseWriter, r *http.Request) {
	response := utility.AjaxResponse{Status: "critical", Data: "Something went wrong, Please try again"}
	if r.Method == "POST" {
		fields := make(map[string][]string)
		fields["required"] = []string{"StartLimit", "LimitRows"}
		// fields["other"] = []string{"toDate"}
		formValue, isValid := utility.CheckFormValidation(r, fields, "")
		if isValid {
			var QryDetails models.QueryDetails

			QryDetails.StartLimit = utility.StrToInt64(formValue["StartLimit"])
			QryDetails.LimitRows = utility.StrToInt64(formValue["LimitRows"])
			QryDetails.Schema = "reservation_guest"
			QryDetails.Columns = []string{"id", "first_name", "last_name", "email", "phone", "address", "city", "state", "country", "zip_code"}
			QryDetails.Middle_Condition = ""
			QryDetails.Condition = "1"

			data, err := Db.utility_model.GetPaginationRecords(QryDetails)
			if err != nil {
				log.Println(err)
			}
			if data.QueryDetails.AllRecords != 0 {
				response = utility.AjaxResponse{Status: "success", Data: data}
			} else {
				response = utility.AjaxResponse{Status: "failure", Data: "Data not available in the system"}
			}
		}
	}
	encodingJson, err := json.Marshal(response)
	if err != nil {
		log.Println(err)
	}
	w.Write([]byte(encodingJson))
}

func InsertGuestOnly(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {

		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("fname") != "" || r.FormValue("lname") != "" || r.FormValue("email") != "" {
				var guest models.Guest_reservation
				guest.First_name = r.FormValue("fname")
				guest.Last_name = r.FormValue("lname")
				guest.Email = r.FormValue("email")
				guest.Phone = sql.NullString{String: r.FormValue("phone"), Valid: r.FormValue("phone") != ""}
				guest.Address = sql.NullString{String: r.FormValue("address"), Valid: r.FormValue("address") != ""}
				guest.City = sql.NullString{String: r.FormValue("city"), Valid: r.FormValue("city") != ""}
				guest.State = sql.NullString{String: r.FormValue("state"), Valid: r.FormValue("state") != ""}
				guest.Country = sql.NullString{String: r.FormValue("country"), Valid: r.FormValue("country") != ""}
				guest.Zip_code = sql.NullInt64{Int64: utility.StrToInt64(r.FormValue("zip_code")), Valid: r.FormValue("zip_code") != ""}
				guest.User_id = r.FormValue("user_id")
				guestResp := Db.guest_reservation.InsertGuestFromList(guest)
				if guestResp {
					data := make(map[string]interface{})
					data["status"] = "success"
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				}
			}
		}
	}
}

func FetchGuestByGuestId(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {

		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("guestId") != "" {
				Guest_id := r.FormValue("guestId")
				guestResp, err := Db.guest_reservation.Get_guest_dataById(Guest_id)
				if err == nil {
					data := make(map[string]interface{})
					data["status"] = "success"
					data["guestData"] = guestResp
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				}
			}

		}
	}
}

func UpdateGuestOnly(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("fname") != "" || r.FormValue("lname") != "" || r.FormValue("email") != "" {
				var guest models.Guest_reservation
				guest.Guest_id = utility.StrToInt64(r.FormValue("guest_Id"))
				guest.First_name = r.FormValue("fname")
				guest.Last_name = r.FormValue("lname")
				guest.Email = r.FormValue("email")
				guest.Phone = sql.NullString{String: r.FormValue("phone"), Valid: r.FormValue("phone") != ""}
				guest.Address = sql.NullString{String: r.FormValue("address"), Valid: r.FormValue("address") != ""}
				guest.City = sql.NullString{String: r.FormValue("city"), Valid: r.FormValue("city") != ""}
				guest.State = sql.NullString{String: r.FormValue("state"), Valid: r.FormValue("state") != ""}
				guest.Country = sql.NullString{String: r.FormValue("country"), Valid: r.FormValue("country") != ""}
				guest.Zip_code = sql.NullInt64{Int64: utility.StrToInt64(r.FormValue("zip_code")), Valid: r.FormValue("zip_code") != ""}
				guest.User_id = r.FormValue("user_id")
				guestResp := Db.guest_reservation.UpdateGuestIndivdual(guest)
				if guestResp {
					data := make(map[string]interface{})
					data["status"] = "success"
					json, _ := json.Marshal(data)
					w.Write([]byte(json))
				}
			}
		}
	}
}

//Can delete Guest which are not included/binded with reservation
func DeleteGuestOnly(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		if err != nil {
			log.Println(err)
		} else {
			if r.FormValue("guestId") != "" {
				var guest models.Guest_reservation
				guest.Guest_id = utility.StrToInt64(r.FormValue("guestId"))
				guestResp, err := Db.guest_reservation.Delete_guest_dataById(guest)
				if err != nil {
					log.Println(err)
					if driverErr, ok := err.(*mysql.MySQLError); ok {
						if driverErr.Number == 1451 {
							data := make(map[string]interface{})
							data["status"] = "err1451"
							json, _ := json.Marshal(data)
							w.Write([]byte(json))
						}
					}
				} else {
					if guestResp {
						data := make(map[string]interface{})
						data["status"] = "success"
						json, _ := json.Marshal(data)
						w.Write([]byte(json))
					} else {
						data := make(map[string]interface{})
						data["status"] = "faliure"
						json, _ := json.Marshal(data)
						w.Write([]byte(json))
					}
				}
			}

		}
	}
}
