package controllers

import (
	"database/sql"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"time"
)

//func to save payment details
func AddPaymentData(w http.ResponseWriter, r *http.Request, tx *sql.Tx) bool {
	var payment models.Payments
	if r.FormValue("reservation_id") != "" && r.FormValue("due_deposit") != "" {
		payment.PaymentType = r.FormValue("getPayType")
		CashPayDate := utility.DateParser_unix(r.FormValue("cash_date"))
		payment.CashPayDate = sql.NullInt64{Int64: CashPayDate, Valid: CashPayDate != 0}
		TransactionDate := utility.DateParser_unix(r.FormValue("bank_transc_date"))
		payment.TransactionDate = sql.NullInt64{Int64: TransactionDate, Valid: TransactionDate != 0}
		payment.TransactionId = sql.NullString{String: r.FormValue("transaction_id"), Valid: r.FormValue("transaction_id") != ""}
		payment.ResId = utility.StrToInt64(r.FormValue("reservation_id"))
		payment.Curr_timestamp = time.Now().Unix()
		resp := Db.payment.InsertCash(payment, tx)
		if resp {
			payment.Due_deposit = r.FormValue("due_deposit")

			updated_Resp := Db.payment.UpdateCollect_dueDepo(payment, tx)
			if updated_Resp {
				return updated_Resp
			}
		} else {
			return false
		}
	}
	return false
}
