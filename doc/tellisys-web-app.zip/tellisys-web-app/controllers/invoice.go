package controllers

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net/http"
	"reakgo/models"
	"reakgo/utility"
	"strconv"
	"time"
)

func RenderReservation_invoice(w http.ResponseWriter, r *http.Request) {
	res_id := r.URL.Query().Get("id")
	data := make(map[string]string)
	data["res_id"] = res_id
	data["bookingNo"] = fmt.Sprintf("%v", utility.SessionGet(r, "id")) + " R" + res_id
	data["bookingName"] = Db.guest_reservation.Get_guest_dataByResId(res_id)
	data["dateofPrint"] = time.Now().Format("2006-01-02")
	utility.RenderTemplate(w, r, "reservation_invoice", data)
}

func RenderEditable_invoice(w http.ResponseWriter, r *http.Request) {
	res_id := r.URL.Query().Get("id")
	data := make(map[string]string)
	data["res_id"] = res_id
	data["bookingNo"] = fmt.Sprintf("%v", utility.SessionGet(r, "id")) + " R" + res_id
	data["bookingName"] = Db.guest_reservation.Get_guest_dataByResId(res_id)
	utility.RenderTemplate(w, r, "editable_invoice", data)
}

func FinalInvoiceWithService(w http.ResponseWriter, r *http.Request) {
	var response []models.Invoice
	var invoicerowData models.Invoice
	var totalSum float64
	if r.Method == "POST" {
		err := r.ParseForm()
		data := make(map[string]interface{})
		if err != nil {
			log.Println(err)
			data["status"] = "faliure"
		} else {
			if r.FormValue("resid") != "" {
				invoicerowData.Res_id = utility.StrToInt64(r.FormValue("resid"))
				resp, err := Db.invoice.GetInvoiceTable_data(invoicerowData)
				if err != nil {
					log.Println(err)
				}
				log_id := fmt.Sprintf("%v", utility.SessionGet(r, "id"))
				response_data := GetReservationData(r.FormValue("resid"), log_id)
				TAXes := Db.usersetting.GetSettings(fmt.Sprintf("%v", utility.SessionGet(r, "id")))

				getdata, err := Db.reservation.GetAllDataFinal(r.FormValue("resid"), log_id)
				if err != nil {
					log.Println(err)
				}
				Room_ch, err := strconv.ParseFloat(getdata.Room_charges, 64)
				if err != nil {
					log.Println(err)
				} else {
					room_tax := Db.taxes.GetRoomTax(r.FormValue("resid"))

					if err != nil {
						log.Println(err)
						data["status"] = "faliure"
					} else {
						for _, data := range resp {
							response = append(response, data)
							totalSum = totalSum + data.Total_price
						}
						tx, err := utility.Db.Begin()
						if err != nil {
							log.Println(err)
						}
						ratetotal := Room_ch + totalSum + room_tax.RoomTax1 + room_tax.RoomTax2
						VATTax1 := utility.TaxCalculation(ratetotal, TAXes.VATTax1)
						VATTax2 := utility.TaxCalculation(ratetotal, TAXes.VATTax2)
						statusVATTax := Db.taxes.SetVATTax(tx, invoicerowData.Res_id, VATTax1, VATTax2)
						if statusVATTax {
							tx.Commit()
						}
						data["status"] = "success"
						data["invoice"] = response
						data["data"] = response_data
						data["taxpercent"] = TAXes
						data["VATTax1"] = math.Floor(VATTax1*100) / 100
						data["VATTax2"] = math.Floor(VATTax2*100) / 100
						data["totalSum"] = math.Floor(totalSum*100) / 100
					}
				}
			}
			json, _ := json.Marshal(data)
			w.Write([]byte(json))
		}
	}
}

func FetchInvoiceData(w http.ResponseWriter, r *http.Request) {
	var response []models.Invoice
	var invoicerowData models.Invoice
	var totalSum float64
	if r.Method == "POST" {
		err := r.ParseForm()
		data := make(map[string]interface{})
		if err != nil {
			log.Println(err)
			data["status"] = "faliure"
		} else {
			if r.FormValue("res_id") != "" {
				invoicerowData.Res_id = utility.StrToInt64(r.FormValue("res_id"))
				resp, err := Db.invoice.GetInvoiceTable_data(invoicerowData)
				if err != nil {
					log.Println(err)
					data["status"] = "faliure"
				} else {
					for _, data := range resp {
						response = append(response, data)
						totalSum = totalSum + data.Total_price
					}
					data["status"] = "success"
					data["getData"] = response
					data["totalSum"] = math.Floor(totalSum*100) / 100
				}
			}
		}
		json, _ := json.Marshal(data)
		w.Write([]byte(json))
	}
}

//SaveInvoiceTable is function to save data into invoice_table
func SaveInvoiceTable(w http.ResponseWriter, r *http.Request) {
	var invoicerowData models.Invoice
	if r.Method == "POST" {
		err := r.ParseForm()
		data := make(map[string]string)
		if err != nil {
			log.Println(err)
			data["status"] = "faliure"
		} else {
			if r.FormValue("invoice_item") != "" {
				//taxes setting data
				taxData := Db.usersetting.GetSettings(fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				invoicerowData.Items = r.FormValue("invoice_item")
				invoicerowData.Quantity = utility.StrToInt64(r.FormValue("invoice_quantity"))
				invoicerowData.Unit_price = utility.StrToFloat64(r.FormValue("invoice_unitPrice"))
				Total_price := math.Floor((float64(invoicerowData.Quantity) * invoicerowData.Unit_price))
				RoomServiceTax1 := utility.TaxCalculation(Total_price, taxData.RoomServiceTax1)
				RoomServiceTax2 := utility.TaxCalculation(Total_price, taxData.RoomServiceTax2)
				invoicerowData.Total_price = Total_price + RoomServiceTax1 + RoomServiceTax2
				invoicerowData.Res_id = utility.StrToInt64(r.FormValue("res_Id"))
				time_timestamp := time.Now().Unix()
				invoicerowData.Time = time_timestamp
				tx, err := utility.Db.Begin()
				if err != nil {
					log.Println(err)
				}
				// room service add
				resp, lastId := Db.invoice.InsertInvoiceData(tx, invoicerowData)
				// room service tax add
				data["status"] = "faliure"
				resp_of_service := Db.taxes.SetRoomServiceTax(tx, invoicerowData.Res_id, lastId, RoomServiceTax1, RoomServiceTax2)
				if resp && resp_of_service {
					err = tx.Commit()
					if err != nil {
						log.Println(err)
					} else {
						data["status"] = "success"
					}
				} else {
					tx.Rollback()
				}
			}
		}
		json, _ := json.Marshal(data)
		w.Write([]byte(json))
	}
}

//Update Invoice data bu Id
func UpdateInvoiceTable(w http.ResponseWriter, r *http.Request) {
	var updateInvoice models.Invoice
	if r.Method == "POST" {
		err := r.ParseForm()
		data := make(map[string]string)
		if err != nil {
			log.Println(err)
			data["status"] = "faliure"
		} else {
			if r.FormValue("invoice_item") != "" {
				taxData := Db.usersetting.GetSettings(fmt.Sprintf("%v", utility.SessionGet(r, "id")))
				updateInvoice.InvId = utility.StrToInt64(r.FormValue("id"))
				updateInvoice.Items = r.FormValue("invoice_item")
				updateInvoice.Quantity = utility.StrToInt64(r.FormValue("invoice_quantity"))
				updateInvoice.Unit_price, _ = strconv.ParseFloat(r.FormValue("invoice_unitPrice"), 64)
				Total_price := math.Floor((float64(updateInvoice.Quantity) * updateInvoice.Unit_price))
				RoomServiceTax1 := utility.TaxCalculation(Total_price, taxData.RoomServiceTax1)
				RoomServiceTax2 := utility.TaxCalculation(Total_price, taxData.RoomServiceTax2)
				updateInvoice.Total_price = Total_price + RoomServiceTax1 + RoomServiceTax2
				time_timestamp := time.Now().Unix()
				updateInvoice.Time = time_timestamp
				tx, err := utility.Db.Begin()
				if err != nil {
					log.Println(err)
				}
				resp := Db.invoice.UpdateInvoiceData(tx, updateInvoice)
				data["status"] = "faliure"
				resp_of_service := Db.taxes.SetRoomServiceTax(tx, 0, updateInvoice.InvId, RoomServiceTax1, RoomServiceTax2)
				if resp && resp_of_service {
					err = tx.Commit()
					if err != nil {
						log.Println(err)
					} else {
						data["status"] = "success"
					}
				} else {
					tx.Rollback()
				}
			}
		}
		json, _ := json.Marshal(data)
		w.Write([]byte(json))
	}
}

//DeleteInvoiceTable is function to delete data from invoice_table by Invoice Id
func DeleteInvoiceTable(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseForm()
		data := make(map[string]string)
		if err != nil {
			log.Println(err)
			data["status"] = "faliure"
		} else {
			if r.FormValue("invoice_id") != "" {
				var invoiceId models.Invoice
				invoiceId.InvId = utility.StrToInt64(r.FormValue("invoice_id"))
				tx, err := utility.Db.Begin()
				if err != nil {
					log.Println(err)
				}
				resp := Db.invoice.DeleteInvoiceData(tx, invoiceId)
				data["status"] = "faliure"
				resp_of_service := Db.taxes.RemoveTax(tx, invoiceId.InvId, "service")
				if resp && resp_of_service {
					err = tx.Commit()
					if err != nil {
						log.Println(err)
					} else {
						data["status"] = "success"
					}
				} else {
					tx.Rollback()
				}
			}
		}
		json, _ := json.Marshal(data)
		w.Write([]byte(json))
	}
}
