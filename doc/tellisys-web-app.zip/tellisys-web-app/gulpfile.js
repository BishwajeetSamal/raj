const { src, dest, series, parallel, watch } = require("gulp");

const concat = require("gulp-concat");
const del = require("del");
const { pipeline } = require("readable-stream");

const fileinclude = require("gulp-file-include");

const sourcemaps = require("gulp-sourcemaps");

const postcss = require("gulp-postcss");
const postcssImport = require("postcss-import");
const tailwindcss = require("tailwindcss");
const tailwindConfig = require("./tailwind.config");
const postcssNested = require("postcss-nested");
const postcssCustomProperties = require("postcss-custom-properties");
const autoprefixer = require("autoprefixer");
const cleanCSS = require("gulp-clean-css");

const uglify = require("gulp-uglify-es").default;

const browserSync = require("browser-sync").create();

// Paths
const paths = {
  src: "html-src/",
  dest: "html-dev/",
  destProd: "assets/",
  html: {
    src: "html-src/*.html",
    dest: "templates/",
    destDev: "html-dev/",
  },
  css: {
    src: "html-src/assets/css/",
    dest: "assets/css/",
    destDev: "html-dev/assets/css"
  },
  cssExtra: {
    src: [
      "./node_modules/notifier-js/css/notifier.css",
      "./node_modules/filepond/dist/filepond.min.css",
      "./node_modules/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css",
      "./node_modules/datatables/media/css/jquery.dataTables.min.css",
      "./node_modules/drmonty-datatables-responsive/css/dataTables.responsive.min.css",
    ],
    dest: "assets/css/",
    destDev: "html-dev/assets/css"
  },
  js: {
    src: "html-src/assets/js/**/*.js",
    dest: "assets/js/",
    destDev: "html-dev/assets/js/",
  },
  images: {
    src: "html-src/assets/images/**/*",
    dest: "assets/images/",
    destDev: "html-dev/assets/images/",
  },
  fonts: {
    src: "html-src/assets/fonts/**/*",
    dest: "assets/fonts/",
    destDev: "html-dev/assets/fonts/",
  },
};

// HTML
const html = () => {
  return src([paths.html.src, "!html-src/partials/**/*.html"])
    .pipe(
      fileinclude({
        prefix: "@@",
        basepath: "@file",
        indent: true,
      })
    )
    .pipe(dest(paths.html.dest))
    .pipe(browserSync.stream());
};

//HTML Dev Build
const htmlDev = () => {
  return src([paths.html.src, "!html-src/partials/**/*.html"])
    .pipe(
      fileinclude({
        prefix: "@@",
        basepath: "@file",
        indent: true,
      })
    )
    .pipe(dest(paths.html.destDev))
    .pipe(browserSync.stream());
};

// CSS
const css = () => {
  return src(paths.css.src + "style.css")
    .pipe(sourcemaps.init())
    .pipe(
      postcss([
        postcssImport(),
        tailwindcss(),
        postcssNested(),
        postcssCustomProperties(),
        autoprefixer(),
      ])
    )
    .pipe(concat("style.css"))
    .pipe(sourcemaps.write("."))
    .pipe(dest(paths.css.destDev))
    .pipe(browserSync.stream());
};

// CSS Production
const cssProd = () => {
  return src(paths.css.src + "style.css")
    .pipe(sourcemaps.init())
    .pipe(
      postcss([
        postcssImport(),
        tailwindcss(),
        postcssNested(),
        postcssCustomProperties(),
        autoprefixer(),
      ])
    )
    .pipe(concat("style.css"))
    .pipe(sourcemaps.write("."))
    .pipe(dest(paths.css.dest))
    .pipe(cleanCSS())
    .pipe(browserSync.stream());
};

// CSS Extras
const cssExtra = () => {
  return src(paths.cssExtra.src)
    .pipe(sourcemaps.init())
    .pipe(concat("vendor.css"))
    .pipe(sourcemaps.write("."))
    .pipe(dest(paths.css.dest))
    .pipe(browserSync.stream());
};
const cssExtraDev = () => {
  return src(paths.cssExtra.src)
    .pipe(sourcemaps.init())
    .pipe(concat("vendor.css"))
    .pipe(sourcemaps.write("."))
    .pipe(dest(paths.css.destDev))
    .pipe(browserSync.stream());
};

// JS
const js = () => {
  return src(paths.js.src)
    .pipe(sourcemaps.init())
    .pipe(concat("script.js"))
    .pipe(sourcemaps.write("."))
    .pipe(dest(paths.js.destDev))
    .pipe(browserSync.stream());
};

// JS Production
const jsProd = () => {
  return pipeline(
    src([paths.js.src, "!html-src/assets/js/custom_script.js"]).pipe(concat("script.js")),
    uglify(),
    dest(paths.js.dest)
  );
};

const cusjsProd = () => {
  return pipeline(
    src('html-src/assets/js/custom_script.js').pipe(concat("custom_script.js")),
    dest(paths.js.dest)
  );
};


// Vendor
const vendor = () => {
  // Line Awesome (Copy Fonts)
  const lineAwesome = () =>
    src("node_modules/line-awesome/dist/line-awesome/fonts/**/*").pipe(
      dest(paths.fonts.dest)
    );

  // Vendor Js
  const vendorJs = () =>
    src([
      // Tippy.js
      "node_modules/@popperjs/core/dist/umd/popper.min.js",
      "node_modules/tippy.js/dist/tippy.umd.min.js",
    ])
      .pipe(concat("vendor.js"))
      .pipe(dest(paths.js.dest));

  return lineAwesome(), vendorJs();
};

// Vendor Dev
const vendorDev = () => {
  // Line Awesome (Copy Fonts)
  const lineAwesome = () =>
    src("node_modules/line-awesome/dist/line-awesome/fonts/**/*").pipe(
      dest(paths.fonts.destDev)
    );

  // Vendor Js
  const vendorJs = () =>
    src([
      // Tippy.js
      "node_modules/@popperjs/core/dist/umd/popper.min.js",
      "node_modules/tippy.js/dist/tippy.umd.min.js",
    ])
      .pipe(concat("vendor.js"))
      .pipe(dest(paths.js.destDev));

  return lineAwesome(), vendorJs();
};


// Vendor Extras
const vendorExtras = (isDev) => {
  const vendorExtrasJs = () =>
    src([
      // Chart.js
      "node_modules/chart.js/dist/chart.min.js",
      // Sortable.js
      "node_modules/sortablejs/Sortable.min.js",
      // Glide.js
      "node_modules/@glidejs/glide/dist/glide.min.js",
      // CKEditor
      "node_modules/@ckeditor/ckeditor5-build-classic/build/ckeditor.js",
      // CKEditor
      "node_modules/@ckeditor/ckeditor5-build-classic/build/ckeditor.js.map",
      // Tippy.js
      "node_modules/tippy.js/dist/tippy.umd.min.js.map",
      //Jquery
      "node_modules/jquery/dist/jquery.min.js",
      //Jquery mask plugin
      "node_modules/jquery-mask-plugin/dist/jquery.mask.min.js",
      //Alpine js
      "node_modules/alpinejs/dist/cdn.min.js",
      //Datatables
      "node_modules/datatables/media/js/jquery.dataTables.min.js",
      "node_modules/drmonty-datatables-responsive/js/dataTables.responsive.min.js",
      //Notifier Js
      "node_modules/notifier-js/dist/js/notifier.js",
      //FilePond
      "node_modules/filepond/dist/filepond.min.js",
      //FilePondPlugin FileEncode
      "node_modules/filepond-plugin-file-encode/dist/filepond-plugin-file-encode.min.js",
      //FilePondPluginFileValidateSize
      "node_modules/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.min.js",
      //FilePondPluginImageExifOrientation
      "node_modules/filepond-plugin-image-exif-orientation/dist/filepond-plugin-image-exif-orientation.min.js",
      //FilePondPluginImagePreview
      "node_modules/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.js",
      //Filepond-Plugin-file-validate-type
      "node_modules/filepond-plugin-file-validate-type/dist/filepond-plugin-file-validate-type.min.js",
      //html2canvas
      "node_modules/html2canvas/dist/html2canvas.min.js",
      //jsPDF
      "node_modules/jspdf/dist/jspdf.umd.min.js",
      //SweetAlert2
      "node_modules/sweetalert2/dist/sweetalert2.all.min.js",

      //remove this list after development Data list of rooms and beds not implimented so we use this
      "html-src/testapi_roomAndBed_type.html"
    ]).pipe(dest(paths.js.dest));

  const vendorExtrasJsDev = () =>
    src([
      // Chart.js
      "node_modules/chart.js/dist/chart.min.js",
      // Sortable.js
      "node_modules/sortablejs/Sortable.min.js",
      // Glide.js
      "node_modules/@glidejs/glide/dist/glide.min.js",
      // CKEditor
      "node_modules/@ckeditor/ckeditor5-build-classic/build/ckeditor.js",
      // CKEditor
      "node_modules/@ckeditor/ckeditor5-build-classic/build/ckeditor.js.map",
      // Tippy.js
      "node_modules/tippy.js/dist/tippy.umd.min.js.map",
      //Jquery
      "node_modules/jquery/dist/jquery.min.js",
      //Jquery mask plugin
      "node_modules/jquery-mask-plugin/dist/jquery.mask.min.js",
      //Alpine js
      "node_modules/alpinejs/dist/cdn.min.js",
      //Datatables
      "node_modules/datatables/media/js/jquery.dataTables.min.js",
      "node_modules/drmonty-datatables-responsive/js/dataTables.responsive.min.js",
      //Notifier Js
      "node_modules/notifier-js/dist/js/notifier.js",
      //FilePond
      "node_modules/filepond/dist/filepond.min.js",
      //FilePondPlugin FileEncode
      "node_modules/filepond-plugin-file-encode/dist/filepond-plugin-file-encode.min.js",
      //FilePondPluginFileValidateSize
      "node_modules/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.min.js",
      //FilePondPluginImageExifOrientation
      "node_modules/filepond-plugin-image-exif-orientation/dist/filepond-plugin-image-exif-orientation.min.js",
      //FilePondPluginImagePreview
      "node_modules/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.js",
      //Filepond-Plugin-file-validate-type
      "node_modules/filepond-plugin-file-validate-type/dist/filepond-plugin-file-validate-type.min.js",
      //html2canvas
      "node_modules/html2canvas/dist/html2canvas.min.js",
      //jsPDF
      "node_modules/jspdf/dist/jspdf.umd.min.js",
      //SweetAlert2
      "node_modules/sweetalert2/dist/sweetalert2.all.min.js"
    ]).pipe(dest(paths.js.destDev));

  if (isDev) {
    return vendorExtrasJsDev();
  } else {
    return vendorExtrasJs();
  }
};

const vendorExtrasDev = () => {
  return vendorExtras(true);
};

const vendorExtrasProd = () => {
  return vendorExtras();
};

// Images
const images = () => {
  return src(paths.images.src)
    .pipe(dest(paths.images.dest))
    .pipe(browserSync.stream());
};

// Images Dev
const imagesDev = () => {
  return src(paths.images.src)
    .pipe(dest(paths.images.destDev))
    .pipe(browserSync.stream());
};

// Fonts
const fonts = () => {
  return src(paths.fonts.src)
    .pipe(dest(paths.fonts.dest))
    .pipe(browserSync.stream());
};

// Fonts Dev
const fontsDev = () => {
  return src(paths.fonts.src)
    .pipe(dest(paths.fonts.destDev))
    .pipe(browserSync.stream());
};

// Clean
const clean = () => {
  console.log("Cleaning dist folder for fresh start.");
  return del(paths.dest);
};

const cleanProd = () => {
  console.log("Cleaning Production assets folder for fresh start.");
  return del(paths.destProd);
};

// Live Server
const liveServer = () => {
  browserSync.init({
    server: {
      baseDir: paths.dest,
    },
    notify: false,
  });
};

// Watch Files
const watchFiles = () => {
  liveServer();

  watch(paths.html.src, series(htmlDev));
  watch([paths.css.src, "tailwind.config.js"], series(css));
  watch(paths.js.src, series(js));
  watch(paths.images.src, series(imagesDev));
  watch(paths.fonts.src, series(fontsDev));
};

// Development
exports.default = series(
  clean,
  parallel(htmlDev, css, js, vendorDev, vendorExtrasDev, imagesDev, fontsDev, cssExtraDev),
  watchFiles
);

// Production
exports.build = series(
  cleanProd,
  //parallel(html,cssProd,jsProd, cusjsProd, vendor, vendorExtrasProd, images, fonts, cssExtra)
  parallel(cssProd, jsProd, cusjsProd, vendor, vendorExtrasProd, images, fonts, cssExtra)
);
