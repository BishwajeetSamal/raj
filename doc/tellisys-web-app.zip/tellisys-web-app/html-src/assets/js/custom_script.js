/**Server */
// const APPURL = "http://161.35.98.79:4000/";
// const APIURL = "http://161.35.98.79:8080/";
const APPURL = "http://localhost:4000/";;
const APIURL = "http://localhost:8080/";

const ASSETS_DIR = "/assets/images/";
const LogIn_Status_Check_Interval = 3;

// Event delegation
const on = (selector, eventType, childSelector, eventHandler) => {
  const elements = document.querySelectorAll(selector);
  for (element of elements) {
    element.addEventListener(eventType, (eventOnElement) => {
      if (eventOnElement.target.closest(childSelector)) {
        eventHandler(eventOnElement);
      }
    });
  }
};

// AnimateCSS
const animateCSS = (element, animation, prefix = "animate__") => {
  return new Promise((resolve, reject) => {
    const animationName = `${prefix}${animation}`;
    const node = element;

    node.classList.add(`${prefix}animated`, `${prefix}faster`, animationName);

    const handleAnimationEnd = (event) => {
      event.stopPropagation();
      node.classList.remove(
        `${prefix}animated`,
        `${prefix}faster`,
        animationName
      );
      resolve("Animation Ended.");
    };

    node.addEventListener("animationend", handleAnimationEnd, { once: true });
  });
};

// Viewport Width
// Define our viewportWidth variable
let viewportWidth;

// Set/update the viewportWidth value
const setViewportWidth = () => {
  viewportWidth = window.innerWidth || document.documentElement.clientWidth;
};

// Watch the viewport width
const watchWidth = () => {
  const sm = 640;
  const md = 768;
  const lg = 1024;
  const xl = 1280;

  const menuBar = document.querySelector(".menu-bar");

  // Hide Menu Detail
  const hideMenuDetail = () => {
    menuBar.querySelectorAll(".menu-detail.open").forEach((menuDetail) => {
      hideOverlay();

      if (!menuBar.classList.contains("menu-wide")) {
        menuDetail.classList.remove("open");
      }
    });
  };

  // Hide Sidebar
  const hideSidebar = () => {
    const sidebar = document.querySelector(".sidebar");

    if (!sidebar) return;

    if (sidebar.classList.contains("open")) {
      sidebar.classList.remove("open");
      hideOverlay();
    }
  };

  if (viewportWidth < sm) {
    if (!menuBar) return;

    const openMenu = menuBar.querySelector(".menu-detail.open");

    if (!openMenu) {
      menuBar.classList.add("menu-hidden");
      document.documentElement.classList.add("menu-hidden");
      hideMenuDetail();
    }
  }

  if (viewportWidth > sm) {
    if (!menuBar) return;

    menuBar.classList.remove("menu-hidden");
    document.documentElement.classList.remove("menu-hidden");
  }

  if (viewportWidth > lg) {
    hideSidebar();
  }
};

// Set our initial width
setViewportWidth();
watchWidth();

// On resize events, recalculate
window.addEventListener(
  "resize",
  () => {
    setViewportWidth();
    watchWidth();
  },
  false
);

// Open Collapse
const openCollapse = (collapse, callback) => {
  collapse.style.transitionProperty = "height, opacity";
  collapse.style.transitionDuration = "200ms";
  collapse.style.transitionTimingFunction = "ease-in-out";

  setTimeout(() => {
    collapse.style.height = collapse.scrollHeight + "px";
    collapse.style.opacity = 1;
  }, 200);

  collapse.addEventListener(
    "transitionend",
    () => {
      collapse.classList.add("open");

      collapse.style.removeProperty("height");
      collapse.style.removeProperty("opacity");

      collapse.style.removeProperty("transition-property");
      collapse.style.removeProperty("transition-duration");
      collapse.style.removeProperty("transition-timing-function");

      if (typeof callback === "function") callback();
    },
    { once: true }
  );
};

// Close Collapse
const closeCollapse = (collapse, callback) => {
  collapse.style.overflowY = "hidden";
  collapse.style.height = collapse.scrollHeight + "px";

  collapse.style.transitionProperty = "height, opacity";
  collapse.style.transitionDuration = "200ms";
  collapse.style.transitionTimingFunction = "ease-in-out";

  setTimeout(() => {
    collapse.style.height = 0;
    collapse.style.opacity = 0;
  }, 200);

  collapse.addEventListener(
    "transitionend",
    () => {
      collapse.classList.remove("open");

      collapse.style.removeProperty("overflow-y");
      collapse.style.removeProperty("height");
      collapse.style.removeProperty("opacity");

      collapse.style.removeProperty("transition-property");
      collapse.style.removeProperty("transition-duration");
      collapse.style.removeProperty("transition-timing-function");

      if (typeof callback === "function") callback();
    },
    { once: true }
  );
};
//Toggle Price Table Code Start 
$("#input_box_toggle").change(function () {
  if ($(this).is(":checked")) {
    $("#input_show").hide();
    $("#toggle_value").show();
  } else {
    $("#toggle_value").hide();
    $("#input_show").show();
  }

});

$("#toggle_value").change(function () {
  //status ajax success
  $("#input_show").html("$" + $(this).val());
  $("#toggle_value").hide();
  $("#input_show").show();
  $("#input_box_toggle").prop('checked', false)
});
//Toggle Price Table Code End


/**Notification flag 
 * Input parameters :
    messageType => info|success|warning|danger
    messageTitle => title of message
    message => string message
    * Output :
    notification flag show
*/
function flagMsg(messageType, messageTitle, message, time) {
  var flagIcon = ASSETS_DIR + 'survey-48.png';
  if (messageType == "success") {
    flagIcon = ASSETS_DIR + 'ok-48.png';
  }
  if (messageType == "warning") {
    flagIcon = ASSETS_DIR + 'medium_priority-48.png';
  }
  if (messageType == "danger") {
    flagIcon = ASSETS_DIR + 'high_priority-48.png';
  }
  notifier.show(messageTitle, message, messageType, flagIcon, time);
}


/** jquery Ajax Request 
 * Input parameters :
    formUrl => full url path of targeted request
    formData => json formatted data set
 * Output :
    success=> {status:success, data: data_sets_array}
    failure=> {status:failure, data: {messageType:info|success|warning|danger, messageTitle: "string message",message: "string message"}}
 */
function ajaxRequest(formUrl, formData, API = false) {
  UriPath = (API) ? APIURL : APPURL;
  return $.ajax({
    url: UriPath + formUrl, type: "POST", data: formData, dataType: "json",
    success: function (data, textStatus, jqXHR) {
      //data - response from server 
      // if (data.status != "success") { when we need to every request check
    },
    error: function (jqXHR, textStatus, errorThrown) {
      flagMsg('danger', 'Server response', 'Something went wrong, please try again.');
    }
  });
}

function getDateNow_o_h() {
  var date = new Date(new Date().setHours(0, 0, 0, 0));
  return date;
}
/**To kamel case  */
function toKamelCase(strWord) {
  strWord = strWord.trim();
  return (strWord.charAt(0).toUpperCase() + strWord.slice(1).toLowerCase());
}
/* Date Format convertor => 23-11-2020 to 2020,11,23 */
function parseDate(dateV) { dt_a = dateV.split("-"); return (((dt_a[2].length) > 2) ? new Date(dt_a[2], (dt_a[1] - 1), dt_a[0]) : new Date(dt_a[0], (dt_a[1] - 1), dt_a[2])) }
/* Get Text/String Number value to Float value */
function toFloat(value) { return parseFloat(value.replace(/[^0-9.-]+/g, '')); }
/* Get Day No. of Date Object  */
function getDayNo(date) { return (date.toDateString().substr(08, 2)); }
/* Get Day of Week Name of Date Object  */
function getDayName(date) { return (date.toDateString().substr(0, 3)); }
/* Get Month Name of Date Object  */
function getMonName(date) { return (date.toDateString().substr(4, 3)); }
// /**Date object to yyyy-mm-dd to  */
function DateToYMD(date) {
  return date.getFullYear() + "-" + ("0" + (parseInt(date.getMonth()) + 1)).slice(-2) + "-" + ("0" + date.getDate()).slice(-2);
}
/** get previous/next date value of given no. of days
  let currentDate = new Date();\
  currentDate.previousNext("next", 7); get next 7th value */
Date.prototype.previousNext = function (previousNext, no_of_days) {
  var tempDateValue = new Date(this.valueOf());
  tempDateValue.setDate((previousNext == 'next') ? tempDateValue.getDate() + no_of_days : tempDateValue.getDate() - no_of_days);
  return tempDateValue
};
//resource https://weeknumber.com/how-to/javascript
// Returns the ISO week of the date.
Date.prototype.getWeek = function () {
  var date = new Date(this.getTime());
  date.setHours(0, 0, 0, 0);
  // Thursday in current week decides the year.
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  // January 4 is always in week 1.
  var week1 = new Date(date.getFullYear(), 0, 4);
  // Adjust to Thursday in week 1 and count number of weeks from date to week1.
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

/**DatePicker AlpineJs Extra Code for Init */
const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",];
const MONTH_SHORT_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",];
const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function app() {
  return {
    showDatepicker: false,
    datepickerValue: "",
    // selectedDate: "2021-07-25",
    dateFormat: "YYYY-MM-DD", /* DD-MM-YYYY, YYYY-MM-DD, D d M, Y*/
    month: "",
    year: "",
    no_of_days: [],
    blankdays: [],
    initDate() { let today; if (this.selectedDate) { today = new Date(Date.parse(this.selectedDate)); } else { today = new Date(); } this.month = today.getMonth(); this.year = today.getFullYear(); this.datepickerValue = this.formatDateForDisplay(today); },
    formatDateForDisplay(date) { let formattedDay = DAYS[date.getDay()]; let formattedDate = ("0" + date.getDate()).slice(-2); /* appends 0 (zero) in single digit date */ let formattedMonth = MONTH_NAMES[date.getMonth()]; let formattedMonthShortName = MONTH_SHORT_NAMES[date.getMonth()]; let formattedMonthInNumber = ("0" + (parseInt(date.getMonth()) + 1)).slice(-2); let formattedYear = date.getFullYear(); if (this.dateFormat === "DD-MM-YYYY") { return `${formattedDate}-${formattedMonthInNumber}-${formattedYear}`; /* 02-04-2021 */ } if (this.dateFormat === "YYYY-MM-DD") { return `${formattedYear}-${formattedMonthInNumber}-${formattedDate}`; /* 2021-04-02 */ } if (this.dateFormat === "D d M, Y") { return `${formattedDay} ${formattedDate} ${formattedMonthShortName} ${formattedYear}`; /* Tue 02 Mar 2021 */ } return `${formattedDay} ${formattedDate} ${formattedMonth} ${formattedYear}`; },
    isSelectedDate(date) { const d = new Date(this.year, this.month, date); return this.datepickerValue === this.formatDateForDisplay(d) ? true : false; },
    isToday(date) { const today = new Date(); const d = new Date(this.year, this.month, date); return today.toDateString() === d.toDateString() ? true : false; },
    getDateValue(date) { let selectedDate = new Date(this.year, this.month, date); this.datepickerValue = this.formatDateForDisplay(selectedDate); /* this.$refs.date.value = selectedDate.getFullYear() + "-" + ('0' + formattedMonthInNumber).slice(-2) + "-" + ('0' + selectedDate.getDate()).slice(-2);*/ this.isSelectedDate(date); this.showDatepicker = false; },
    getNoOfDays() { let daysInMonth = new Date(this.year, this.month + 1, 0).getDate(); /* find where to start calendar day of week*/ let dayOfWeek = new Date(this.year, this.month).getDay(); let blankdaysArray = []; for (var i = 1; i <= dayOfWeek; i++) { blankdaysArray.push(i); } let daysArray = []; for (var i = 1; i <= daysInMonth; i++) { daysArray.push(i); } this.blankdays = blankdaysArray; this.no_of_days = daysArray; },
    isBlocked(date) {
      if (this.$refs.main.id == "checkoutDiv") {
        let target = document.getElementById("checkin");
        if (target.value == "") {
          // Today's date selected in checkin
          this.blockdate = new Date();
          //this.blockdate = "2021-09-05";
        } else {
          // Use the target value to block date
          this.blockdate = target.value;
          //this.blockdate = "2021-09-15";
        }
      }
      let selectedDate = new Date(this.year, this.month, date);
      let checkInDate = new Date(Date.parse(this.blockdate));
      if (selectedDate <= checkInDate) {
        return false;
      } else {
        return true;
      }
    },
  }
}
/** ./ DatePicker AlpineJs Extra Code for Init */

/**Count Number of Two Date  */
function countNoOfDays(dateStart, dateEnd) {
  return Math.round(Math.abs((new Date(dateStart) - new Date(dateEnd)) / (24 * 60 * 60 * 1000)));
}
/**Coll-Span Skip column Function for Timeline Table Header */
function collSpanMonth(date1, date2) {
  if (date2.getMonth() !== date1.getMonth()) { var dateEnd = new Date(date1.getFullYear(), date1.getMonth() + 1, 0); return (dateEnd.getDate() - date1.getDate()) + 1; } else { return (date2.getDate() - date1.getDate()) + 1; }
}
/**1 day, 5 day 7 day Card trigger function after get response on card*/
function getDisplayDaysLocalStorage(capacity) {
  noOfDay = window.localStorage.getItem("displayNoDay");
  selectCard = (noOfDay === null || (noOfDay === "auto")) ? "auto" : noOfDay;
  document.querySelectorAll(".DataFilterShowCardLimit").forEach(element => {
    if (element.getAttribute("data-card-days-show-val") == selectCard) {
      element.classList.add("bg-primary-500");
      element.classList.add("text-white");
      element.classList.remove("hover:text-white");
      element.classList.remove("hover:bg-primary-500");
      /*dark*/
      element.classList.remove("dark:hover:text-primary-800");
      element.classList.remove("dark:hover:bg-primary-200");
      element.classList.add("dark:bg-primary-200");
      element.classList.add("dark:text-primary-800");
    } else {
      element.classList.add("hover:text-white");
      element.classList.add("hover:bg-primary-500");
      element.classList.remove("bg-primary-500");
      element.classList.remove("text-white");
      /*dark*/
      element.classList.add("dark:hover:text-primary-800");
      element.classList.add("dark:hover:bg-primary-200");
      element.classList.remove("dark:bg-primary-200");
      element.classList.remove("dark:text-primary-800");
    }
  })

  if (noOfDay === "auto") {
    return capacity;
  }
  noOfDay = parseInt(noOfDay) - 1;
  return (noOfDay < capacity) ? noOfDay : capacity;
}

/**1 day, 5 day 7 day Card display or hide in diff screen viewport */
function step_of_timeline_dateSHow(dateStart, dateEnd) {
  const lg = 1024;
  const xl = 1366;
  if (viewportWidth >= xl) {
    // Extra Large Screen
    deviding_day = 80;
  } else if (viewportWidth < xl && viewportWidth >= lg) {
    // Large Screen
    deviding_day = 90;
  } else {
    // Medium Screen and Small Screen
    deviding_day = 100;
  }
  countOfDay = parseInt((viewportWidth) / deviding_day);
  countOfDay = (countOfDay) > 31 ? 30 : countOfDay;
  countOfDay = getDisplayDaysLocalStorage(countOfDay);
  return countOfDay;

}
/**Refresh re plot TImeline table storage clear and re-plot */
function plotDataRefresh() {
  window.localStorage.clear();
  plotData();
}


/**1 day, 5 day 7 day Card trigger function after click on card click event*/
// class="  block  w-20 border-2 cursor-pointer dark:hover:bg-primary-200 hover:bg-primary-500 hover:text-white dark:hover:text-primary-800 "
document.querySelectorAll(".DataFilterShowCardLimit").forEach(element => {
  element.addEventListener("click", function () {
    window.localStorage.setItem("displayNoDay", this.getAttribute("data-card-days-show-val"));
    plotData();
  })
});

/**Coll-Span Skip column Function for Timeline Table Cell Data */
function checkSplitRoomCol(timelineStartDate, cDate, resourceId, events) {
  let returnVal = { "status": false };

  events.some(event => {
    if (event.Room_type_id === resourceId) {
      // let eventDate = new Date(event.start);
      let eventDateStart = parseDate(event.CheckIn);
      let eventDateEnd = parseDate(event.CheckOut);

      if (eventDateStart.getTime() === cDate.getTime()) {
        returnVal = { "status": true, "skipDate": countNoOfDays(eventDateStart, eventDateEnd) + 1, "data": event, "before": false };
        // break;
        return returnVal;
      } else if (timelineStartDate > eventDateStart && eventDateEnd.getTime() >= cDate.getTime()) {
        returnVal = { "status": true, "skipDate": countNoOfDays(timelineStartDate, eventDateEnd) + 1, "data": event, "before": true };
        // break;
        return returnVal;
      } else { }
    }
  });
  return returnVal;
}

/* Date toggle form Date Toggle Previous or Next Page switching*/
function dateTogglePage(togglePreviousNext, date, no_of_days) {
  startEndDate = parseDate(date);
  if (document.getElementById("timelineTableType").value == "reservation") {
    if (noOfDay > 30) {
      (togglePreviousNext == "next") ? get_reservation_timeline_data(startEndDate, new Date(startEndDate.getFullYear(), startEndDate.getMonth() + 1, startEndDate.getDate())) : get_reservation_timeline_data(new Date(startEndDate.getFullYear(), startEndDate.getMonth() - 1, startEndDate.getDate()), startEndDate);
    } else {
      (togglePreviousNext == "next") ? get_reservation_timeline_data(startEndDate.previousNext("next", parseInt(1)), startEndDate.previousNext("next", parseInt(no_of_days))) : get_reservation_timeline_data(startEndDate.previousNext("previous", parseInt(no_of_days)), startEndDate.previousNext("previous", parseInt(1)));
    }
  }
  if (document.getElementById("timelineTableType").value == "pricing") {
    if (noOfDay > 30) {
      // (togglePreviousNext == "next") ? get_pricing_timeline_data(startEndDate, new Date(startEndDate.getFullYear(), startEndDate.getMonth() + 1, startEndDate.getDate())): get_pricing_timeline_data(new Date(startEndDate.getFullYear(), startEndDate.getMonth() - 1, startEndDate.getDate()), startEndDate);
      (togglePreviousNext == "next") ? get_pricing_timeline_data(startEndDate, new Date(startEndDate.getFullYear(), startEndDate.getMonth(), startEndDate.getDate())) : get_pricing_timeline_data(new Date(startEndDate.getFullYear(), startEndDate.getMonth(), startEndDate.getDate()), startEndDate);
    } else {
      (togglePreviousNext == "next") ? get_pricing_timeline_data(startEndDate.previousNext("next", parseInt(1)), startEndDate.previousNext("next", parseInt(no_of_days))) : get_pricing_timeline_data(startEndDate.previousNext("previous", parseInt(no_of_days)), startEndDate.previousNext("previous", parseInt(1)));
    }
  }
}

function numberWithCommas(x) {
  return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
}
/**Popover tooltips Template: for Cell*/
function template_TimeLineToolTips(reference, id, data) {
  var dataVal = JSON.parse(data);
  var headerDta = "";
  var footerDta = "";
  if (id === "info") {
    headerDta = dataVal.Title;
    footerDta = dataVal.Subtitle;
  }
  if (id === "date") {
    start = parseDate(dataVal.StartDate);
    headerDta = ['<div class="w-full"> <span class="uppercase text-xs text-gray-500">', getDayName(start), '</span>', getMonName(start), ', ', getDayNo(start), start.getFullYear(), '</div>'].join(' ');

    footerDta = ' <div class="w-full"> <span class="pr-2">' + dataVal.Title + '</span>' + numberWithCommas(reference.value) + '</div>';
  }
  if (id === "resRv") {
    start = parseDate(dataVal.StartDate);
    end = parseDate(dataVal.EndDate);
    headerDta = ['<div class="w-2/5  text-center"> <div class="w-full whitespace-no-wrap">' + getMonName(start), ', ', getDayNo(start), '<br>', start.getFullYear(), '</div> <div class="w-full uppercase text-xs text-gray-500">', getDayName(start), '</div> </div> <div class="items-center pl-1 pr-2"> <div class="w-full whitespace-no-wrap text-center -mb-2">', (countNoOfDays(start, end) + 1) + 'N </div> <div class="w-full text-center w-1/5"> <i class="la  la-long-arrow-right text-md text-lg"></i> </div> </div> <div class="w-2/5  text-center"> <div class="w-full whitespace-no-wrap">' + getMonName(end), ', ', getDayNo(end), '<br>', end.getFullYear(), '</div> <div class="w-full uppercase text-xs text-gray-500">', getDayName(end), '</div> </div>'].join(' ');
    footerDta = dataVal.Name;
  }
  var tmplPlot = ['<div class="' + id + ' w-48 text-sm leading-tight"> <div class="flex flex-col w-full"> <ul class="list-n fullYear"><li class="pb-2 border-b-2"> <div class="w-full flex items-center ">', headerDta, ' </div> <li><div class="w-full pt-4 text-center">', footerDta, '</div></li> </ul> </div> </div>'].join(' ');
  return tmplPlot;
}

/* function templateDeleteConfirm(id, data) {
    var dataVal = JSON.parse(data);
    return (['<div class="' + id + ' w-50 block font-normal leading-normal text-sm max-w-xs text-left no-underline break-words"><div class="flex pb-2 border-b-2">Confirmation </div> <div class="w-full p-2"> Delete Records ? <div class="w-full text-center pt-2"><button type="button" class="btn btn_outlined btn_success uppercase text-sm py-1"><i class="la la-check pr-2"></i> Delete</button></div></div>'].join(' '));    
}
*/

/**Popover tooltips Template: for Cell which is reserve by guest*/
function template_Timeline_reservation_data_show(id, data) {
  var dataVal = JSON.parse(data);
  start = parseDate(dataVal.StartDate)
  end = parseDate(dataVal.EndDate)
  var tmplPlot = ['<div class="' + id + ' z-20 "><div class="w-full border-b-2"> <div class="flex font-semibold whitespace-no-wrap uppercase"> <div class="w-1/2"> <h1 class="text-lg ">', dataVal.Name, '</h1> </div> <div class="w-1/2 text-right "> <h1 class="text-lg "> #', dataVal.UniqueId, '</h1> </div> </div> <div class="w-full py-3 text-sm "> <div class="flex w-full"> <div class="w-1/2">', dataVal.Address, ',', dataVal.City, '</div> <div class="w-1/2 text-right ">', 'Trips Total', '<span class="pl-1">$' + dataVal.Trip_total, '</span> </div> </div> <div class="flex w-full"> <div class="w-1/2">', dataVal.State, ',', dataVal.Country, '</div> <div class="w-1/2 text-right ">', 'Balance Due', '<span class="pl-1">$' + dataVal.Due_depo, '</span> </div> </div> </div> </div> <div class="items-center w-full gap-2 leading-normal text-sm flex flex-1 pt-4"> <div class="w-2/5 flex items-center gap-2 "> <div> <i class="la la-calendar-alt text-3xl "></i> </div> <div class="w-16"> <div class="w-full whitespace-no-wrap">', getMonName(start), getDayNo(start), start.getFullYear(), '</div> <div class="w-full uppercase text-xs text-gray-500">', getDayName(start), '</div> </div> <div class="items-center pl-1 pr-2"> <div class="w-full whitespace-no-wrap text-center -mb-2">', (countNoOfDays(start, end) + 1), 'N</div> <div class="w-full text-center "> <i class="la la-long-arrow-right text-md text-lg"></i> </div> </div> <div class="w-16"> <div class="w-full whitespace-no-wrap">', getMonName(end), getDayNo(end), end.getFullYear(), '</div> <div class="w-full uppercase text-xs text-gray-500">', getDayName(end), '</div> </div> <!-- /date --> </div> <div class="w-full flex items-center justify-center gap-2"> <div class=""> <i class="la la-user-friends text-3xl "></i> </div> <div class=""> <div class=" whitespace-no-wrap">', dataVal.Adult, ' Ad', '</div> <div class=" whitespace-no-wrap ">', dataVal.Child, ' Ch', '</div> </div> </div> <div class="w-2/5 flex items-center text-left"> <div> <div class="w-full">', dataVal.RmType, '</div> <div class="w-full whitespace-no-wrap flex"> <div class="uppercase pr-2">', , '</div> <strong>', , '</strong> </div> </div> </div> </div> </div>'].join(' ');
  return tmplPlot;
}

//allow only number
function isNumberKey(evt) {
  timeline_rate_plan_change(evt.target.id);
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
  return true;
}
/**Popover tooltips Template: Pricing cell change price value  */
function template_Timeline_Price_value_change(reference, id, data) {
  var dataVal = JSON.parse(data);
  start = parseDate(dataVal.StartDate)
  var tmplPlot = [
    '<div class="' + id + ' w-72 border-0 block font-normal leading-normal text-sm max-w-xs text-left no-underline break-words"><div class=0 text-white opacity-75 p-3 font-semibold mb-0 border-b border-solid border-primary-200 rounded-t-lg">', '<div class="flex"><div class="flex-auto "><span class="uppercase text-xs text-gray-500">', getDayName(start), '</span>', getMonName(start), ', ', getDayNo(start), start.getFullYear(), '</div> <div class="flex flex-col font-medium">',
    dataVal.Title, '</div> </div> </div> <div class="flex pt-2 border-b-2"></div><div class="flex pt-2 gap-2"><div> <label> Room rate: <br />', '<input type="text"  placeholder="0.00" data-roomData="' + id + '" class="form-control w-full px-2 py-1 rounded mt-2" value="' + toFloat(reference.value) + '" id="PopInp' + id.trim() + '" onchange="PriceValueChange(\'' + id.trim() + '\', this)" onkeypress="return isNumberKey(event)" />', '</label> </div>', (reference.getAttribute("data-SystemGenRate") != "prev") ? '<div> <label> System Suggested: <br /><div class="input-group"> <input type="text"  readonly="true" data-roomData="' + id + '" class="form-control w-full px-2 py-1 rounded mt-2 input-group-item" value="' + toFloat(reference.getAttribute("data-SystemGenRate")) + '" placeholder="0.00"> <label class="input-addon input-addon-append input-group-item mt-2 btn btn_primary bg-opacity-70" style="padding:0px 0.2rem !important" onclick="SysSugCopyToRoomRate(\'' + id.trim() + '\',' + toFloat(reference.getAttribute("data-SystemGenRate")) + ')"><i class="la la-dollar text-lg"></i></label> </div>' : '', ' </label> </div> </div> </div>',

  ].join(' ');
  return tmplPlot;
}
function SysSugCopyToRoomRate(targetedId, val) {
  document.getElementById(targetedId).value = "$" + val;
  document.getElementById("PopInp" + targetedId).value = val;
  PriceValueChange(targetedId, document.getElementById("PopInp" + targetedId))
  return true;
}

function template_Timeline_table_cell_tooltips() {
  tippy('.ToolTips', {
    placement: 'top',
    onTrigger(instance) {
      var reference = instance.reference;
      instance.setContent(template_TimeLineToolTips(reference, reference.getAttribute('data-template-tooltips'), reference.getAttribute('data-data')));
    },

    onMount(instance) { instance.popperInstance.setOptions({ placement: instance.reference.getAttribute('data-placement') }); },
    theme: "light-border popover",
    animation: "shift-toward-extreme",
    allowHTML: true,
    interactive: true,
    delay: [500, null],
    touch: 'hold',
    zIndex: 50,
    offset: [0, -1],
  });
  return true;
}

/**Check Price available of room or not available then return true otherwise false */
function checkRoomPriceAvailable(cDate, resourceId, events) {
  let returnVal = { "Status": false };
  if (events != null) {
    events.some(event => {
      if (event.RoomTypeId === resourceId || resourceId === "SystemSuggested") {
        let eventDateStart = (resourceId === "SystemSuggested") ? parseDate(event.date) : parseDate(event.DateTime);
        if (eventDateStart.getTime() === cDate.getTime()) {
          returnVal = { "Status": true, "Data": event };
          // break;
          return returnVal;
        }
      }
    });
  }
  return returnVal;
}

/** System suggested price calculation */

function calculate_current_system_suggested_price(event, cDate, today, week) {
  // year
  // weekno
  day_of_checkin = countNoOfDays(cDate, today);
  day_of_checkin = (day_of_checkin === 0) ? 0.5 : day_of_checkin;
  c_price = parseFloat(event.system_price);
  targeted_occupancy = (parseFloat(event.targeted_occupancy) !== 0) ? targeted_occupancy : 1;
  current_occupancy = parseFloat(event.current_occupancy);
  diff = targeted_occupancy - current_occupancy;
  if (diff > 0) {
    current_price = c_price - (c_price * (diff / 100)) - (c_price * (1 / (10 * day_of_checkin)));
  } else {
    current_price = c_price - (c_price * ((3 * diff) / 100)) - (c_price * (1 / day_of_checkin))
  }

  console.log("analytical_price", event.analytical_price, "analytical_rank", event.analytical_rank, "current_occupancy", event.current_occupancy, "hotel", event.hotel, "historical_price", event.historical_price, "system_price", event.system_price, "targeted_occupancy", event.targeted_occupancy, "day_of_checkin", day_of_checkin, ", c_price", c_price, ", targeted_occupancy", targeted_occupancy, ", current_occupancy", current_occupancy, ", diff", diff, "current_price", current_price, "week", week, "date", cDate);
  return current_price.toFixed(2);
}

/* /System suggested price calculation */
/**
 * @returns Status: true|false, Data: Number|prev
 */

function checkRoomSuggestedPriceAvailable(cDate, events) {
  today = getDateNow_o_h()
  let returnVal = { "Status": false };
  if (events != null && (today <= cDate)) {
    events.some(event => {
      if (cDate.getFullYear() === event.year && cDate.getWeek() === event.weekno) {
        // console.log(today,cDate, cDate.getFullYear() === event.year && cDate.getWeek() === event.weekno, cDate.getWeek() ,event.weekno, );
        try {
          returnVal = { "Status": true, "Data": calculate_current_system_suggested_price(event, cDate, today, cDate.getWeek()) };
        } catch (error) {
          console.error(error);
        }
        return returnVal;
      }
    });
  } else {
    returnVal = { "Status": true, "Data": "prev" };
  }
  return returnVal;
}

function IsAssignOrNot(cDate, resourceId, events) {
  let returnVal = { "Status": false };
  if (events != null) {
    events.some(event => {
      if (event.Room_type_id == resourceId) {
        let eventDateStart = parseDate(event.CheckIn);
        let eventDateEnd = parseDate(event.CheckOut);
        if (eventDateStart.getTime() === cDate.getTime()) {
          returnVal = { "Status": true, "Data": event };
          return returnVal;
        } else if (eventDateEnd.getTime() > cDate.getTime()) {
          returnVal = { "Status": true, "Data": event, "enddate": 2 };
          // break;
          return returnVal;
        }
      }
    });
  }
  return returnVal;
}


/**reservation heading data plot */
function tmplDataSet_timeline_Header(loadTimelineData) {
  if (loadTimelineData != null) {
    document.getElementById('timelineResourceHeader').innerHTML = tmpl("tmpl-timelineResourceHeader", loadTimelineData);
    document.getElementById('timelineResourceHeaderFixed').innerHTML = tmpl("tmpl-timelineResourceHeader", loadTimelineData);
  } else {
    document.getElementById('timelineResourceHeader').innerHTML = "";
    document.getElementById('timelineResourceHeaderFixed').innerHTML = "";
  }
}

/** pricing body room pricing data */
function tmplDataSet_timeline_pricing_data_room(pricing_data_set) {
  if (pricing_data_set.SystemSuggested === null) {
    flagMsg("warning", "System suggessted records fetch", "API server not found or <br> Something went wrong, please try again.", 5000)
  }
  if (pricing_data_set) {
    if (pricing_data_set["Rooms"] === null) {
      document.getElementById('timelinePricingTableBody').innerHTML = '<tr><td class="text-center h-36 items-center" colspan="31"> Rooms not available. </td></tr>';
    } else {
      document.getElementById('timelinePricingTableBody').innerHTML = tmpl("tmpl-timelinePricingTableBody", pricing_data_set);
    }
  } else {
    document.getElementById('timelinePricingTableBody').innerHTML = '<tr><td class="text-center h-36 items-center" colspan="31"> Rooms not available. </td></tr>';
  }


  /**popover: Cell Tooltips */
  template_Timeline_table_cell_tooltips();

  tippy('.PopoverBoxPriceCange', {
    placement: 'top',
    onShow(instance) {
      var reference = instance.reference;
      instance.setContent(template_Timeline_Price_value_change(reference, reference.getAttribute('id'), reference.getAttribute('data-data')));
    },

    onMount(instance) { instance.popperInstance.setOptions({ placement: instance.reference.getAttribute('data-placement') }); },
    theme: "light-border popover",
    animation: "shift-toward-extreme",
    allowHTML: true,
    trigger: 'click',
    interactive: true,
    delay: [500, null],
    touch: 'hold',
    zIndex: 60,
    offset: [0, -1]
  });

}
function dataSetUnassign(currentDateB, endDate, events) {
  dataMain = {};
  currentDateA = currentDateB;
  if (events != null) {
    for (let increment = 0; increment <= step_of_timeline_dateSHow(currentDateB, endDate) + 1; increment++) {
      if (increment) {
        events.some(event => {
          let eventDateStart = parseDate(event.CheckIn);
          let eventDateEnd = parseDate(event.CheckOut);
          if (eventDateStart.getTime() <= currentDateA.getTime() && eventDateEnd.getTime() > currentDateA.getTime()) {
            cc = (event.Counting === undefined) ? 0 : event.Counting;
            dataMain[currentDateA] = ((dataMain[currentDateA]) ? dataMain[currentDateA] : 0) + toFloat(cc);
          }

        });
        currentDateA = new Date(currentDateA.getFullYear(), currentDateA.getMonth(), currentDateA.getDate() + 1);
      }
    }
  }
  return dataMain;
}

/** reservation body guest reservation data */
function tmplDataSet_timeline_reservation_data_guest(reservation_data_set) {
  var check = (reservation_data_set) ? (reservation_data_set.Rooms && reservation_data_set.Reserve) : false;
  if (check) {
    document.getElementById('timelineResourceBody').innerHTML = tmpl("tmpl-timelineResourceBody", reservation_data_set);
  } else {
    document.getElementById('timelineResourceBody').innerHTML = '<tr class="animate-pulse bg-primary-100 h-12"></tr>';
  }


  check = (reservation_data_set) ? (reservation_data_set.Statistics) : false;
  reservation_data_set.dataMain = dataSetUnassign(reservation_data_set.startDate, reservation_data_set.endDate, reservation_data_set.Unassign);
  if (check) {
    document.getElementById('timelineResourceFooter').innerHTML = tmpl("tmpl-timelineResourceFooter", reservation_data_set);
  } else {
    document.getElementById('timelineResourceFooter').innerHTML = '<tr> <td class="animate-pulse bg-primary-100 h-12"></td></tr>';
  }
  reservation_data_set.StatusFooter = [{ "Themes": "#Room Available", "Counting": reservation_data_set.dataMain, "All": reservation_data_set.AllRooms.Counting }, { "Themes": "%Occupancy", "Counting": reservation_data_set.dataMain, "All": reservation_data_set.AllRooms.Counting }];
  if (reservation_data_set.StatusFooter) {
    document.getElementById('timelineResourceFooterFix').innerHTML = tmpl("tmpl-timelineResourceFooterFix", reservation_data_set);
  } else {
    document.getElementById('timelineResourceFooterFix').innerHTML = '<tr> <td class="animate-pulse bg-primary-100 h-12"></td></tr>';
  }

  // document.getElementById('timelineResource').style.minHeight = (document.getElementById('timelineResourceBody').scrollHeight * 3) / 2;

  /**popover: Cell Tooltips */
  template_Timeline_table_cell_tooltips();

  /*popover: Reservation gest Data SHow */
  tippy('.PopoverInfo', {
    placement: 'top',
    onTrigger(instance) {
      var reference = instance.reference;
      instance.setContent(template_Timeline_reservation_data_show(reference.getAttribute('data-template-popover'), reference.getAttribute('data-data')));
    },
    onMount(instance) { instance.popperInstance.setOptions({ placement: instance.reference.getAttribute('data-placement') }); },
    theme: "light-border popover", animation: "shift-toward-extreme", allowHTML: true, trigger: 'click', interactive: true, delay: [500, null], touch: 'hold', zIndex: 60, offset: [0, -1], maxWidth: "100%"
  });
  /*popover: Delete Conformation
  tippy('.ConfirmDelete', { placement: 'top', onTrigger(instance) { var reference = instance.reference; instance.setContent(templateDeleteConfirm(reference.getAttribute('data-template-popover'), reference.getAttribute('data-data'))); }, onMount(instance) { instance.popperInstance.setOptions({ placement: instance.reference.getAttribute('data-placement') }); }, theme: "light-border popover", animation: "shift-toward-extreme", allowHTML: true, trigger: 'click', interactive: true, delay: [1000, null], touch: 'hold', zIndex: 20, offset: [0, -1]});
  */
}


/**Pricing timeline-table main function plot timeline table use tmpl js */
function plotPriceTable(loadTimelineData) {
  /**pricing heading data plot */
  tmplDataSet_timeline_Header(loadTimelineData);

  /** pricing body room pricing data */
  tmplDataSet_timeline_pricing_data_room(loadTimelineData);

  return 1;
}

/**Reservation timeline-table main function plot timeline table use tmpl js */
function plotReservationTable(loadTimelineData) {
  /**reservation heading data plot */
  tmplDataSet_timeline_Header(loadTimelineData);

  /** reservation body guest reservation data */
  tmplDataSet_timeline_reservation_data_guest(loadTimelineData);
  return 1;
}

/* Plot timeline table records by default date on Page load */
function plotData() {
  startDate = document.getElementById('date_checkIn_form').value;
  if (startDate != "") {
    // plot timeline start with start date
    dateStart = parseDate(startDate);
    dateEnd = new Date(dateStart.getFullYear(), dateStart.getMonth() + 1, dateStart.getDate());
    if (document.getElementById("timelineTableType").value == "reservation") {
      get_reservation_timeline_data(dateStart, dateEnd);
    }
    if (document.getElementById("timelineTableType").value == "pricing") {
      get_pricing_timeline_data(dateStart, dateEnd);
    }

  }
}

function get_reservation_timeline_data(dateStart, dateEnd) {
  var loadTimelineData = { "fromDate": DateToYMD(dateStart), "toDate": document.getElementById('date_checkOut_to').value, "adult": document.getElementById('no_adult').value, "child": document.getElementById('no_child').value };
  if (loadTimelineData.formData != "" && loadTimelineData.toDate != "") {
    ajaxRequest("roomtape_timeline", loadTimelineData).done(function (response) {
      if (response.Status === "success") {
        response.Data.startDate = dateStart;
        response.Data.endDate = dateEnd;
        plotReservationTable(response.Data);
      } else {
        plotReservationTable(null);
        flagMsg("warning", "RoomTape records fetch", response.Data, 4000)
      }
    });
  } else {
    flagMsg("warning", "RoomTape records fetch", "Required filed are missing.", 4000)
  }
}

function get_pricing_timeline_data(dateStart, dateEnd) {
  var loadTimelineData = { "fromDate": DateToYMD(dateStart), "toDate": DateToYMD(dateEnd), "ratePlan": document.getElementById('timeline_rate_plan').value };
  if (document.getElementById('timeline_rate_plan').value != "" && dateStart != "") {
    ajaxRequest("inventory_timeline", loadTimelineData).done(function (response) {
      if (response.Status === "success") {
        response.Data.startDate = dateStart;
        response.Data.endDate = dateEnd;
        plotPriceTable(response.Data);
      } else {
        plotPriceTable(null);
      }
    });
  } else {
    timeline_rate_plan_change("timeline_rate_plan");
    flagMsg("warning", "Inventory records fetch", "Required filed are missing.", 4000)
  }
}

function timeline_rate_plan_change(me, isError = false) {
  me = "#" + me;
  if ($(me).val() != "" && $(me).val() != null && isError === false) {
    $(me).removeClass("border border-red");
  } else {
    $(me).addClass("border border-red");
  }
}

$("#timeline_rate_plan").change(function () {
  timeline_rate_plan_change(this.id);
});



/*CURID Operation start */

/** Ajax price value change */
function PriceValueChange(targetId, myPointer) {
  // Ajax Update Price document.getElementById(targetId) check all data Fields
  if (myPointer.value != "" && myPointer.value != null) {
    var data = { "RoomId": document.getElementById(targetId).getAttribute("data-room-id"), "TimeStamp": document.getElementById(targetId).getAttribute("data-timestamp"), "Price": toFloat(myPointer.value) };
    ajaxRequest("inventory_price_update", data).done(function (response) {
      if (response.Status === "success") {
        document.getElementById(targetId).value = "$" + toFloat(myPointer.value);
        flagMsg("warning", "Price Value", response.Data, 5000);
      } else {
        flagMsg("warning", "Price Value", "value not update", 5000);
      }
    });
  } else {
    timeline_rate_plan_change(myPointer.id)
    flagMsg("warning", "Inventory records fetch", "Required filed are missing.", 4000)
  }
}

//Room_type PAGE JS START ------------------------
/**
 * after developent remove the code on gulpfile.js,
 * inside the funciton name vendorExtrasJs src last item "html-src/testapi_roomAndBed_type.html"
*/
var roomsAndBeds_data;
function fetch_roomsAndBeds(hotelId, bedSel, roomSel, page) {
  var loadRoomData = { "hotelId": hotelId };
  //global url;
  ajaxRequest("assets/js/testapi_roomAndBed_type.html", loadRoomData).done(function (response) {
    if (response.status == "success") {
      if (page == "edit") {
        addRoomInfo();
      } else {
        //console.log(response.data);
        roomsAndBeds_data = response.data;
        add_options(response.data.bed, bedSel);
        add_options(response.data.room, roomSel);
      }
    }
    else {
      console.log("rooms And Beds Data not Found");
    }
  });

}

function add_options(data, parent) {
  let dropdown = `<option value="">Select</option>`;
  data.forEach(element => {
    dropdown += `<option value="` + element.type + `">` + element.type + `</option>`;
  });
  $("#" + parent + "").append(dropdown);
}

function add(btn) {
  var div, thing;
  var rem_btn;
  if (btn == "add_bed") {
    div = document.getElementById("beds_div").lastChild;
    rem_btn = "remove_bed";
    thing = "bed";
  }
  else if (btn == "add_room") {
    div = document.getElementById("rooms_div").lastChild;
    rem_btn = "remove_room";
    thing = "room";
  }
  var no = '';
  if (typeof div.id === 'undefined') {
    no = 2;
  }
  else {
    id = parseInt(div.id);
    no = id + 1;
  }
  var next_div;
  var inner_div;
  if (no == 2) {
    inner_div1 = `<div class="lg:grid lg:grid-cols-12 gap-4 -mt-8 multiple_` + thing + `"`;
    $("#" + rem_btn + "").removeClass("hidden");
  }
  else {
    inner_div1 = `<div class="lg:grid lg:grid-cols-12 gap-4 multiple_` + thing + `"`;
  }
  if (btn == "add_bed") {
    next_div =
      inner_div1 + `id="` + no + `" name="bed_div` + no + `">
        <div class="mb-5 col-span-5 ">    
          <div class="mt-2">
            <label class="label block mb-2" for="beds">Bed Type<span class="text-red-600">*</span></label>
            <div class="custom-select" id="beds">
              <select class="form-control" id="bed`+ no + `" name="bed` + no + `" oninput="validate(this.id);" required>`
      /*<option>Select</option>
      <option value="King Bed">King Bed</option>
      <option value="Queen Bed">Queen Bed</option>
      <option value="Double Bed">Double Bed</option>
      <option value="Single Bed">Single Bed</option>
      <option value="Sofa Bed">Sofa Bed</option>
      <option value="Couch">Couch</option>
      <option value="Air Matteress">Air Matteress</option>
      <option value="Bunk Bed">Bunk Bed</option>
      <option value="Floor Mattress">Floor Mattress</option>
      <option value="Toddler Bed">Toddler Bed</option>
      <option value="Crip">Crip</option>
      <option value="Water Bed">Water Bed</option>
      <option value="Hammock">Hammock</option>*/
      + `</select>
              <div class="custom-select-icon la la-caret-down"></div>
            </div>
          </div>    
        </div>
        
        <div class="mb-5 col-span-5 ">       
          <div class="mt-2">
            <label class="label block mb-2" for="bed_quan`+ no + `" >Quantity<span class="text-red-600">*</span></label>
            <input id="bed_quan`+ no + `" name="bed_quan` + no + `" type="number" oninput="checkNo(this.id);" class="form-control" required>
          </div>
        </div>
      </div>`;
    $("#beds_div").append(next_div);
    add_options(roomsAndBeds_data.bed, 'bed' + no + '');
  }
  else if (btn == "add_room") {
    next_div =
      inner_div1 + `id="` + no + `" name="room_div` + no + `">
        <div class="mb-5 col-span-5 ">        
          <div class="mt-2">
            <label class="label block mb-2" for="rooms">Room Type<span class="text-red-600">*</span></label>
            <div class="custom-select" id="rooms">
              <select class="form-control" id="room`+ no + `" name="room` + no + `" oninput="validate(this.id);" required>`
      /*<option>Select</option>
      <option value="Bedroom">Bedroom</option>
      <option value="Hall">Hall</option>
      <option value="Kitchen">Kitchen</option>
      <option value="Bathroom">Bathroom</option>*/
      + `</select>
              <div class="custom-select-icon la la-caret-down"></div>
            </div>
          </div>
        </div>
        
        <div class="mb-5 col-span-5 ">        
          <div class="mt-2">
            <label class="label block mb-2" for="room_quan`+ no + `"">Quantity<span class="text-red-600">*</span></label>
            <input id="room_quan`+ no + `" name="room_quan` + no + `" type="number" oninput="checkNo(this.id);" class="form-control border-gray-500" required>
          </div>
        </div>
      
      </div>`;
    $("#rooms_div").append(next_div);
    add_options(roomsAndBeds_data.room, 'room' + no + '');
  }
  return no;
}

function remove_roombed(btn) {
  var div;
  var sect;
  if (btn == "remove_bed") {
    div = document.getElementById("beds_div").lastChild;
    sect = "bed";
  }
  else if (btn == "remove_room") {
    div = document.getElementById("rooms_div").lastChild;
    sect = "room";
  }
  var no = '';
  if (typeof div.id === 'undefined') {
    if (div.previousElementSibling.id === 'undefined') { }
    else {
      var no = div.previousElementSibling.id;
      if (!(no == 1)) {
        var last_div = document.getElementByName("" + sect + "_div" + no + "");
        last_div.remove();
      }
    }
  }
  else {
    no = div.id;
    var last_div = document.getElementsByName("" + sect + "_div" + no + "")[0];
    last_div.remove();
  }
  if (no == 2) {
    $("#remove_" + sect + "").addClass("hidden");
  }
}
var counter = 0;

function show(id, section) {
  if ($("#" + id + "").hasClass("active")) {
    //document.getElementById(""+id+"_form").reset(); 
    $("#" + section + "").addClass("hidden");
    $("#" + id + "").addClass("active");
    $("#" + section + "").addClass("open");
  } else {
    $(".tabs").addClass("hidden");
    $("#" + section + "").removeClass("hidden");
    $("#" + id + "").removeClass("active");
    document.getElementById(id).style.backgroundColor = "";
    $("#" + section + "").removeClass("open");
  }
}
function addRequired(id) {
  document.getElementById('' + id + '').setAttribute('required', '');
}

function checkNo(id) {
  var val = document.getElementById('' + id + '').value;
  var val1 = parseInt(val);
  if (isNaN(val1)) {
    //$("#" + id + "").addClass("is-invalid");
    document.getElementById(id).style.borderColor = "red";
  } else {
    //$("#" + id + "").removeClass("is-invalid");
    document.getElementById(id).style.borderColor = "";
  }
}

function checkCount(id, id1, id2, e) {
  if (!($("#rooms_num").hasClass("hidden")) /*&& !(document.getElementById(''+id1+'') === null )*/) {
    var count = document.getElementById('' + id1 + '').children.length;
    var limit = document.getElementById('' + id2 + '').value;
    if (count == limit || count == 0) {
      document.getElementById(id).style.borderColor = "";
    } else {
      document.getElementById(id).style.borderColor = "red";
      if (e.type == "blur") {

        flagMsg("warning", "Invalid!", "Room numbers count must be equal to number of rooms", 4000)
      }
    }
  }
}


//rgb(230, 64, 64);
//rgb(203, 76, 76);


function showField(id, e) {
  var rooms = document.getElementById("no_of_rooms").value;
  if (!(rooms == 0) && !(rooms === "")) {
    $("#rooms_num").removeClass("hidden");
  } else {
    if (e.type == "blur") {
      const elements = document.querySelectorAll('.del_roomNo');
      for (element of elements) {
        element.click();
      }
      $("#rooms_num").addClass("hidden");
    }
  }
}

var allCkEditors = [];
// Initialize All CKEditors
allCkEditors = [];
var allHtmlElements = document.querySelectorAll('.editor_box');
for (var i = 0; i < allHtmlElements.length; ++i) {
  ClassicEditor
    .create(allHtmlElements[i])
    .then(editor => {
      allCkEditors.push(editor);
    })
    .catch(error => {
      console.error(error);
    });
}
function ckEditor(name) {
  for (var i = 0; i < allCkEditors.length; i++) {
    if (allCkEditors[i].sourceElement.id === name) return allCkEditors[i];
  }
  return null;
}
var pond;

function LoadFilepond() {
  FilePond.registerPlugin(
    // encodes the file as base64 data
    FilePondPluginFileEncode,
    // validates the size of the file
    FilePondPluginFileValidateSize,
    // corrects mobile image orientation
    FilePondPluginImageExifOrientation,
    // previews dropped images
    FilePondPluginImagePreview,
    //validate File Type
    FilePondPluginFileValidateType
  );
  // Select the file input and use create() to turn it into a pond
  pond = FilePond.create(
    document.getElementById('images'),
    {
      labelIdle: `Drag & Drop your picture or <span class="filepond--label-action">Browse</span>`,
      acceptedFileTypes: ['image/png', 'image/jpeg', 'image/jpg'],
      fileValidateTypeDetectType: (source, type) =>
        new Promise((resolve, reject) => {
          if (!(type == "image/png" || type == "image/jpeg" || type == "image/jpg")) {
            flagMsg("warning", "Alert", "Selected file type is not allowed, png, jpeg, jpg are allowed.", 4000)
          }
          resolve(type)
        }),
    }
  );
  FilePond.setOptions({
    server: './pondfile',
  });
}

let forms = 0;
var valid_data;
function validateForm(ev, id) {
  ev.preventDefault();
  valid_data = 1;

  //Fields of General Info Section
  var roomType_name = $("#roomType_name").val();
  var abbreviation = $("#abbreviation").val();
  var max_adult = $("#max_adult").val();
  var max_children = $("#max_children").val();
  var checkin_hours = $("#checkin_hours").val();
  var checkin_minu = $("#checkin_minu").val();
  var checkin_ampm = $("#checkin_ampm").val();
  var checkOut_hours = $("#checkOut_hours").val();
  var checkOut_minu = $("#checkOut_minu").val();
  var checkOut_ampm = $("#checkOut_ampm").val();
  var basePrice = $("#base_price").val();
  var smoking = ($("#smoking").is(":checked")) ? "1" : "0";
  var pet = ($("#pet").is(":checked")) ? "1" : "0";
  var status = ($("#status").is(":checked")) ? "1" : "0";
  //Fields of Additional Info Section
  var no_of_rooms = $("#no_of_rooms").val();
  var room_nos = [];
  var description = ckEditor("description").getData();
  var images = pond.getFiles();
  //Fields of Room Info section
  var beds = [];
  var rooms = [];
  //Fields of Settings Info Section
  var permit_tax_id = $("#permit_tax_id").val();
  var checkIn_meth = $("#checkIn_meth").val();
  var checkIn_inst = ckEditor("checkIn_inst").getData();
  var infant_inst = ckEditor("infant_inst").getData();
  var cancel_policy = ckEditor("cancel_policy").getData();

  var section;
  var next_id;
  var next_section;
  var room_nos = [];
  if (!($("#rooms_num").hasClass("hidden"))) {
    var count = document.getElementById('badge_group').children;
    for (var i = 0; i < count.length; i++) {
      room_nos.push(count[i].innerText.trim());
    }
  }
  beds = get_data('bed');
  rooms = get_data('room');

  //Validation for General Info Section
  if (id === "general_info_btn" || id === "settings_btn" && valid_data === 1) {
    if (roomType_name == "") {
      document.getElementById("roomType_name").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Name.', 4000);
      valid_data = 0;
    } else if (abbreviation == "") {
      document.getElementById("abbreviation").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Abbreviation.', 4000);
      valid_data = 0;
    } else if (max_adult == "") {
      document.getElementById("max_adult").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Valid Number For Max Adult Allowed.', 4000);
      valid_data = 0;
    } else if (max_children == "") {
      document.getElementById("max_children").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Valid Number For Max Children Allowed.', 4000);
      valid_data = 0;
    } else if (basePrice == "") {
      document.getElementById("base_price").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Valid Number For Base Price.', 4000);
      valid_data = 0;
    }
    section = "general_info";
    next_id = "additional_info";
    next_section = "Additional_Information";
  }

  //Validation for Additional Info Section
  if (id === "additional_info_btn" || id === "settings_btn" && valid_data === 1) {
    if (no_of_rooms == "") {
      document.getElementById("no_of_rooms").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Valid Number For Rooms.', 4000);
      valid_data = 0;
    } else if (room_nos == "" || !(room_nos.length == no_of_rooms)) {
      document.getElementById("room_no").style.borderColor = "red";
      flagMsg("warning", "Insert Room Type", 'Please Insert Room Numbers For All Rooms.', 4000);
      valid_data = 0;
    }
    section = "additional_info";
    next_id = "room_info";
    next_section = "Room_Info";
  }

  //Validation for Room Info section
  if (id === "room_info_btn" || id === "settings_btn" && valid_data === 1) {
    check_data(beds, 'bed');
    if (valid_data == 1) {
      check_data(rooms, 'room');
    }
    section = "room_info";
    next_id = "settings";
    next_section = "Settings";
  }

  if (valid_data === 1) {
    if (id === "settings_btn") {

      //converting beds, rooms and room_no array into json
      beds = JSON.stringify(beds);
      rooms = JSON.stringify(rooms);
      room_no = JSON.stringify(room_nos);
      //sending All forms data to backend
      var formData = new FormData();
      formData.append("roomType_name", roomType_name);
      formData.append("abbreviation", abbreviation);
      formData.append("max_adult", max_adult);
      formData.append("max_children", max_children);
      formData.append("checkin_hours", checkin_hours);
      formData.append("checkin_minu", checkin_minu);
      formData.append("checkin_ampm", checkin_ampm);
      formData.append("checkOut_hours", checkOut_hours);
      formData.append("checkOut_minu", checkOut_minu);
      formData.append("checkOut_ampm", checkOut_ampm);
      formData.append("basePrice", basePrice);
      formData.append("smoking", smoking);
      formData.append("pet", pet);
      formData.append("status", status);
      formData.append("no_of_rooms", no_of_rooms);
      formData.append("room_nos", room_nos);
      formData.append("description", description);
      for (var i in images) {
        formData.append("images", images[i].file);
      }
      formData.append("beds", beds);
      formData.append("rooms", rooms);
      formData.append("permit_tax_id", permit_tax_id);
      formData.append("checkIn_meth", checkIn_meth);
      formData.append("checkIn_inst", checkIn_inst);
      formData.append("infant_inst", infant_inst);
      formData.append("cancel_policy", cancel_policy);
      if (page == "edit") {
        meth = 'update_room_type'
        formData.append("id", roomType_id);
      } else {
        meth = 'add_room_type'
      }
      $.ajax({
        url: APPURL + meth,
        data: formData,
        type: 'POST',
        dataType: "json",
        contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
        processData: false, // NEEDED, DON'T OMIT THIS
        error: function (jqXHR, textStatus, errorThrown) {
          flagMsg("danger", "Insert Room Type", 'Something Went Wrong, Please Try Again!', 4000);
        }
      })
        .done(function (response) {
          if (response.Status === "success") {
            flagMsg("success", "Insert Room Type", response.Data, 4000);
          } else {
            //flagMsg('danger','Error: Get server response', response.Data);
            flagMsg("danger", "Insert Room Type", response.Data, 4000);
          }
          resetFields();
        });
      setTimeout(function () { window.location.href = "roomType_list"; }, 5000);
    }
    else {
      $('#' + section + '').toggleClass('active');
      showNext(next_id, next_section);
    }
  } else {
    if (id === "settings_btn") {
      document.getElementById(section).style.backgroundColor = "rgb(203, 76, 76)";
    }
  }
}

function get_data(thing) {
  var div = document.getElementById("" + thing + "s_div").lastChild;
  var no;
  var arr = [];
  if (typeof div.id === 'undefined') { no = 1 }
  else {
    id = parseInt(div.id);
    no = id;
  }
  for (var i = 0; i < no; i++) {
    y = i + 1;
    arr[i] = {};
    arr[i]["" + thing.charAt(0).toUpperCase() + thing.slice(1) + "_type"] = $("#" + thing + y + "").val();
    arr[i]["Quantity"] = parseInt($('#' + thing + '_quan' + y + '').val());
  }
  return arr;
}

function check_data(arr, thing) {
  for (var i in arr) {
    y = parseInt(i) + 1;

    if (arr[i]["" + thing.charAt(0).toUpperCase() + thing.slice(1) + "_type"] === "") {
      document.getElementById('' + thing + y + '').style.borderColor = "red";
      flagMsg("warning", "Warning", "Please select " + thing.charAt(0).toUpperCase() + thing.slice(1) + y + " type.", 4000)
      valid_data = 0;
      break;
    }
    else if (isNaN(arr[i]["Quantity"])) {
      document.getElementById('' + thing + '_quan' + y + '').style.borderColor = "red";
      flagMsg("warning", "Warning", "Please insert valid number for " + thing.charAt(0).toUpperCase() + thing.slice(1) + y + " quantity.", 4000)
      valid_data = 0;
      break;
    }
  }
}

function validate(id) {
  let data = $("#" + id + "").val();
  if (data == "") {
    document.getElementById(id).style.borderColor = "red";
  } else {
    document.getElementById(id).style.borderColor = "";
  }
}

function showNext(id, section) {
  if ($("#" + id + "").hasClass("active")) {
    $("#" + section + "").addClass("hidden");
  } else {
    $(".tabs").addClass("hidden");
    $(".tabs").removeClass("open");
    $("#" + section + "").removeClass("hidden");
  }
  $("#" + id + "").toggleClass("active");
  $("#" + section + "").toggleClass("open");
}

function resetFields() {
  document.getElementById("room_type").reset();
  //reset CkEditor Fields
  ckEditor("description").setData("");
  ckEditor("checkIn_inst").setData("");
  ckEditor("infant_inst").setData("");
  ckEditor("cancel_policy").setData("");
  //reset Filepond Field
  pond.removeFiles();
  //removing all beds and rooms Fields
  $(".multiple_bed").remove();
  $(".multiple_room").remove();
  //reset room_no field and hiding it
  const elements = document.querySelectorAll('.del_roomNo');
  for (element of elements) {
    element.click();
  }
  $("#rooms_num").addClass("hidden");
}

//Room_type PAGE JS END ------------------------  

//Edit_Room_Type JS Start ----------------------
function get_room_data(hotelId) {
  var loadRoomData = { "hotelId": hotelId };
  ajaxRequest('assets/testapi_roomType.html', loadRoomData).done(function (response) {
    if (response.status == "success") {
      //console.log(response.data);
      if (response.data.hasOwnProperty('bed')) {
        var arr = response.data.bed;
        add_room_data(arr, 'add_bed', 'bed');
      }
      if (response.data.hasOwnProperty('room')) {
        var arr = response.data.room;
        add_room_data(arr, 'add_room', 'room');
      }
    }
    else {
      console.log("Data not Found");
    }
  });
}
function add_room_data(data, btn, thing) {
  let i = 0;
  var no;
  data.forEach(element => {
    if (i == 0) {
      no = 1;
    }
    else {
      no = add(btn);
    }
    let type = document.getElementById('' + thing + no + '');
    let quant = document.getElementById('' + thing + '_quan' + no + '');
    type.value = element.type;
    quant.value = element.quant;
    i++;
  });
}
//Edit_Room_Type JS END -----------------------

// Colors
let colors = {};
colors.primary = "20, 83, 136";
colors.secondary = "38, 119,106";
colors.tirtary = "0, 153,153";
colors.quaternary = "255, 102,102";

// Tooltips Options
const tooltipOptions = {
  backgroundColor: "#ffffff",
  borderColor: "#dddddd",
  borderWidth: 0.5,
  bodyColor: "#555555",
  bodySpacing: 8,
  cornerRadius: 4,
  padding: 16,
  titleColor: "rgba(" + colors.primary + ")",
};


const config = {
  data: {
    labels: "",
    datasets: [{
      type: "line",
      label: "Actual Revenue",
      data: {},
      backgroundColor: "rgba(" + colors.primary + ", .1)",
      // backgroundColor: gradientBackground,
      borderColor: "rgba(" + colors.primary + ")",
      borderWidth: 2,
      fill: true,
      pointBackgroundColor: "#ffffff",
      pointBorderColor: "rgba(" + colors.primary + ")",
      pointBorderWidth: 2,
      pointRadius: 4,
      pointHoverBackgroundColor: "rgba(" + colors.primary + ")",
      pointHoverBorderColor: "#26776a",
      pointHoverBorderWidth: 2,
      pointHoverRadius: 6,
      tension: 0.5,
    }, {
      type: "line",
      label: "System Boosted Revenue",
      data: {},
      backgroundColor: "rgba(" + colors.secondary + ", .1)",
      // backgroundColor: gradientBackground,
      borderColor: "rgba(" + colors.tirtary + ")",
      borderWidth: 2,
      borderDash: [5, 5],
      fill: true,
      pointBackgroundColor: "#ffffff",
      pointBorderColor: "rgba(" + colors.secondary + ")",
      pointBorderWidth: 2,
      pointRadius: 4,
      pointHoverBackgroundColor: "rgba(" + colors.secondary + ")",
      pointHoverBorderColor: "#ffffff",
      pointHoverBorderWidth: 2,
      pointHoverRadius: 6,
      tension: 0.5,
    }, {
      type: "line",
      label: "Compititor Intelligence Revenue",
      data: {},
      backgroundColor: "rgba(" + colors.secondary + ", .1)",
      // backgroundColor: gradientBackground,
      borderColor: "rgba(" + colors.quaternary + ")",
      borderWidth: 2,
      borderDash: [5, 5],
      fill: true,
      pointBackgroundColor: "rgba(" + colors.quaternary + ")",
      pointBorderColor: "rgba(" + colors.quaternary + ")",
      pointBorderWidth: 2,
      pointRadius: 4,
      pointHoverBackgroundColor: "rgba(" + colors.quaternary + ")",
      pointHoverBorderColor: "#ffffff",
      pointHoverBorderWidth: 2,
      pointHoverRadius: 6,
      tension: 0.5,
    },],
  },
  options: {
    plugins: {
      legend: {
        display: true,
        position: "bottom",
      },
      tooltip: tooltipOptions,
    },
    scales: {
      y: {
        grid: {
          display: true,
          drawBorder: false,
        },
        min: 0,
        max: 25,
        ticks: {
          stepSize: 5,
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  },
};
/**Data table code start */
var dt_DataTable;
var checkIn_DataTable;
var checkOut_DataTable;
var activeRes_DataTable;
var _alphabetSearch = '';
/**Filter Card of data table */

function bin(data) {
  var letter, bins = {};
  for (var i = 0, ien = data.length; i < ien; i++) { letter = data[i].charAt(0).toUpperCase(); if (bins[letter]) { bins[letter]++; } else { bins[letter] = 1; } }
  return bins;
}
// Init data table
function initDataTable() {
  var table = $('#test').DataTable({
    responsive: true,
    paging: false,
    info: false,
    "dom": '<"lg:flex"<"#dt_alphabetSearch_main.dt_alphabetSearch_main flex-grow pb-4"><"pb-4"f >>rtip',
    "initComplete": function (settings, json) {
      $.fn.dataTable.ext.search.push(function (settings, searchData) {
        if (!_alphabetSearch) { return true; }
        if (searchData[1].charAt(0).toUpperCase() === _alphabetSearch) { return true; }
        return false;
      });
    }
  });
  var alphabet = $('<div id="dt_alphabetSearch" class=" alphabet"/>').append('<label class="pr-4">Filter: <label>');
  var columnData = table.column(1).data();
  var bins = bin(columnData);
  $('<span class="clear active"/>').data('letter', '').data('match-count', columnData.length).html('All').appendTo(alphabet);
  for (var i = 0; i < 26; i++) { var letter = String.fromCharCode(65 + i); $('<span/>').data('letter', letter).data('match-count', bins[letter] || 0).addClass(!bins[letter] ? 'empty' : '').html(letter).appendTo(alphabet); }
  // alphabet.insertBefore(table.table().container());
  $("#dt_alphabetSearch_main").html(alphabet);
  alphabet.on('click', 'span', function () { alphabet.find('.active').removeClass('active'); $(this).addClass('active'); _alphabetSearch = $(this).data('letter'); table.draw(); });
  return table;
}
/**Filter Card of data table */
// Destroy data table
function destroyDataTable(destroy) {
  return destroy.destroy();
}

function DeleteTableRowRecord() {
  var data = { "id": $(this).attr("data-id") };
  ajaxRequest("http://localhost:4000/testapi_pricing.html", data).done(function (response) {
    if (response.status == "success") {
      flagMsg("success", "Rooms information delete", "Records deleted successfully");
      dt_pagination_toggle(list)
    } else {
      flagMsg("warning", "Rooms information delete", "Records not to be deleted");
    }
  });
}

function actionInitEventDetect(list) {
  // Delete Records
  deleteButton = document.getElementsByClassName("action_delete");
  for (var i = 0; i < deleteButton.length; i++) { deleteButton[i].addEventListener("click", onceCalled); }
}
// Plot Data Table
function getRecords_rooms(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start };
  ajaxRequest("get_rooms", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "roomType";
      dt_DataTable = destroyDataTable(dt_DataTable);
      document.getElementById('rooms_list').innerHTML = tmpl("tmpl-rooms_list", response.Data);
      dt_DataTable = initDataTable();
      actionInitEventDetect("roomType");
    } else if (response.Status === "failure") {
      console.log(response.Data)
    }
    else {
      flagMsg("warning", "Rooms information fetch", "Fetching records failed, Please try again !");
    }
  });
}
function dt_pagination_toggle(my = "limit", list) {
  start_limit = (my == "limit") ? document.getElementById("dt_current_page_info").value : my.value;
  switch (list) {
    case "roomType":
      getRecords_rooms(start_limit);
      break;
    case "allRes":
      get_allReservations(start_limit);
      break;
    case "check-inRes":
      getCheckIn_res(start_limit);
      break;
    case "check-outRes":
      getCheckOut_res(start_limit);
      break;
    case "activeRes":
      getActiveRes(start_limit);
      break;
    case "guests_list":
      getRecords_guests(start_limit);
      break;
  }
}

//Guest List
function getRecords_guests(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start };
  ajaxRequest("all_guest", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "guests_list";
      dt_DataTable = destroyDataTable(dt_DataTable);
      document.getElementById('guest_list').innerHTML = tmpl("tmpl-guest_list", response.Data);
      dt_DataTable = initDataTable();
      actionInitEventDetect("guests_list");
    } else if (response.Status === "failure") {
      console.log(response.Data)
    } else {
      flagMsg("warning", "Rooms information fetch", "Fetching records failed, Please try again !");
    }
  });
}

/*function dt_pagination_toggle(my="limit") {
   start_limit = (my == "limit") ? document.getElementById("dt_current_page_info").value : my.value;
   getRecords_guests(start_limit);
}*/

//All Reservation list
function get_allReservations(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start };
  ajaxRequest("all_reservations", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "allRes";
      dt_DataTable = destroyDataTable(dt_DataTable);
      document.getElementById('allReservations_list').innerHTML = tmpl("tmpl-allReservations_list", response.Data);
      dt_DataTable = initDataTable();
      actionInitEventDetect("allRes");
    } else if (response.Status === "failure") {
      console.log(response.Data)
    } else {
      flagMsg("warning", "Failure", "Data Not Found For Reservations !");
    }
  });
}

function checkIn_list_Miss(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start, "missCheckin": "yes" };
  ajaxRequest("all_reservations", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "allRes";
      dt_DataTable = destroyDataTable(dt_DataTable);
      document.getElementById('allReservations_list').innerHTML = tmpl("tmpl-allReservations_list", response.Data);
      dt_DataTable = initDataTable();
      actionInitEventDetect("allRes");
    } else if (response.Status === "failure") {
      console.log(response.Data)
    } else {
      flagMsg("warning", "Failure", "Data Not Found For Check-Out Miss !");
    }
  });
}

//Reservation to check-In today
function getCheckIn_res(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start };
  ajaxRequest("res_to_checkIn", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "check-inRes";
    } else if (response.Status === "failure") {
      console.log(response.Data)
    } else {
      flagMsg("warning", "Failure", "Reservation Not found For Check-In !");
    }
    dt_DataTable = destroyDataTable(dt_DataTable);
    document.getElementById('checkIn_list').innerHTML = tmpl("tmpl-checkIn_list", response.Data);
    dt_DataTable = initDataTable();
    actionInitEventDetect("check-inRes");
  });
}

//Reservation to check-Out today
function getCheckOut_res(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start };
  ajaxRequest("res_to_checkOut", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "check-outRes";
    } else if (response.Status === "failure") {
      console.log(response.Data)
    } else {
      flagMsg("warning", "Failure", "Reservation Not found For Check-Out !");
    }
    dt_DataTable = destroyDataTable(dt_DataTable);
    document.getElementById('checkOut_list').innerHTML = tmpl("tmpl-checkOut_list", response.Data);
    dt_DataTable = initDataTable();
    actionInitEventDetect("check-outRes");
  });
}

function saveTime(action, resId) {
  var data = { "Action": action, "ResId": resId };
  ajaxRequest("saveTime", data).done(function (response) {
    if (response.Status === "success") {
      flagMsg("Success", "", response.Data, 5000);
      if (action == "Checked-In") {
        getCheckIn_res()
      } else {
        window.location.href = "reservation_invoice?id=" + resId;
      }
    } else {
      flagMsg("warning", "Failure", "Something Went Wrong, Please Try Again !");
    }
  });
}

//Active Reservations
function getActiveRes(start = 0) {
  limit_start = ($("#dt_limit_item_show").val() != "" && $("#dt_limit_item_show").val() != undefined) ? $("#dt_limit_item_show").val() : "10";
  var data = { "StartLimit": start, "LimitRows": limit_start };
  ajaxRequest("active_res", data).done(function (response) {
    if (response.Status === "success") {
      response.Data.QueryDetails.List = "activeRes";
    } else if (response.Status === "failure") {
      console.log(response.Data)
    } else {
      flagMsg("warning", "Failure", "Data Not Found For Active Reservation !");
    }
    dt_DataTable = destroyDataTable(dt_DataTable);
    document.getElementById('activeRes_list').innerHTML = tmpl("tmpl-activeRes_list", response.Data);
    dt_DataTable = initDataTable();
    actionInitEventDetect("activeRes");

  });
}

function manage(resId) {
  window.location.href = "editable_invoice?id=" + resId;
}

/**./ Data table code */

//Check Email function check email is existed or not, if existed then message shown "Email already registered".
function check_email() {
  var email_check = document.getElementById("signup_email").value;
  if (email_check != "") {
    register_check_email = {
      "register_check_email": email_check
    }
    ajaxRequest("email_check", register_check_email).done(function (response) {
      if (response.status == "success") {
        if (response.email_present == true) {
          $("#register_button").attr("disabled", true);
          $("#exist_email").addClass("border-red-400");
          $("#exist_email").show();
        } else {
          $("#register_button").removeAttr("disabled");
          $("#exist_email").hide();
          $("#exist_email").removeClass("border-red-400");

        }
      } else {
        $("#register_button").removeAttr("disabled");
        $("#exist_email").hide();
        $("#exist_email").removeClass("border-red-400");
      }
    });
  } else {
    $("#register_button").removeAttr("disabled");
    $("#exist_email").hide();
    $("#exist_email").removeClass("border-red-400");
  }
}


function sendHotelData(e, id) {
  e.preventDefault();
  var hotel_name = $("#hotel_name").val();
  var primary_customer = $("#primary_customers").val();
  var nearest_competitor = $("#nearest_competitor").val();
  var years_in_operation = $("#years_in_operation").val();
  var high_traffic_months = [];
  var status = $("#backend_status").val();
  var hotel_rating;

  //getting high_traffic_months entered by user
  var count = document.getElementById('months_group').children;
  for (var i = 0; i < count.length; i++) {
    high_traffic_months.push(count[i].innerText.trim());
  }
  //getting hotel_rating
  var count = document.getElementById('rating').children;
  for (var i = 0; i < count.length; i++) {
    id = count[i].id;
    if ($('#' + id + '').hasClass('active')) {
      hotel_rating = id;
    }
  }

  var hotel_unique_id = $('#WebHotelName_list option').filter(function () {
    return this.value == hotel_name;
  }).data('uniqueid');
  var formData = new FormData();
  formData.append("hotel_name", hotel_name);
  formData.append("primary_customer", primary_customer);
  formData.append("nearest_competitor", nearest_competitor);
  formData.append("years_in_operation", years_in_operation);
  formData.append("high_traffic_months", high_traffic_months);
  formData.append("hotel_rating", hotel_rating);
  formData.append("hotel_unique_id", hotel_unique_id);
  var des;
  if (status == "true") {
    formData.append("status", status);
    formData.append("saved_months", saved_months);
    formData.append("hotel_id", $("#hotel_id").val());
    des = 'update_hotel';
  } else {
    des = 'add_hotel';
  }

  $.ajax({
    url: APPURL + des,
    data: formData,
    type: 'POST',
    dataType: "json",
    contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
    processData: false, // NEEDED, DON'T OMIT THIS
    error: function (jqXHR, textStatus, errorThrown) {
      //flagMsg('danger','Error: Get server response', 'Something went wrong, please try again.');
      flagMsg("danger", 'Failure', 'Something went wrong, please try again.', 4000)
    }
  })
    .done(function (response) {
      if (response.Status === "success") {
        flagMsg("success", 'Success', response.Data, 4000);
        $('.close_questionarie').click();
      } else {

        flagMsg("danger", 'Failure', response.Data, 4000);
      }
      //resetFields();
    });
}

//Payment page hide show according to payment type
let prev_id = "";
var getPayType;
function display_hide_card_details(type_of_data, id) {
  getPayType = id
  if (type_of_data == "Credit Card") {
    $('#' + id).addClass('bg-gray-900 dark:text-gray-400');

    $('#cash').removeClass('bg-gray-900 dark:text-gray-400');
    $('#bank_transfer').removeClass('bg-gray-900 dark:text-gray-400');
    $("#hidden_bank_transfer").hide();
    $("#hidden_cash").hide();
    $("#hidden_credit_card_data").show();
  } else if (type_of_data == "Cash") {
    $('#' + id).addClass('bg-gray-900 dark:text-gray-400');
    $('#credit_card').removeClass('bg-gray-900 dark:text-gray-400');
    $('#bank_transfer').removeClass('bg-gray-900 dark:text-gray-400');
    $("#hidden_credit_card_data").hide();
    $("#hidden_bank_transfer").hide();
    $("#hidden_cash").show();
  } else if (type_of_data == "Bank Transfer") {
    $('#' + id).addClass('bg-gray-900 dark:text-gray-400');
    $('#cash').removeClass('bg-gray-900 dark:text-gray-400');
    $('#credit_card').removeClass('bg-gray-900 dark:text-gray-400');
    $("#hidden_credit_card_data").hide();
    $("#hidden_cash").hide();
    $("#hidden_bank_transfer").show();
  }
  else {
    $('#' + id).toggleClass('bg-gray-900 dark:text-gray-400');
  }
}

//For Add Rooms button in Rooms 
function AddRoomsFunc() {
  window.location.href = "room_type";
}

//Adding row first name and last name in Guest Page

function addNewRow() {
  if (guest_val1 < (Total_members - 1)) {
    $('#id_add_row').append('<div class="delete_guest' + guest_val1 + ' lg:grid lg:grid-cols-9 gap-4"> <div class="mb-2  col-span-4 "><label class="label block mb-2" for="first_name_add">First Name <span class="text-red-600">*</span></label> <input id="add_new_fname_one' + guest_val1 + '" type="text" class="form-control guest" placeholder="Enter First Name" autocomplete="off" required > </div> <div class="mb-2 delete_guest' + guest_val1 + ' col-span-4"><label class="label block mb-2" for="last_name_add">Last Name <span class="text-red-600">*</span></label> <input id="add_new_lname_one' + guest_val1 + '" type="text" class="form-control guest" placeholder="Enter Last Name" autocomplete="off" required></div> <div class="col-span-1 "><button type="button" class="btn btn_primary lg:mt-7 rounded-full dark:text-gray-100 hover:text-white dark:hover:text-white  text-lg mb-1 leading-none la la-trash la-lg w-14 delete_guest' + guest_val1 + '" " onclick="deleteNewRow(' + guest_val1 + ')"></button></div></div>');
    guestaddArray.push(guest_val1);
    guest_val1 = guest_val1 + 1;
  } else {
    flagMsg("danger", "Sorry", "Exceeded maximum number of adding members !");
  }
}

//Deletion func to delete row 
function deleteNewRow(guest_val1) {
  $('.delete_guest' + guest_val1).remove();
  const index = guestaddArray.indexOf(guest_val1);
  if (index > -1) {
    guestaddArray.splice(index, 1);
  }
  guest_val1 = guest_val1 - 1;
}

function addNewEditRow() {
  if (temp_arr.length < (Total_person)) {
    $('#id_edit_add_guestrow').append('<div class="delete_guest' + guest_val1 + ' lg:grid lg:grid-cols-9 gap-4"> <div class="mb-2  col-span-4 "><label class="label block mb-2" for="first_name_add">First Name <span class="text-red-600">*</span></label> <input id="edit_fname_one' + guest_val1 + '" type="text" class="form-control guest" placeholder="Enter First Name" autocomplete="off" required > </div> <div class="mb-2 delete_guest' + guest_val1 + ' col-span-4"><label class="label block mb-2" for="last_name_add">Last Name <span class="text-red-600">*</span></label> <input id="edit_lname_one' + guest_val1 + '" type="text" class="form-control guest" placeholder="Enter Last Name" autocomplete="off" required></div> <div class="col-span-1 "><button type="button" class="btn btn_primary lg:mt-7 rounded-full dark:text-gray-100 hover:text-white dark:hover:text-white  text-lg mb-1 leading-none la la-trash la-lg w-14 delete_guest' + guest_val1 + '" " onclick="deleteEditNewRow(' + guest_val1 + ')"></button></div></div>');
    temp_arr.push(guest_val1);
    guest_val1 = guest_val1 + 1;
  } else {
    flagMsg("danger", "Sorry", "Exceeded maximum number of adding members !");
  }

}

//Deletion func to delete row 
function deleteEditNewRow(guest_val1) {
  $('.delete_guest' + guest_val1).remove();
  const index = temp_arr.indexOf(guest_val1);
  if (index > -1) {
    temp_arr.splice(index, 1);
  }
  guest_val1 = guest_val1 - 1;
}

  //Toggle Price Table Code Start in reservation page was in edit_collect.html
  $("#chk_due_depo_toggle").change(function () {
    if ($(this).is(":checked")) {
        $("#due_depo").hide();
        $("#toggle_value").val(toFloat($("#due_depo").html()));
        $("#toggle_value").show();
    } else {
        $("#toggle_value").hide();
        $("#due_depo").show();
    }

});

$("#toggle_value").change(function () {
    //status ajax success 
    // console.log($('#toggle_value').val() < $('#trip_total').html(),$('#toggle_value').val(),$('#trip_total').html())
    if (toFloat($('#toggle_value').val()) < toFloat($('#trip_total').html())) {
        let balance_total = toFloat($('#trip_total').html()) - toFloat($('#toggle_value').val());
        $("#due_depo").html("$" + numberWithCommas($('#toggle_value').val()));
        $('#need_to_pay').html(numberWithCommas($('#toggle_value').val()));
        $('#balance').html(numberWithCommas(balance_total.toFixed(2)));
    } else {
        balance_total = toFloat($('#trip_total').html()) - toFloat($('#trip_total').html());
        $("#due_depo").html("$" + numberWithCommas($('#trip_total').html()));
        $('#need_to_pay').html(numberWithCommas($('#trip_total').html()));
        $('#balance').html(numberWithCommas(balance_total.toFixed(2)));
        flagMsg("danger", "Sorry", "Due deposit is over than trip total !", 5000)
    }

    $("#toggle_value").hide();
    $("#due_depo").show();
    $("#chk_due_depo_toggle").prop('checked', false)
});
//Toggle Price Table Code End


/* Ajax collect page  Search rooms table */
function search_rooms_collect(user_Id) {
  let checkIn = $('#checkin').val();
  let checkOut = $('#checkout').val();
  let adult = $('#reservation_collect_adult').val();
  let children = $('#reservation_collect_child').val();
  let rate_plan = $('#reservation_collect_rack_rate').val();
  let userId = user_Id;
  if (adult != "" && children != "") {
    var data = {
      "checkIn": checkIn,
      "checkOut": checkOut,
      "adult": adult,
      "children": children,
      "rate_plan": rate_plan,
      "userId": userId,
    };
    ajaxRequest("reservation_collect_ajax", data).done(function (response) {
      if (response.status == "success") {
        Plot_tableDataAdd(response);
      } else {
        flagMsg("danger", "Error", "Not able to update !");
      }
    });

  } else {
    flagMsg("danger", "Sorry", "Please fill all the fields !", 5000);
  }
}


function addcollect_CheckMark(id) {
  $('#' + id).addClass("bg-green-500");
  $('#' + id).removeClass("bg-gray-300");
  $('#' + id).html("<span class='text-7xl text-white' id='delete3'>&#10003;</span>");
  $('#' + id).addClass("can_delete3");
  $('#aa').show();
}

function price_table(room_price, incidentals, fee, Rtax1, Rtax2, adult, child, checkIN, checkOut, total_room_charges, vatTax1, vatTax2) {
  $('#next_id_to_guest ').show();

  // room tax
  total_rooms = parseInt(total_room_charges) / parseInt(room_price);

  Roomtax1 = TaxCalculation(room_price, Rtax1) * total_rooms;
  Roomtax2 = TaxCalculation(room_price, Rtax2) * total_rooms;
  Roomtax = Roomtax1 + Roomtax2;
  // trip Total Price 
  total_price = parseFloat(total_room_charges) + parseFloat(incidentals) + parseFloat(fee) + Roomtax;

  // add vat vax
  VAttax1 = TaxCalculation(total_price, vatTax1);
  VAttax2 = TaxCalculation(total_price, vatTax2);
  VAttax = VAttax1 + VAttax2;
  total_price = total_price + VAttax;
  let balance_price = total_price - Number(room_price);
  $("#room_tax_value").html(numberWithCommas(Roomtax.toFixed(2)));
  $('#checkinDate').html(checkIN);
  $('#checkOutDate').html(checkOut);
  $('#total_room_charges').html(numberWithCommas(total_room_charges));
  $('#trip_total').html(numberWithCommas(total_price.toFixed(2)));
  $("#vat_tax_value").html(numberWithCommas(VAttax.toFixed(2)));
  $('#due_depo').html("$" + numberWithCommas(total_price.toFixed(2)));
  $('#need_to_pay').html(room_price);
  $('#balance').html(numberWithCommas(balance_price.toFixed(2)));
  $('#adult_collect').html(adult);
  $('#child_collect').html(child);

  // 
  $("#reserv_room_tax_1").val(Roomtax1);
  $("#reserv_room_tax_2").val(Roomtax2);
  $("#reserv_vat_tax_1").val(VAttax1);
  $("#reserv_vat_tax_2").val(VAttax2);
}


//TaxCalculation: returnval = rate * (percent * %) where % is 0.01
function TaxCalculation(rate, percent) {
  return parseFloat(rate) * (parseFloat(percent) * parseFloat(0.01))
}


//Sidebar Price menu code in reservation page start
var total_room_price = 0;
var toggleNumber_forButtonAdd = 0;
var add_id_for_update_collect_selected_room;
var selectecd_room_id;
var getRoomNo;
function updatePriceInfoAdd(e, id_table, room_price, total_price, tax1, tax2, vat1, vat2) {
  let checkinDate = $('#reservation_collect_checkInVal1').val();
  let checkoutDate = $('#reservation_collect_checkOutVal1').val();
  let add_adult = $('#reservation_collect_adult').val();
  let add_child = $('#reservation_collect_child').val();
  let id_of_room = $(e).attr('id');
  selectecd_room_id = id_table.trim();
  getRoomNo = $('#getRoomNo' + selectecd_room_id).val();
  let incidentals = 0;
  let fee = 0;

  if (toggleNumber_forButtonAdd == 0) {
    toggleNumber_forButtonAdd = selectecd_room_id;
    addcollect_CheckMark(id_of_room);
    price_table(room_price, incidentals, fee, tax1, tax2, add_adult, add_child, checkinDate, checkoutDate, total_price, vat1, vat2);
  } else {

    if (toggleNumber_forButtonAdd != selectecd_room_id) {
      addcollect_RemoveCheckMark(toggleNumber_forButtonAdd);
      price_table(room_price, incidentals, fee, tax1, tax2, add_adult, add_child, checkinDate, checkoutDate, total_price, vat1, vat2);
      addcollect_CheckMark(id_of_room);
      toggleNumber_forButtonAdd = selectecd_room_id;

    }
  }
  add_id_for_update_collect_selected_room = selectecd_room_id;
}
function addcollect_RemoveCheckMark(id) {
  $('#selectBtn' + id).removeClass("bg-green-500");
  $('#selectBtn' + id).addClass("bg-gray-300");
  $('#selectBtn' + id).html("<span class='select_text text-blue-900 hover:text-white focus:text-white cursor-pointer'>SELECT</span>");
  $('#selectBtn' + id).removeClass("can_delete3");
  $('#aa').show();
}


/* Ajax Submit data for revervation_collect page*/
function save_reservation_collect(user_Id) {
  let collect_checkIn = $('#checkin').val();
  let collect_checkOut = $('#checkout').val();
  let collect_adult = $('#reservation_collect_adult').val();
  let collect_child = $('#reservation_collect_child').val();
  let collect_rack_rate = $('#reservation_collect_rack_rate').val();
  let room_charges = $('#total_room_charges').html();
  let trip_total = $('#trip_total').html();
  let due_depo = toFloat($.trim($('#due_depo').html()));
  let user_id = user_Id;
  var data = {
    "collect_checkIn": collect_checkIn,
    "collect_checkOut": collect_checkOut,
    "collect_adult": collect_adult,
    "collect_child": collect_child,
    "collect_rack_rate": collect_rack_rate,
    "selectecd_room_id": selectecd_room_id,  //room_type_id
    "user_id": user_id,
    "getRoomNo": getRoomNo.trim(),  //This is for room number
    "room_charges": room_charges,
    "trip_total": trip_total,
    "due_depo": due_depo,
    "room_tax_1": $("#reserv_room_tax_1").val(),
    "room_tax_2": $("#reserv_room_tax_2").val(),
    "vat_tax_1": $("#reserv_vat_tax_1").val(),
    "vat_tax_2": $("#reserv_vat_tax_2").val()
  };
  if (collect_checkIn != "" && collect_checkOut != "" && collect_adult && collect_child != "" && collect_rack_rate != "" && room_charges != "" && trip_total && due_depo != "") {
    ajaxRequest("reservation_collect_saveData", data).done(function (response) {
      if (response.status == "success") {
        window.location.href = "reservation_guest?id=" + response.res_id + "";
      } else {
        flagMsg("danger", "Sorry", "Data not saved,Please try after some time !");
      }
    });
  } else {
    flagMsg("danger", "Sorry", "Please select the Room to move to the further process!");
  }
}

//  Search guest for add guest reservation
function SearchGuest(e) {
  let get_name_toSearch = $('#search_guest_name').val();
  get_name_toSearch = $.trim(get_name_toSearch.replace(/\s+/g, ' '));
  if (get_name_toSearch.length != 0) {
    var key = event.keyCode || event.charCode;
    if (key == 8 || key == 46 || key == undefined || key == 13 || key == 40) {
      return false;
    } else {
      if (get_name_toSearch.length > 3) {
        let data = {
          "guest_name": get_name_toSearch
        }
        $('#select_guest').empty();
        ajaxRequest("search_guest_ajax", data).done(function (response) {
          if (response.status == "success") {
            if (response.guestName_resp != null) {
              response.guestName_resp.forEach(function (element) {
                $('#select_guest').append('<option data-value="' + element.Id + '" value="' + element.First_name + " " + element.Last_name + " " + "(" + element.Email + ")" + '"></option>')
              });
            }

          }
        });
      }
    }
  }
  else {
    $('#select_guest').empty();
  }
}

//Datalist get option id by selecting Option dynamically
/*document.querySelector('#search_guest_name').addEventListener('input', function(e) {
  var input = e.target,  
      list = input.getAttribute('list'),
      options = document.querySelector('#' + list + ' option[value="'+input.value+'"]'),
      hiddenInput = document.getElementById(input.getAttribute('id') + '-hidden');
    hiddenInput.value =  options.getAttribute('data-value');
  });*/

function Get_guest_data() {
  let guest_id = $('#search_guest_name-hidden').val();
  let data = {
    "guest_Id": guest_id
  }
  ajaxRequest("search_guest_ajax_byId", data).done(function (response) {
    if (response.status == "success") {
      $('#add_guest_fname').val(response.guestData_resp[0].First_name);
      $('#add_guest_lname').val(response.guestData_resp[0].Last_name);
      $('#add_guest_email').val(response.guestData_resp[0].Email);
      $('#add_guest_phone').val(response.guestData_resp[0].Phone.String);
      $('#add_guest_address').val(response.guestData_resp[0].Address.String);
      $('#add_guest_city').val(response.guestData_resp[0].City.String);
      $('#add_guest_state').val(response.guestData_resp[0].State.String);
      $('#add_guest_country').val(response.guestData_resp[0].Country.String);
      $('#add_guest_zip_code').val(response.guestData_resp[0].Zip_code.Int64);

    }
    else {
      flagMsg("danger", "Sorry", "No Guest found !");
    }
  });
}

/* Ajax Update data for edit guest table*/
function guest_submit(user_Id) {
  let fname = $.trim($('#add_guest_fname').val());
  let lname = $.trim($('#add_guest_lname').val());
  let email = $.trim($('#add_guest_email').val());
  let phone = $.trim($('#add_guest_phone').val());
  let address = $.trim($('#add_guest_address').val());
  let city = $.trim($('#add_guest_city').val());
  let state = $.trim($('#add_guest_state').val());
  let country = $.trim($('#add_guest_country').val());
  let zip = $.trim($('#add_guest_zip_code').val());
  let due_deposit = toFloat($.trim($('#due_depo').html()));
  if (getPayType == "cash") {
    var cash_date = $('#guest_cash_date').val();
    var bank_transc_date = "";
    var transaction_id = "";
  } else {
    if (getPayType == "bank_transfer") {
      var cash_date = "";
      if ($('#Id_transc').val() != "") {
        $('#Id_transc').removeClass("border border-red");
        var transaction_id = $('#Id_transc').val();
        var bank_transc_date = $('#guest_bank_transaction_date').val();
      } else {
        $('#Id_transc').addClass("border border-red");
        throw new Error('Please Enter value of Transaction ID');
      }
    }
  }
  let user_id = user_Id;
  let extra_name = [];
  let reservation_id = $('#reservation_getId').val();
  let guest_id = $('#search_guest_name-hidden').val();
  let temp_data;
  for (let i = 0; i < guestaddArray.length; i++) {
    temp_data = {
      "fname": $.trim($('#add_new_fname_one' + guestaddArray[i]).val()),
      "lname": $.trim($('#add_new_lname_one' + guestaddArray[i]).val())
    };
    extra_name.push(temp_data);
  }
  data1 = JSON.stringify(extra_name);
  if (fname != "" && lname != "" && lname != "" && email != "" && getPayType != "") {
    var data = {
      "fname": fname,
      "lname": lname,
      "email": email,
      "phone": phone,
      "address": address,
      "city": city,
      "state": state,
      "country": country,
      "zip_code": zip,
      "extra_name": data1,
      "user_id": user_id,
      "length_of_extraG": guestaddArray.length,
      "reservation_id": reservation_id,
      "guest_id": guest_id,
      "getPayType": getPayType,
      "cash_date": cash_date,
      "bank_transc_date": bank_transc_date,
      "transaction_id": transaction_id,
      "due_deposit": due_deposit

    };
    if (guestaddArray.length <= 0) {
      ajaxRequest("reservation_guest_ajax", data).done(function (response) {
        if (response.status == "success") {
          window.location.href = "reservation_confirm?id=" + reservation_id + ""
        }
      })
    } else {
      $('.guest').each(function (i, obj) {
        if (obj.value != "") {
          $(this).removeClass("border border-red");
          if (((guestaddArray.length * 2) - 1) === i) {
            var isTrue = checkValues();
            if (isTrue) {
              ajaxRequest("reservation_guest_ajax", data).done(function (response) {
                if (response.status == "success") {
                  window.location.href = "reservation_confirm?id=" + reservation_id + ""
                } else {
                  flagMsg("danger", "Error", "Please fill form first !");
                }
              });
            }
          }
        } else {
          $(this).addClass("border border-red");
        }
      });
    }

  } else {
    flagMsg("danger", "Sorry", "Please fill all required fields !");
  }
}


function checkValues() {
  let check = true;
  $('.guest').each(function (i, obj) {
    if (obj.value == "") {
      check = false;
    }
  });
  return check;
}

function pdfPrint() {
  window.html2canvas = html2canvas;
  const doc = document.getElementById("print-area");

  if (doc) {
    var pdf = new jspdf.jsPDF("l", "pt", "a2");
    pdf.html(doc, {
      callback: function (pdf) {
        pdf.save("DOC.pdf");
      }
    });
  }
}

function normalPrint() {
  html2canvas(document.querySelector("#print-area"), {
    allowTaint: true,
    useCORS: true
  }).then((canvas) => {
    var tWindow = window.open("");
    tWindow.document.body.appendChild(canvas);
    tWindow.print();
  });
}
function remove(id, url) {
  $("#" + id + "").toggleClass("active");
  window.location.assign(url);
}


//Adding new Data into the table
function add_InvoiceData(resId) {
  let invoice_item = $('#invoice_item').val();
  let invoice_quantity = $('#invoice_quantity').val();
  let invoice_unitPrice = $('#invoice_unitPrice').val();
  if (invoice_item != "" && invoice_quantity != "" && invoice_unitPrice != "") {

    var data = {
      "res_Id": resId,
      "invoice_item": invoice_item,
      "invoice_quantity": invoice_quantity,
      "invoice_unitPrice": invoice_unitPrice
    }
    ajaxRequest("save_invoice_table", data).done(function (response) {
      if (response.status == "success") {
        showInvoiceData(resId)
        $('#invoice_quantity').val("");
        $('#invoice_item').val("");
        $('#invoice_unitPrice').val("");
      } else {
        flagMsg("danger", "Sorry", "Data not saved,Please try after some time");
      }
    });
  } else {
    flagMsg("danger", "Sorry", "Please fill all required fields", 4000);
  }
}

function addInvoiceAllData(invoiceResData) {
  $('#table_invoice_data').empty();
  invoiceResData.forEach(function (element) {
    if (element.InvId != 0) {
      $('#table_invoice_data').append('<tr class="text-center" id="invoice' + element.InvId + '"> <td>' + element.GetTime_date + '</td><td>' + element.GetTime_kitchen + '</td><td class="inline_edit_data" id="update_item">' + element.Items + '</td><td class="inline_edit_data" id="update_quantity">' + element.Quantity + '</td><td class="inline_edit_data" id="update_unit_price">$' + numberWithCommas(element.Unit_price) + '</td><td>$' + numberWithCommas((element.ServiceTax1 + element.ServiceTax2).toFixed(2)) + '</td><td>$' + numberWithCommas(element.Total_price) + '</td><td class="whitespace-nowrap"> <div class="inline-flex ml-auto"> <div id="editBtn' + element.InvId + '"><button onclick="edit_invoice_Inline(' + element.InvId + ')" class="btn btn-icon btn_outlined btn_secondary"><span class="la la-pen-fancy"></span></button></div><div id="delBtn' + element.InvId + '"><button onclick="delete_invoice(' + element.Res_id + ',' + element.InvId + ')" class="btn btn-icon btn_outlined btn_danger ml-2"><span class="la la-trash-alt"></span></button></div></div></td></tr>');
    }
  });
}

function edit_invoice_Inline(inv_id) {
  var element = document.getElementById('invoice' + inv_id);
  var reserv_id = $('#resIdForInv').val();
  var subElement = element.getElementsByClassName("inline_edit_data");
  for (let index = 0; index < subElement.length; index++) {
    if (subElement[index].id + inv_id == "update_item" + inv_id) {
      subElement[index].innerHTML = '<input type="text" class="form-control" id="' + subElement[index].id + inv_id + '" value="' + subElement[index].innerHTML + '"/>';
    } else {
      subElement[index].innerHTML = '<input type="text" class="form-control" id="' + subElement[index].id + inv_id + '" value="' + toFloat(subElement[index].innerHTML) + '"/>';
    }
  }
  document.getElementById("editBtn" + inv_id).innerHTML = '<button type="button" class="btn btn_primary text-xs" onclick="updateInvoice(' + reserv_id + ',' + inv_id + ')">Update</button>'
  document.getElementById("delBtn" + inv_id).innerHTML = '<button type="button" class="btn btn_danger text-xs ml-2" onclick="Cancel(' + reserv_id + ')">Cancel</button>'
}

//Delete Invoice Data by Id
function delete_invoice(res_id, invid) {
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      var data = {
        "invoice_id": invid
      }
      ajaxRequest("delete_invoice_data", data).done(function (response) {
        if (response.status == "success") {
          let getLength = $('#table_invoice_data tr').length;
          flagMsg("success", "Success", "Data deleted successfully !", 4000);
          if (getLength <= 1) {
            $('#headRow').hide()
            $('#table_invoice_data').empty();
            $("#inv_editgrand_total").html("");
          } else {
            $('#headRow').show()
            showInvoiceData(res_id)
          }
        } else {
          flagMsg("danger", "Sorry", "Data not deleted,Try after sometime !", 4000);
        }
      });
    }
  })
}

//Update Invoice Data by Id
function updateInvoice(resId, invid) {
  let invoice_item = $('#update_item' + invid).val();
  let invoice_quantity = $('#update_quantity' + invid).val();
  let invoice_unitPrice = $('#update_unit_price' + invid).val();
  if (invid != "") {
    var data = {
      "id": invid,
      "invoice_item": invoice_item,
      "invoice_quantity": invoice_quantity,
      "invoice_unitPrice": invoice_unitPrice
    }
    ajaxRequest("update_invoice_table", data).done(function (response) {
      if (response.status == "success") {
        showInvoiceData(resId)
        flagMsg("success", "Success", "Data updated successfully !", 4000);
      } else {
        flagMsg("danger", "Sorry", "Data not updated,Please try after some time !");
      }
    });
  } else {
    flagMsg("danger", "Sorry", "Please fill all required fields !", 4000);
  }
}

function showInvoiceData(res_id) {
  ajaxRequest("fetch_invoice_data", { "res_id": res_id }).done(function (response) {
    if (response.getData != null) {
      $('#headRow').show()
      if (response.status == "success") {
        addInvoiceAllData(response.getData);
        $('#inv_editgrand_total').html("$" + numberWithCommas(response.totalSum));
        $("#int_to_inWords").html(IntToWord(response.totalSum));
      }
    } else {
      $('#headRow').hide()
    }

  });
}

function Cancel(res_id) {
  showInvoiceData(res_id)
}

function FinalInvoicePrint(res_data) {
  ajaxRequest("final_invoice_with_service", { "resid": res_data }).done(function (response) {
    if (response.status === "success") {
      if (response.invoice == null) {
        $('#headRowInvoice').hide()
      } else {
        $('#headRowInvoice').show()
        addFinalInInvoice(response.invoice)
      }
      Final_Invoice_ploat_and_calculation(response, response.totalSum)
    }
  });
}

function Final_Invoice_ploat_and_calculation(dataPlot, totalSum) {
  var notSure =0.00;
  $('#total_inv_sum').html(totalSum);
   $('.invoice_hotelName').html(dataPlot.data.Confirm.Hotel_name);
   $('#hotel_name').html(dataPlot.data.Confirm.Hotel_name);
   $('#invoice_hotel_address').html(dataPlot.data.Confirm.Hotel_address);
   $('#invoice_name').html(dataPlot.data.Confirm.First_name);
  $('#finalInv_paid').html(notSure);
  $('#finalInv_balance').html(notSure);
  $('#invoice_incidental').html(notSure);
  $('#invoice_fee').html(notSure);
  // $('#invoice_hotel_phone').html(element.HotStr.Hotel_phone);
  // $('#total_inv_sum').html("$" + element.InvStr.TotalSum);
  $('#finalroom_charges').html(dataPlot.data.Confirm.Room_charges);
  $('#finalroom_tax1').html(dataPlot.data.Roomtax.RoomTax1);
  $('#finalroom_tax2').html(dataPlot.data.Roomtax.RoomTax2);
   var totalValForVatCalc =  GetTotalValueFor_VatCalc();
   $('#invoice_vat_1').html(dataPlot.VATTax1);
   $('#invoice_vat_2').html(dataPlot.VATTax2);
  // $('#finalInv_paid').html("$" + element.ColStr.Due_depo);
  // var balance = element.ColStr.Room_charges - element.ColStr.Due_depo
  // $('#finalInv_balance').html("$" + balance);
  // var grand_total = element.InvStr.TotalSum + balance + tax;
  // $('#grand_total').html("$" + grand_total);
  var GrandSum = totalValForVatCalc+Number( $('#invoice_vat_1').html())+Number( $('#invoice_vat_2').html());
  $('#grand_total').html(GrandSum);
  $("#int_to_inWords").html(IntToWord(totalSum));
  // $("#image_src").attr("src", element.RoomImg.Images.String);
  // $('#todayDate').html(todayDate);
  // $('#res_idForbook').html(element.ColStr.Id);
  // $('#final_name').html(element.GuesStr.First_name + " " + element.GuesStr.Last_name);

  // $('#total_inv_sum').html(response.totalSum);
  // // $("#int_to_inWords").html(IntToWord(response.totalSum));
}
function GetTotalValueFor_VatCalc(){
  var room_chg = $('#finalroom_charges').html();
  var room_tax1= $("#finalroom_tax1").html();
  var room_tax2= $("#finalroom_tax2").html();
  var total_inv_sum = $('#total_inv_sum').html();
  var RateforVatCalc =  Number(total_inv_sum)+Number(room_chg)+Number(room_tax1)+Number(room_tax2);
  return RateforVatCalc;
}

//Show Data in Invoice Final Page
function addFinalInInvoice(invoiceResData) {
  $('#invoice_InvStr').empty();
  invoiceResData.forEach(function (element) {
    if (element.InvId != 0) {
      $('#invoice_InvStr').append('<tr class="text-center" id="invoice' + element.InvId + '"> <td>' + element.GetTime_date + '</td><td>' + element.GetTime_kitchen + '</td><td class="inline_edit_data" id="update_item">' + element.Items + '</td><td class="inline_edit_data" id="update_quantity">' + element.Quantity + '</td><td class="inline_edit_data" id="update_unit_price">$' + numberWithCommas(element.Unit_price) + '</td><td>$' + (element.ServiceTax1).toFixed(2) + " + $" + numberWithCommas((element.ServiceTax2).toFixed(2)) + '</td><td>$' + numberWithCommas((element.Total_price) + '</td></tr>'));
    }
  });
}

function getTodayDate() {
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0');
  var yyyy = today.getFullYear();

  today = mm + '/' + dd + '/' + yyyy;
  return today;
}
function roomType_edit(roomType_id) {
  window.location.href = "show_roomType_edit?RoomType_id=" + roomType_id + ""
}

function GetCollectDataToEdit(res_id) {
  data = {
    "res_id": res_id
  }
  ajaxRequest("getedit_collect_data", data).done(function (res) {
    if (res.status == "success") {
      $('#edit_collect_checkInVal1').val(res.edit_data.CheckIn);
      $('#edit_collect_checkOutVal1').val(res.edit_data.CheckOut);
      $('#edit_collect_adult').val(res.edit_data.Adult);
      $('#edit_collect_child').val(res.edit_data.Child);
      $('#edit_collect_rack_rate').val(res.edit_data.Collect_rack_rate);
      price_table(res.edit_data.Due_depo, 0, 0, 44.65, 44.65, res.edit_data.Adult, res.edit_data.Child, res.edit_data.CheckIn, res.edit_data.CheckOut, res.edit_data.Room_charges, 1, 2)

      let getRoomdata = {
        "checkIn": res.edit_data.CheckIn,
        "checkOut": res.edit_data.CheckOut,
        "adult": res.edit_data.Adult,
        "children": res.edit_data.Child
      }
      ajaxRequest("getedit_Roomscollect_data", getRoomdata).done(function (resp) {
        if (resp.status == "success") {
          Plot_tableDataEdit(resp.val, res.edit_data);
          $('#getEditRoomNo' + res.edit_data.Room_type_id).append('<option selected class="border-b-0">' + res.edit_data.Room_no + '</option>');
          var getFunc = $('#selectBtnEdit' + res.edit_data.Room_type_id).attr("onclick");
          $('#getEditRoomNo' + res.edit_data.Room_type_id).attr('onChange', getFunc);
          previous_select_roomAdd = res.edit_data.Room_type_id;
        } else {
          flagMsg("danger", "Sorry", "Please try after some time !", 4000);
        }
      });
    } else {
      flagMsg("danger", "Sorry", "Please try after some time !", 4000);
    }
  });
}
function addCheckMark(edit_data) {
  $('#selectBtnEdit' + edit_data).addClass("bg-green-500");
  $('#selectBtnEdit' + edit_data).removeClass("bg-gray-300");
  $('#selectBtnEdit' + edit_data).html("<span class='text-7xl text-white' id='delete3'>&#10003;</span>");
  $('#selectBtnEdit' + edit_data).addClass("can_delete" + edit_data);
  $('#aa').show();
}

function removeCheckMark(toggleNumber_forButton) {
  room_remove_id(toggleNumber_forButton);
}

function room_remove_id(id) {
  $('#selectBtnEdit' + id).removeClass("bg-green-500");
  $('#selectBtnEdit' + id).addClass("bg-gray-300");
  $('#selectBtnEdit' + id).html("<span class='text-blue-900'>SELECT</span>");
  $('#selectBtnEdit' + id).removeClass("can_delete" + id);
}

//Sidebar Price menu code in Edit Collect page start
var previous_select_roomAdd;
function updatePriceInfoEditable(id_table, room_price, total_price) {
  let checkinDate = $('#edit_collect_checkInVal1').val();
  let checkoutDate = $('#edit_collect_checkOutVal1').val();
  let add_adult = $('#edit_collect_adult').val();
  let add_child = $('#edit_collect_child').val();
  selectecd_room_id = id_table;
  getRoomNo = $('#getEditRoomNo' + id_table).val();
  let tax = 44.65;
  let incidentals = 0;
  let fee = 0;
  if (toggleNumber_forButtonAdd == 0) {
    toggleNumber_forButtonAdd = id_table;
    if (previous_select_roomAdd > 0) {
      room_remove_id(previous_select_roomAdd);
      previous_select_roomAdd = 0;
    }
    addCheckMark(id_table);
    price_table(room_price, incidentals, fee, tax, tax, add_adult, add_child, checkinDate, checkoutDate, total_price, 1, 2);
  } else {
    if (toggleNumber_forButtonAdd != id_table) {
      removeCheckMark(toggleNumber_forButtonAdd);
      price_table(room_price, incidentals, fee, tax, tax, add_adult, add_child, checkinDate, checkoutDate, total_price, 1, 2);
      addCheckMark(id_table);
      toggleNumber_forButtonAdd = id_table;

    }
  }
  add_id_for_update_collect_selected_room = id_table;
}

/* Ajax Update data for revervation_collect page*/
function update_reservation_collect(user_Id, res_Id) {
  let collect_checkIn = $('#edit_collect_checkInVal1').val();
  let collect_checkOut = $('#edit_collect_checkOutVal1').val();
  let collect_adult = $('#edit_collect_adult').val();
  let collect_child = $('#edit_collect_child').val();
  let collect_rack_rate = $('#edit_collect_rack_rate').val();
  let room_charges = $('#total_room_charges').html();
  let trip_total = $('#trip_total').html();
  let due_depo = toFloat($.trim($('#due_depo').html()));
  let user_id = user_Id;

  var data = {
    "collect_checkIn": collect_checkIn,
    "collect_checkOut": collect_checkOut,
    "collect_adult": collect_adult,
    "collect_child": collect_child,
    "collect_rack_rate": collect_rack_rate,
    "selectecd_room_id": selectecd_room_id,
    "user_id": user_id,
    "resId": res_Id,
    "room_charges": room_charges,
    "getRoomNo": getRoomNo,
    "trip_total": trip_total,
    "due_depo": due_depo
  };
  if (collect_checkIn != "" && collect_checkOut != "" && collect_adult && collect_child != "" && collect_rack_rate != "" && room_charges != "" && trip_total && due_depo != "" && res_Id != 0) {
    ajaxRequest("update_collect_saveData", data).done(function (response) {
      if (response.status == "success") {
        window.location.href = "edit_guest?id=" + res_Id + "";
      } else {
        flagMsg("danger", "Sorry", "Data not saved,Please try after some time !");
      }
    });
  } else {
    flagMsg("danger", "Sorry", "Please select the Room to move to the further process!");
  }
}
//Sidebar Price menu code in Edit Collect page End

/* Ajax Update data for revervation_collect page*/
function search_Editrooms_collect(user_Id) {
  let checkIn = $('#checkin').val();
  let checkOut = $('#checkout').val();
  let adult = $('#edit_collect_adult').val();
  let children = $('#edit_collect_child').val();
  let rate_plan = $('#edit_collect_rack_rate').val();
  let userId = user_Id;
  $('#aa').hide();
  if (adult != "" && children != "") {
    var data = {
      "checkIn": checkIn,
      "checkOut": checkOut,
      "adult": adult,
      "children": children,
      "rate_plan": rate_plan,
      "userId": userId,
    };
    ajaxRequest("getedit_Roomscollect_data", data).done(function (getData) {
      if (getData.status == "success") {
        Plot_tableDataEdit(getData.val, "");
      } else {
        flagMsg("danger", "Error", "Not able to update !");
      }
    });

  } else {
    flagMsg("danger", "Sorry", "Please fill all the fields !", 5000);
  }
}
//show edit guest data
function showGuestDataInEdit(res_id) {
  var data = {
    "res_id": res_id
  }
  ajaxRequest("getedit_guest_ajax", data).done(function (response) {
    if (response.status == "success") {
      $('#edit_guest_fname').val(response.guestData[0].First_name);
      $('#edit_guest_lname').val(response.guestData[0].Last_name);
      $('#edit_guest_email').val(response.guestData[0].Email);
      $('#edit_guest_phone').val(response.guestData[0].Phone.String);
      $('#edit_guest_address').val(response.guestData[0].Address.String);
      $('#edit_guest_city').val(response.guestData[0].City.String);
      $('#edit_guest_state').val(response.guestData[0].State.String);
      $('#edit_guest_country').val(response.guestData[0].Country.String);
      $('#edit_guest_zip_code').val(response.guestData[0].Zip_code.Int64);
      $('#guestId').val(response.guestData[0].GuestId);
      Total_person = Number(response.guestData[0].Adult) + Number(response.guestData[0].Child);
      response.guestData.forEach(function (element) {
        if (element.AddGuestId.Int64 != 0) {
          temp_arr.push(element.AddGuestId.Int64);
        }
        guest_val1 = element.AddGuestId.Int64;
        if (element.AddF_name.String != "") {
          $('#id_edit_add_guestrow').append('<div class="delete_guest' + guest_val1 + ' lg:grid lg:grid-cols-9 gap-4"> <div class="mb-2  col-span-4 "><label class="label block mb-2" for="first_name_add">First Name <span class="text-red-600">*</span></label> <input id="edit_fname_one' + guest_val1 + '" type="text" class="form-control guest" placeholder="Enter First Name" autocomplete="off" required > </div> <div class="mb-2 delete_guest' + guest_val1 + ' col-span-4"><label class="label block mb-2" for="last_name_add">Last Name <span class="text-red-600">*</span></label> <input id="edit_lname_one' + guest_val1 + '" type="text" class="form-control guest" placeholder="Enter Last Name" autocomplete="off" required></div> <div class="col-span-1 "><button type="button" class="btn btn_primary lg:mt-7 rounded-full dark:text-gray-100 hover:text-white dark:hover:text-white  text-lg mb-1 leading-none la la-trash la-lg w-14 delete_guest' + guest_val1 + '" " onclick="deleteEditNewRow(' + guest_val1 + ')"></button></div></div>');
          $('#edit_fname_one' + element.AddGuestId.Int64).val(element.AddF_name.String);
          $('#edit_lname_one' + element.AddGuestId.Int64).val(element.AddL_name.String);
        }
      });
      guest_val1 = guest_val1 + 1;
    }
  });
}

/* Ajax Update data for edit guest table*/
function updateGuestEdit(user_Id, resId) {
  let edit_fname = $.trim($('#edit_guest_fname').val());
  let edit_lname = $.trim($('#edit_guest_lname').val());
  let edit_email = $.trim($('#edit_guest_email').val());
  let edit_phone = $.trim($('#edit_guest_phone').val());
  let edit_address = $.trim($('#edit_guest_address').val());
  let edit_city = $.trim($('#edit_guest_city').val());
  let edit_state = $.trim($('#edit_guest_state').val());
  let edit_country = $.trim($('#edit_guest_country').val());
  let edit_zip = $.trim($('#edit_guest_zip_code').val());
  let guest_id = $('#guestId').val();
  let user_id = user_Id;
  let extra_name = [];
  let reservation_id = resId;

  for (let i = 0; i < temp_arr.length; i++) {
    var temp_name = {
      "fname": $.trim($('#edit_fname_one' + temp_arr[i]).val()),
      "lname": $.trim($('#edit_lname_one' + temp_arr[i]).val())
    };
    extra_name.push(temp_name);
  }
  data1 = JSON.stringify(extra_name);
  if (edit_fname != "" && edit_lname != "" && edit_email != "") {
    var data = {
      "fname": edit_fname,
      "lname": edit_lname,
      "email": edit_email,
      "phone": edit_phone,
      "address": edit_address,
      "city": edit_city,
      "state": edit_state,
      "country": edit_country,
      "zip_code": edit_zip,
      "extra_name": data1,
      "user_id": user_id,
      "length_of_extraG": temp_arr.length,
      "reservation_id": reservation_id,
      "guest_id": guest_id
    };
    if (temp_arr.length <= 0) {
      ajaxRequest("update_guest_ajax_edit", data).done(function (response) {
        if (response.status == "success") {
          window.location.href = "reservation_confirm?id=" + reservation_id + ""
        }
      })
    } else {
      $('.guest').each(function (i, obj) {
        if (obj.value != "") {
          $(this).removeClass("border border-red");
          if (((temp_arr.length * 2) - 1) === i) {
            var isTrue = checkValues();
            if (isTrue) {
              ajaxRequest("update_guest_ajax_edit", data).done(function (response) {
                if (response.status == "success") {
                  window.location.href = "reservation_confirm?id=" + reservation_id + ""
                } else {
                  flagMsg("danger", "Error", "Please fill form first !");
                }
              });
            }
          }
        } else {
          $(this).addClass("border border-red");
        }
      });
    }

  } else {
    flagMsg("danger", "Sorry", "Please fill all required fields !");
  }
}

//Send reservation Id from reservation_list to Edit Reservation to edit the reservation
function edit_reservationFromList(reserv_id) {
  window.location.href = "edit_collect?id=" + reserv_id + "";
}

//This is responsible for adding new reservation from reservation_list page,Checkin,checkout page and from active reservation through 
//(Add Reservation Button)
function to_reservation() {
  window.location.href = "reservation_collect";
}

//This is responsible to redirecting the page from guest_list to adding new guest
function guestPage() {
  window.location.href = "reservation_guest?id=addguestonly";
}

//This is responsible for adding new guest to guest table
function SubmitGuestOnly(userId) {
  let fname = $.trim($('#add_guest_fname').val());
  let lname = $.trim($('#add_guest_lname').val());
  let email = $.trim($('#add_guest_email').val());
  let phone = $.trim($('#add_guest_phone').val());
  let address = $.trim($('#add_guest_address').val());
  let city = $.trim($('#add_guest_city').val());
  let state = $.trim($('#add_guest_state').val());
  let country = $.trim($('#add_guest_country').val());
  let zip = $.trim($('#add_guest_zip_code').val());

  let user_id = userId;

  if (fname != "" && lname != "" && email != "") {
    var data = {
      "fname": fname,
      "lname": lname,
      "email": email,
      "phone": phone,
      "address": address,
      "city": city,
      "state": state,
      "country": country,
      "zip_code": zip,
      "user_id": user_id,
    };
    ajaxRequest("addguest_only", data).done(function (response) {
      if (response.status == "success") {
        window.location.href = "guest_list"
      }
    })
  } else {
    flagMsg("danger", "Sorry", "Please try after some time !");
  }
}

//get page to edit the data of guest after the redirection of to edit guest page
function EditGuestOnly(guestId) {
  window.location.href = "edit_guest?guest=" + guestId;
}


//this function is responsible for to show the prefilled data according to guest id
function showGuestData_only(guestId) {
  var data = {
    "guestId": guestId
  }
  ajaxRequest("guestdata_ajax", data).done(function (response) {
    if (response.status == "success") {
      $('#edit_guest_fname').val(response.guestData[0].First_name);
      $('#edit_guest_lname').val(response.guestData[0].Last_name);
      $('#edit_guest_email').val(response.guestData[0].Email);
      $('#edit_guest_phone').val(response.guestData[0].Phone.String);
      $('#edit_guest_address').val(response.guestData[0].Address.String);
      $('#edit_guest_city').val(response.guestData[0].City.String);
      $('#edit_guest_state').val(response.guestData[0].State.String);
      $('#edit_guest_country').val(response.guestData[0].Country.String);
      $('#edit_guest_zip_code').val(response.guestData[0].Zip_code.Int64);
    }

  });
}
//Update guest without the reservation Id. Only need guest Id to update the data in table
function updateGuestOnly(userId, guestId) {
  let fname = $.trim($('#edit_guest_fname').val());
  let lname = $.trim($('#edit_guest_lname').val());
  let email = $.trim($('#edit_guest_email').val());
  let phone = $.trim($('#edit_guest_phone').val());
  let address = $.trim($('#edit_guest_address').val());
  let city = $.trim($('#edit_guest_city').val());
  let state = $.trim($('#edit_guest_state').val());
  let country = $.trim($('#edit_guest_country').val());
  let zip = $.trim($('#edit_guest_zip_code').val());

  let user_id = userId;

  if (fname != "" && lname != "" && email != "") {
    var data = {
      "fname": fname,
      "lname": lname,
      "email": email,
      "phone": phone,
      "address": address,
      "city": city,
      "state": state,
      "country": country,
      "zip_code": zip,
      "user_id": user_id,
      "guest_Id": guestId
    };
    ajaxRequest("updateguest_only", data).done(function (response) {
      if (response.status == "success") {
        window.location.href = "guest_list"
      }
    })
  } else {
    flagMsg("danger", "Sorry", "Please try after some time !");
  }
}

//Delete guest record which don't have binded with reservation Id
function DeleteGuestRecord(guestId) {
  alert()
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      var data = {
        "guestId": guestId
      };
      ajaxRequest("delete_guest_Only", data).done(function (response) {
        if (response.status == "success") {
          flagMsg("success", "Success", "Guest deleted successfully !", 3000);
          window.location.href = "guest_list"
        } else {
          if (response.status == "err1451") {
            flagMsg("danger", "Sorry", "Reservation existed for the guest !", 3000);
          } else {
            flagMsg("danger", "Sorry", "Please try after some time !", 3000);
          }
        }
      });


    }
  })
}

//Delete reservation by id record which don't have reservation Id as foreign Key
function DeleteReservationbyID(resId) {
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      var data = {
        "reservationId": resId
      };
      ajaxRequest("delete_reservation_throughId", data).done(function (response) {
        if (response.status == "success") {
          flagMsg("success", "Success", "Guest deleted successfully !", 3000);
          window.location.href = "reservation_list"
        } else {
          if (response.status == "err1451") {
            flagMsg("danger", "Sorry", "Reservation existed for the guest !", 3000);
          } else {
            flagMsg("danger", "Sorry", "Please try after some time !", 3000);
          }
        }
      });

    }
  })
}

//Delete room by id record which don't have room id as foreign Key

function DeleteRoombyID(roomType_id) {
  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      var data = {
        "Room_type_id": roomType_id
      };
      ajaxRequest("delete_room_throughId", data).done(function (response) {
        if (response.status == "success") {
          flagMsg("success", "Success", "room deleted successfully !", 3000);
          window.location.href = "roomType_list";
        } else {
          if (response.status == "err1451") {
            flagMsg("danger", "Sorry", "Reservation existed for the guest !", 3000);
          } else {
            flagMsg("danger", "Sorry", "Please try after some time !", 3000);
          }
        }
      });

    }

  })
}


function AppendHotel_NamesList(storedNames) {
  $("#WebHotelName_list").html("");
  $("#hotel_listCompetitors").html("");
  storedNames.forEach(element => $("#WebHotelName_list").append("<option data-uniqueid='" + element[0] + "' value='" + element[1] + "'>" + element[1] + "</option>"));
  storedNames.forEach(element => $("#hotel_listCompetitors").append("<option data-uniqueid='" + element[0] + "' value='" + element[1] + "'>" + element[1] + "</option>"));
}

//Fetch Country from the DB for Signup Page
function fetchcountries() {
  ajaxRequest("fetchCountry_name", "").done(function (response) {
    if (response.status == "success") {
      $('#country_lists').empty();
      $("#get_state").val("");
      $("#get_city").val("");
      $('#get_state-hidden').val(null);
      response.country.forEach(element => {
        $("#country_lists").append("<option data-value=" + element.Id + " >" + element.Country + "</option>");
      })
    }
  });
}

//Fetch state if Country is selected for Signup Page
function fetchStates(eve) {
  var Cid = $('#get_country-hidden').val();
  if (Cid != "") {
    var data = {
      "countryId": Cid
    };
    ajaxRequest("fetchStates_name", data).done(function (response) {
      if (response.status == "success") {
        $('#state_lists').empty();
        $("#get_city").val("");
        if (response.state != null) {
          response.state.forEach(element => {
            $("#state_lists").append("<option data-value=" + element.Id + ">" + element.State + "</option>");
          })
        } else {
          if (eve.type !== "keyup") {
            flagMsg("danger", "Sorry", "No States are available !", 3000);
          }
        }

      }
    });
  } else {
    if (eve.type !== "keyup") {
      flagMsg("danger", "Sorry", "Please select Country !", 3000);
    }
  }
}

//Fetch city if state and country is selected for Signup Page
function fetchCities(eve) {
  var Cid = $('#get_country-hidden').val();
  var Sid = $('#get_state-hidden').val();
  if (Cid == "") {
    if (eve.type !== "keyup") {
      flagMsg("danger", "Sorry", "Please select Country and State!", 3000);
    }
  } else {
    if (Sid != "") {
      var data = {
        "stateId": Sid
      };
      ajaxRequest("fetchcity_name", data).done(function (response) {
        if (response.status == "success") {
          $('#city_lists').empty();
          if (response.city != null) {
            response.city.forEach(element => {
              $("#city_lists").append("<option data-value=" + element.Id + ">" + element.City + "</option>");
            })
          } else {
            if (eve.type !== "keyup") {
              flagMsg("danger", "Sorry", "No cities are available!", 3000);
            }
          }

        }
      });
    } else {
      if (eve.type !== "keyup") {
        flagMsg("danger", "Sorry", "Please select State!", 3000);
      }
    }
  }
}

//Signup ajax code
function SignupUser() {
  let signup_fname = $.trim($('#signup_fname').val());
  let signup_lname = $.trim($('#signup_lname').val());
  let signup_email = $.trim($('#signup_email').val());
  let signup_phone = $.trim($('#signup_phone').val());
  let signup_password = $.trim($('#password1').val());
  let signup_city = $.trim($('#get_city-hidden').val());
  if (signup_fname != "" && signup_lname != "" && signup_email != "" && signup_phone != "" && signup_city != "" && signup_password != "") {
    var data = {
      "signup_fname": signup_fname,
      "signup_lname": signup_lname,
      "signup_email": signup_email,
      "signup_phone": signup_phone,
      "signup_password": signup_password,
      "signup_city": signup_city,
    };
    ajaxRequest("signupAjax", data).done(function (response) {
      if (response.status == "success") {
        flagMsg("success", "Success", " An Email has been sent to your Email-ID. Please Verify to complete the registration!", 5000);
        setTimeout(function () { window.location.href = "signup" }, 3000);
      } else {
        flagMsg("danger", "Sorry", "Account not created. You need to signup again  !", 3000);
      }
    })
  } else {
    flagMsg("danger", "Sorry", "Please fill all the required fields !", 3000);
  }
}


function questionnaire_modal() {
  //Modal opening on document load
  $('#welcome-modal-questionnaire').addClass('modal active');
}

//Till now used in Questionnaire Modal
//insert tag input data
//zzz anonymous function remov
function insertTag(inputId, outputId) {
  document.getElementById(inputId).addEventListener("keypress", insertNewItemOnTags);
}
function insertNewItemOnTags(e) {
  var regex = /[,]/g;
  this.value = this.value.replace(regex, '');
  $("#error_multipicker").html("");
  $(this).val($(this).val().trim());
  if (e.keyCode == 0 || e.keyCode == 32 || e.keyCode == 13 || e.keyCode == 44) {
    if (this.value.length <= 1) {
      this.value = "";
    } else {
      this.value = toKamelCase(this.value.replace(regex, ''));
      groupSelection = String($(this).data("output"));
      child = document.getElementById(groupSelection).children;
      flag_items_avaialbe = false;
      for (var i = 0; i < child.length; i++) {
        if (toKamelCase(child[i].innerText) == this.value) {
          flag_items_avaialbe = true;
          break;
        }
      }
      if (flag_items_avaialbe) {
        $("#error_multipicker").html("Item already exist.");
      } else {
        insertflag = false;
        if (groupSelection == "months_group") {
          $("#months_name_list").find("#monthName_" + this.value).remove();
          if (MONTH_NAMES.includes(this.value)) {
            insertflag = true;
          } else {
            $("#error_multipicker").html("Input month name");
          }
        } else {
          insertflag = true;
        }
        if (insertflag) {
          $('#' + groupSelection).append('<span id="delete' + (child.length + 1) + '" class="badge badge_primary">' + this.value + ' <button type="button" class="focus:outline-none ml-1 la la-times del_roomNo" onclick="deleteTag(\'delete' + (child.length + 1) + '\',\'' + groupSelection + '\')" ></button></span>');
        }
      }
      this.value = "";
    }
  }
}

//delete tag input data
function deleteTag(index, flagRemoveBadge = "true") {
  control_remove = $("#" + index);
  control_remove.remove();
  if (flagRemoveBadge == "badge_group") {
    checkCount('room_no', 'badge_group', 'no_of_rooms', event);
  }
  if (flagRemoveBadge == "months_group") {
    OPtionVal = toKamelCase(control_remove.text());
    if (MONTH_NAMES.includes(OPtionVal)) {
      $("#months_name_list").append("<option id='monthName_" + OPtionVal + "' value=" + OPtionVal + ">" + OPtionVal + "</option>");
    }
  }
}

// fetch Hotel list
function getHotelListPlotOnSuggesionList(hotel_address) {
  var data = JSON.parse(hotel_address);
  ajaxRequest("getHotel", data, true).done(function (response) {
    if (response.Status === "success") {
      AppendHotel_NamesList(response.Data);
    }
  })
  // High Traffic Months list
  MONTH_NAMES.forEach(monthName => { $("#months_name_list").append("<option id='monthName_" + monthName + "' value=" + monthName + ">" + monthName + "</option>"); });
}

//this function call on dashboard page only
function set_local_stroage_hotel_place_value(hotel_place_value) {
  getHotelListPlotOnSuggesionList(hotel_place_value);
  questionnaire_modal();
}

//hint warning of input box
function add_valid_hint_msg(p_id, message = "") {
  document.getElementById(p_id).innerText = message;
}

//hint warning of input box
function check_valid_tax(this_p) {
  tax_value = parseFloat($(this_p).val());
  // console.log(">>.",$(this).attr("id"));
  if (tax_value > 0 && tax_value <= 100) {
    $(this_p).removeClass("border-red");
    add_valid_hint_msg("error_" + $(this_p).attr("id"));
  } else {
    $(this_p).addClass("border-red");
    add_valid_hint_msg("error_" + $(this_p).attr("id"), "Input any number from 1 to 100");
  }
}
//update tax value
function UpdateTaxValue(this_p) {
  tax_value = parseFloat($(this_p).val());
  column = ($(this_p).data("column"));
  if (column != "" && tax_value > 0 && tax_value <= 100) {
    add_valid_hint_msg("error_" + this_p.id);
    update_setting_taxes(this_p, column, tax_value);
  } else {
    check_valid_tax(this_p);
  }
}

//get user setting
function getUserSetting() {
  ajaxRequest("getdataUserSettings", null).done(function (getData) {
    if (getData.Status === "success") {
      document.getElementById("room_tax_1").value = getData.Data.RoomTax1;
      document.getElementById("room_tax_2").value = getData.Data.RoomTax2;
      document.getElementById("room_service_tax_1").value = getData.Data.RoomServiceTax1;
      document.getElementById("room_service_tax_2").value = getData.Data.RoomServiceTax2;
      document.getElementById("vat_tax_1").value = getData.Data.VATTax1;
      document.getElementById("vat_tax_2").value = getData.Data.VATTax2;
    }
  });
}

function update_hotel_name_from_list(id_of_control) {
  document.getElementById(id_of_control.getAttribute("error")).innerHTML = "";
  child = document.getElementById(id_of_control.getAttribute("list")).children;
  flag_items_not_avaialbe = true;
  for (var i = 0; i < child.length; i++) {
    if (toKamelCase(child[i].value) === toKamelCase(id_of_control.value)) {
      flag_items_not_avaialbe = false;
      break;
    }
  }
  if (flag_items_not_avaialbe) {
    document.getElementById(id_of_control.getAttribute("error")).innerHTML = "Please check the hotel name.";
  }
}

//check logout status
checkLoginStatus = setInterval(() => {
  ignorePage = [APPURL, APPURL + "index", APPURL + "signup", APPURL + "under_progress", APPURL + "email_success", APPURL + "forgot_password", APPURL + "change_password", APPURL + "token_verify"];
  // ignore extra url line with # and peram (ater ?)
  if (!ignorePage.includes((String(window.location).split("?")[0].split("#")[0]))) {
    var request = new XMLHttpRequest();
    request.open("POST", APPURL + "checkLoginStatus");
    // Defining event listener for readystatechange event
    request.onreadystatechange = function () {
      // Check if the request is compete and was successful
      if (this.readyState === 4 && this.status === 200) {
        if (this.responseText != "loggedin") {
          clearInterval(checkLoginStatus);
          window.location = APPURL;
        }
      }
    };
    request.send();
  } else {
    clearInterval(checkLoginStatus);
  }

}, LogIn_Status_Check_Interval * 1000);


var a = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

function inWords(num) {
  if ((num = num.toString()).length > 12) return 'overflow';
  n = ('000000000000' + num).substr(-12).match(/^(\d{1})(\d{2})(\d{1})(\d{2})(\d{1})(\d{2})(\d{1})(\d{2})$/);
  console.log(n)
  if (!n) return; var str = '';
  str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + '' + a[n[1][1]]) + ' Hundred ' : '';
  str += (n[2] != 0) ? (a[Number(n[2])] || ((n[2][1] == 0) ? b[n[2][0]] + "" : b[n[2][0]] + '-') + a[n[2][1]]) + ' Billion ' : '';
  str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + '' + a[n[3][1]]) + ' Hundred ' : '';
  str += (n[4] != 0) ? (a[Number(n[4])] || ((n[4][1] == 0) ? b[n[4][0]] + "" : b[n[4][0]] + '-') + a[n[4][1]]) + ' Million ' : '';
  str += (n[5] != 0) ? (a[Number(n[5])] || b[n[5][0]] + '-' + a[n[5][1]]) + ' Hundred ' : '';
  str += (n[6] != 0) ? (a[Number(n[6])] || ((n[6][1] == 0) ? b[n[6][0]] + "" : b[n[6][0]] + '-') + a[n[6][1]]) + ' Thousand ' : '';
  str += (n[7] != 0) ? (a[Number(n[7])] || b[n[7][0]] + '-' + a[n[7][1]]) + ' Hundred ' : '';
  str += (n[8] != 0) ? (a[Number(n[8])] || ((n[8][1] == 0) ? b[n[8][0]] + "" : b[n[8][0]] + '-') + a[n[8][1]]) + ' ' : '';

  return str;
}
function DecimalPortion(num) {
  let valueString = "";
  for (var i = 0; i < num.length; i++) {
    valueString = valueString + " " + inWords(num.charAt(i)).trim();
  }
  return valueString;
}

function IntToWord(IntString) {
  price = String(toFloat(String(IntString))).split(".");
  decimalP = (price[1] != undefined && price[1] > 0) ? "<i class='text-gray-600'> [dot]" + DecimalPortion(price[1]) + "</i> " : " only";
  return toKamelCase(inWords(price[0]).trim() + decimalP);
}