function checkRequired(element){
    var required_attr = $(element).attr("required");
    if(required_attr!==undefined) {
      return true;
    } else {
      return false;
    }
  }
  
  function validateLength(element , pattern="") {
    let val = $(element).cleanVal();
    let patternString = pattern.replace(/[^A-Z0-9]/ig, "");
    // let value = $(element).val();
    let is_required = checkRequired(element);
    let id = $(element).attr('id');
    
    if (element.hasClass("reak_accountno_validate")) {
      let account_number = $('#' + id).val();
      account_number_array = account_number.split("");
      // alert(account_number_array);
      if ((is_required == false || is_required == "false")) {
  
      } else if ((is_required == true || is_required == "true")) {
        /* Checking whether every number in account number is 0 or not
          if it is true then mark it as invalid */
        let is_valid = account_number_array.every((e) => e == 0);
  
        if (!is_valid) {
            $('#' + id).get(0).setCustomValidity("");
            console.debug("Valid Pattern");
            document.getElementById(id).style.borderColor = "";
        } else {
            $('#' + id).get(0).setCustomValidity("Invalid Pattern");
            console.debug("Invalid Pattern");
            document.getElementById(id).style.borderColor = "red";
          // return_value = false;
        }
      } else {
          $('#' + id).get(0).setCustomValidity("Invalid Pattern");
          console.debug("Invalid Pattern");
          document.getElementById(id).style.borderColor = "red";
  
        // return_value = false;
      }
    } else if(element.hasClass('reak_ifsc_validate')) {
      if(val.length == patternString.length || ((is_required == false || is_required == "false") && (val.length == 0)) ){
              $('#'+id).get(0).setCustomValidity("");
              console.debug("Valid Pattern");                      
              document.getElementById(id).style.borderColor = "";   
      } else {
              $('#'+id).get(0).setCustomValidity("Invalid Pattern");
              console.debug("Invalid Pattern");  
              document.getElementById(id).style.borderColor = "red";                         
      }
    } else {
      
      console.debug(val.length, " ---- ", patternString.length);
      if (val.length == patternString.length) {
        $('#'+id).get(0).setCustomValidity("");
        console.debug(val.length, "--------Valid Length");
        $('#'+id).removeClass("border-red-300");
      } else {
        $('#'+id).get(0).setCustomValidity("Invalid Length");
        $('#'+id).addClass("border-red-300");
      }
    }
   
  }
  
  function validatePattern(element, regex_pattern, msg) {
    let inputVal = $(element).val();
    var id_name = $(element).attr('id');
    if(inputVal.match(regex_pattern)) {
        console.debug("Valid ",msg);
        $('#'+id_name).get(0).setCustomValidity(""); 
        $('#'+id_name).removeClass("border-red-300"); 
    } else {
        console.debug("You have entered an invalid ",msg);
        $('#'+id_name).get(0).setCustomValidity("Invalid "+msg); 
        $('#'+id_name).addClass("border-red-300"); 
    }
  }
  $( document ).ready(function() {
    $('.reak_mobile_validate').mask('(000) 000-0000');
    $(".reak_mobile_validate").attr('placeholder', '(000) 000-0000');
    $('.reak_mobile_validate').on("keyup", function() {
      // alert("yes");
      let element = $(this);
      let mobile_pattern  = '(000) 000-0000';
    
       console.log(mobile_pattern);
       console.log("mobile Pattern Length-"+mobile_pattern.length);
       var patternString = mobile_pattern.replace(/[^A-Z0-9]/ig, "");
      
      validateLength(element, mobile_pattern);
    });
    
    $('.reak_zip_validate').mask('S0S 0S0');
    $(".reak_zip_validate").attr('placeholder', 'S0S 0S0');
    $('.reak_zip_validate').on("keyup",function() {
      let element = $(this);
      let zip_pattern = "S0S 0S0";
      validateLength(element, zip_pattern); 
    });
    $('.reak_landline_validate').mask('(000) 000-0000');
    $(".reak_landline_validate").attr('placeholder', '(000) 000-0000');
    $(".reak_landline_validate").on('change keyup', function() {
      let element = $(this);
      let landline_pattern = '(000) 000-0000';
      validateLength(element, landline_pattern); 
    });
    $('.reak_ifsc_validate').mask('AAAA0000000');
    $(".reak_ifsc_validate").attr('placeholder', 'AAAA0000000');
    $('.reak_ifsc_validate').on("change keyup",function() {
      let element = $(this);
      // let regex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
      let pattern = 'AAAA0000000';
      $('.reak_ifsc_validate').val(this.value.toUpperCase());
      validateLength(element,pattern);
    });
    $(".reak_accountno_validate").mask('0000000000000');
    let account_no_pattern = '0000000000000';
      // validateLength(element, account_no_pattern); 
    $("#Account_no").val(account_no_pattern);
    // $(".reak_accountno_validate").attr('placeholder', '0000XXXXXX');
    $(".reak_accountno_validate").on("change keyup", function() {
      let element = $(this);
      validateLength(element,".reak_accountno_validate");
    });
    maskIt("#Account_no","#Account_no");
    $(".reak_email_validate").attr('placeholder', 'example@domain.com');
    $('.reak_email_validate').on("change keyup", function() {    
      let element = $(this);
      var mailformat = '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$';
    
      validatePattern(element,mailformat,"email");
    });
    $(".reak_website_validate").attr('placeholder', 'www.example.com');
    $('.reak_website_validate').on('change keyup', function(e) {
      
        // var pressed = String.fromCharCode(e.which);    
        // var final = this.value + pressed;
        // var data = $(this).val();
        // var regx = /^((https?|ftp|smtp):\/\/)?(www.)?[a-z0-9-]+\.[a-z]{2,20}[a-z0-9-]{0,7}?(\.[a-z]{2,20}[a-z0-9-]{0,7})?((\/[a-zA-Z0-9#]+\/?))*$/;
        // console.log(data.match(regx));
        let regx = /^(?:http(?:s)?:\/\/)?(?:HTTP(?:S)?:\/\/)?(www\.|WWW\.+)?([a-zA-Z\-_$\/0-9?]+(\.[a-zA-Z?\-_\/$#]{2,50}(?:[0-9a-zA-Z\-_#]{0,50}))+)$/;
        let element = $(this);
    
        validatePattern(element,regx,"website");
      });
    
       
});
 
    // $(".validation_check").on("change keyup",()=>{
    //   alert("test");
    // });
  
  // Masking Function for numbers
  function maskIt(element, id) {
  
    $(element).keyup((e) => {
      let input_val = e.target.value;
      input_val = input_val.split("");
      // console.log(input_val);
  
      if (e.originalEvent.key >= 0 || e.originalEvent.key <= 9) {
        if (element === id) {
          if (input_val.length < ($(element)[0].maxLength)) {
            input_val.length = 0;
          }
          for (var i = input_val.length; input_val.length < ($(element)[0].maxLength); i++) {
            input_val.unshift("0");
          }
          if (input_val[0] == "0") {
            input_val.splice(0, 1);
            input_val.push(e.originalEvent.key);
  
          }
        }
      } else if (e.originalEvent.key === "Backspace" || e.originalEvent.key === "Delete") {
        input_val.unshift("0");
        if (input_val.length < ($(element)[0].maxLength)) {
          input_val.unshift(contact_phone_pattern);
        }
      }
      else {
        for (var i = input_val.length; input_val.length < ($(element)[0].maxLength); i++) {
          input_val.unshift("0");
        }
      }
      let val = $(element).masked(input_val.join(""));
      $(element).val(val);
    });
  }