# tellisys-web-app
Simple Framework to quickly build webapps in GoLang with tailwind css.

# theme documentation
[Theme Documentation](https://yetiadmin.yetithemes.net/docs)
## Yarn

Installing [Yarn](https://yarnpkg.com/) on Ubuntu 
```
    curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -
    echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
```
Once the repository is enabled, update the package list, and install Yarn.
```
    sudo apt update
    sudo apt install yarn
```
The command above will also install Node.js . If you installed Node trough nvm, skip the Node.js installation with:
```
    sudo apt install --no-install-recommends yarn
```
Sometimes on ubuntu instead of installing yarn it installs cmd test (I've tested on Ubuntu 18.04), I would recommend installing this through npm
```
npm install -g yarn
```

Once completed, verify the installation by printing the Yarn version:
```    
    yarn --version
```
To install all project dependencies that are specified in the package.json file, run:
``` 
    yarn install
```
Upgrading dependency
```
    yarn upgrade
    yarn upgrade [package_name]
    yarn upgrade [package_name]@[version_or_tag]
```

Removing dependency
```
    yarn remove [package_name]
```

Start Project yarn server
```
    yarn dev
```

## do
* use comment with code. 
* formate your code (in VScode `ctrl`+`shft`+`i`) before push on server;
* every js write on `script.js`


## do'nt 
* not use CDN external link
* not use custom css.

sequence 17 july
```

<script src="/assets/js/ckeditor.js"></script>
<script src="/assets/js/filepond.min.js"></script>
<script src="/assets/js/filepond-plugin-file-encode.min.js"></script>
<script src="/assets/js/filepond-plugin-file-validate-size.min.js"></script>
<script src="/assets/js/filepond-plugin-image-exif-orientation.min.js"></script>
<script src="/assets/js/filepond-plugin-image-preview.min.js"></script>
<script src="/assets/js/filepond-plugin-file-validate-type.min.js"></script>
<script src="/assets/js/jquery.min.js"></script>
<script src="/assets/js/vendor.js"></script>
<script src="/assets/js/chart.min.js"></script>
<script src="/assets/js/notifier.js"></script>
<script src="/assets/js/custom_script.js"></script>
<script src="/assets/js/script.js"></script>
<script src="/assets/js/jquery.mask.min.js"></script>
<script src="/assets/js/cdn.min.js"></script>
<script src="/assets/js/jquery.dataTables.min.js"></script>
<script src="/assets/js/dataTables.responsive.min.js"></script>
<script src="assets/js/html2canvas.min.js"></script>
<script src="assets/js/jspdf.umd.min.js"></script>
```

## Notification flag 

    flagMsg(type,title,msg);
where input parameter is
* type (string): `"info"`or `"success"`or `"warning"`or `"danger"`
* title (string): title of notification.
* msg (string): message string

output
flag notification right top position.
ie.

    flagMsg("warning","Demo title","message demo text.");

## jquery ajax function

    ajaxRequest(formUrl, formData);
where input parameter is
* url (string)
* data (json)

output:
* success: read data through .done promise.
* error : show notification critical error.
* read response : because js is not work top to bottom approach, we want to check with promise use `.done()`.
     

how to use ? `response variable overwrite with our backend response.

    ajaxRequest("url", data).done(function(response) {
        if (response.status == "success") {
            //do something.
        }else{
             flagMsg("warning","Room Price","value not update.");
        }
    };


# Go
## send email 
for send email use function  `utility.SendEmail`

    func SendEmail(to []string, template string, data map[string]string) (bool, error)
    
where 

@ input parameter
* `to []string` string array stored list of email ids
* `template string` name of template of email send
* `data map[string]string` associative array of data which is use in template.


@ return Output 
* `bool` return success for `true` and failure for `false`
* `error` if error then return error

## form Parser and validation check
    #input
        fields := make(map[string][]string)
        fields["required"] = []string{"required1", "required2"}
        fields["other"] = []string{"otherfield1", "otherfiled2"}

    #output
        formValue, isValid := utility.checkFormValidation(r, fields,"['',multiPart]")
        if isValid {
            //if valid return formValue["required1"], formValue["otherfiled1"], ...
        }else{
            formValue["empty"]
            //list of all comma seperated fields name that is empty
            //or check err
        }
    */


## .env

    DB_USER=<db.user>
    DB_PASSWORD=<db.Pwd>
    DB_NAME=tellisys
    SESSION_KEY=<session_key>
    SESSION_NAME=<session_name>
    WEB_PORT=4000
    APPNAME=REAK
    APPURL=http://localhost:4000/
    FROM_USER=<Email_user_smtp>
    FROM_EMAIL=no-reply@reak.in
    PASSWORD=<Email_password_smtp>
    SMTP_HOST=smtp.sendgrid.net
    SMTP_PORT=587
    EMAIL_TOKEN_EXPIRE=86400


## Remove anonymous function on custom_script.js
[Check This bug, reason of remove anonymous function](https://codepen.io/rajp7jowa/pen/VwMwxzg)

# Javascript
## Price in Words [International number system] 
For number output to change in word output. Function is in template

    function IntToWord(IntString)
Example :-Input-`224,256,145` Output - `Two hundred twentyfour million two hundred fiftysix thousand one hundred fortyfive only.`
