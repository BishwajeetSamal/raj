-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 17, 2022 at 06:05 PM
-- Server version: 8.0.27-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tellisys`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional_guest`
--

CREATE TABLE `additional_guest` (
  `f_name` varchar(255) NOT NULL,
  `l_name` varchar(255) NOT NULL,
  `guest_id` varchar(255) NOT NULL,
  `id` int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `authentication`
--

CREATE TABLE `authentication` (
  `id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(128) NOT NULL COMMENT 'bcrypt',
  `hotel_id` varchar(255) NOT NULL DEFAULT '1',
  `token` varchar(255) DEFAULT NULL,
  `tokenTimestamp` bigint DEFAULT NULL,
  `status` int NOT NULL
);

--
-- Dumping data for table `authentication`
--

INSERT INTO `authentication` (`id`, `first_name`, `last_name`, `email`, `phone`, `password`, `hotel_id`, `token`, `tokenTimestamp`, `status`) VALUES
(25, 'Bar_user', 'user', 'admin@reak.in', '(+99) 8779 8977 79', '$2a$10$dCQQHXzU5GOX3YuU5.w/2OJ6vMPqMimA2YUZR25UQpBQ5eHZ6wtVe', '36', 'n9p9f2fB5YcRLC6EwURDG7ExP0jwaBt-8b66XYgsIK8Z3Y6pzZWvpV3OqGuZLfchX', 1637906452, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bed`
--

CREATE TABLE `bed` (
  `bed_id` int NOT NULL,
  `room_type_id` int NOT NULL,
  `bed_type` varchar(255) NOT NULL,
  `quantity` int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `guest_checkIn_checkOut`
--

CREATE TABLE `guest_checkIn_checkOut` (
  `id` int NOT NULL,
  `res_id` int NOT NULL,
  `check_in` int NOT NULL,
  `check_out` int NOT NULL DEFAULT '0'
);

-- --------------------------------------------------------

--
-- Table structure for table `high_traffic_month`
--

CREATE TABLE `high_traffic_month` (
  `id` int NOT NULL,
  `hotel_id` int NOT NULL,
  `month` varchar(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `hotel_name` varchar(255) DEFAULT NULL,
  `primary_customer` varchar(255) DEFAULT NULL,
  `nearest_competitor` varchar(255) DEFAULT NULL,
  `years_in_operation` int DEFAULT NULL,
  `hotel_rating` int DEFAULT NULL,
  `status` int NOT NULL,
  `uniqueId` varchar(255) DEFAULT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `hotel_list`
--

CREATE TABLE `hotel_list` (
  `id` int NOT NULL,
  `hotel_name` varchar(255) NOT NULL,
  `hotel_id` varchar(200) NOT NULL,
  `hotel_address` text NOT NULL
);

--
-- Dumping data for table `hotel_list`
--
-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int NOT NULL,
  `room_type_id` int NOT NULL,
  `path` varchar(2000) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `place`
--

CREATE TABLE `place` (
  `id` int NOT NULL,
  `country` varchar(255) NOT NULL
);

--
-- Dumping data for table `place`
--

INSERT INTO `place` (`id`, `country`) VALUES
(1, 'United States');

-- --------------------------------------------------------

--
-- Table structure for table `place_city`
--

CREATE TABLE `place_city` (
  `id` int NOT NULL,
  `state_id` int NOT NULL,
  `city` varchar(255) NOT NULL
);

--
-- Dumping data for table `place_city`
--

INSERT INTO `place_city` (`id`, `state_id`, `city`) VALUES
(1, 2, 'Bar Harbor');

-- --------------------------------------------------------

--
-- Table structure for table `place_state`
--

CREATE TABLE `place_state` (
  `id` int NOT NULL,
  `country_id` int NOT NULL,
  `state` varchar(255) NOT NULL
);

--
-- Dumping data for table `place_state`
--

INSERT INTO `place_state` (`id`, `country_id`, `state`) VALUES
(2, 1, 'Maine');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_collect`
--

CREATE TABLE `reservation_collect` (
  `id` int NOT NULL,
  `checkin` varchar(255) DEFAULT NULL,
  `checkout` varchar(255) DEFAULT NULL,
  `adult` varchar(255) NOT NULL,
  `child` varchar(255) NOT NULL,
  `collect_rack_rate` varchar(255) NOT NULL,
  `room_no_id` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `room_charges` varchar(255) NOT NULL,
  `trip_total` varchar(255) NOT NULL,
  `due_depo` varchar(255) NOT NULL,
  `guest_id` int DEFAULT '0'
);

-- --------------------------------------------------------

--
-- Table structure for table `reservation_guest`
--

CREATE TABLE `reservation_guest` (
  `id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `reservation_payment`
--

CREATE TABLE `reservation_payment` (
  `id` int NOT NULL,
  `resid` int NOT NULL,
  `cashpaydate` int DEFAULT NULL,
  `transactionid` varchar(255) DEFAULT NULL,
  `transactiondate` int DEFAULT NULL,
  `paymenttype` varchar(255) NOT NULL,
  `curr_timestamp` int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int NOT NULL,
  `room_type_id` int NOT NULL,
  `room_type` varchar(255) NOT NULL,
  `quantity` int NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `roomNo`
--

CREATE TABLE `roomNo` (
  `id` int NOT NULL,
  `room_type_id` int NOT NULL,
  `room_no` varchar(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `rooms_ratio_yearly`
--

CREATE TABLE `rooms_ratio_yearly` (
  `id` int NOT NULL,
  `b_hotel_id` int NOT NULL,
  `cal_timestamp` bigint NOT NULL,
  `ratios` text NOT NULL
);

--
-- Dumping data for table `rooms_ratio_yearly`
--

--
-- Table structure for table `room_price`
--

CREATE TABLE `room_price` (
  `roomTypeId` int NOT NULL,
  `dateTime` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `ratePlan` varchar(255) DEFAULT ''
);

-- --------------------------------------------------------

--
-- Table structure for table `room_type`
--

CREATE TABLE `room_type` (
  `room_type_id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `abbreviation` varchar(255) NOT NULL,
  `max_adult_allowed` int NOT NULL,
  `max_children_allowed` int NOT NULL,
  `check_in_hour` int NOT NULL,
  `check_in_minu` int NOT NULL,
  `check_in_ampm` varchar(255) NOT NULL,
  `check_out_hour` int NOT NULL,
  `check_out_minu` int NOT NULL,
  `check_out_ampm` varchar(255) NOT NULL,
  `base_price` int NOT NULL,
  `pet_allowed` tinyint DEFAULT NULL,
  `status` tinyint NOT NULL,
  `total_rooms` int NOT NULL,
  `smoking_allowed` tinyint DEFAULT NULL,
  `description` text,
  `permit_tax_id` varchar(255) DEFAULT NULL,
  `check_in_method` text,
  `check_in_instruction` text,
  `children_infant_restriction` text,
  `cancellation_policy` text
);

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int NOT NULL,
  `hotel_name` varchar(255) NOT NULL,
  `hotel_email` varchar(255) NOT NULL,
  `hotel_phone` varchar(255) NOT NULL,
  `hotel_address` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `hotel_id` varchar(255) NOT NULL
);

-- --------------------------------------------------------

--
-- Table structure for table `user_place`
--

CREATE TABLE `user_place` (
  `id` int NOT NULL,
  `city_id` int NOT NULL,
  `user_id` int NOT NULL
);

--
-- Dumping data for table `user_place`
--

INSERT INTO `user_place` (`id`, `city_id`, `user_id`) VALUES
(1, 1, 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additional_guest`
--
ALTER TABLE `additional_guest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authentication`
--
ALTER TABLE `authentication`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `bed`
--
ALTER TABLE `bed`
  ADD PRIMARY KEY (`bed_id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guest_checkIn_checkOut`
--
ALTER TABLE `guest_checkIn_checkOut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `high_traffic_month`
--
ALTER TABLE `high_traffic_month`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `hotel_list`
--
ALTER TABLE `hotel_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hotel_id` (`hotel_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `place`
--
ALTER TABLE `place`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `country` (`country`);

--
-- Indexes for table `place_city`
--
ALTER TABLE `place_city`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `city` (`city`),
  ADD KEY `StateId Foreign Key` (`state_id`);

--
-- Indexes for table `place_state`
--
ALTER TABLE `place_state`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `state` (`state`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `reservation_collect`
--
ALTER TABLE `reservation_collect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservation_guest`
--
ALTER TABLE `reservation_guest`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `reservation_payment`
--
ALTER TABLE `reservation_payment`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `curr_timestamp` (`curr_timestamp`),
  ADD UNIQUE KEY `transaction_id` (`transactionid`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roomNo`
--
ALTER TABLE `roomNo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms_ratio_yearly`
--
ALTER TABLE `rooms_ratio_yearly`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_type`
--
ALTER TABLE `room_type`
  ADD PRIMARY KEY (`room_type_id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hotel_emial` (`hotel_email`),
  ADD UNIQUE KEY `hotel_phone` (`hotel_phone`);

--
-- Indexes for table `user_place`
--
ALTER TABLE `user_place`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `additional_guest`
--
ALTER TABLE `additional_guest`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `authentication`
--
ALTER TABLE `authentication`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `bed`
--
ALTER TABLE `bed`
  MODIFY `bed_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `guest_checkIn_checkOut`
--
ALTER TABLE `guest_checkIn_checkOut`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `high_traffic_month`
--
ALTER TABLE `high_traffic_month`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `hotels`
--
ALTER TABLE `hotels`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `hotel_list`
--
ALTER TABLE `hotel_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `place`
--
ALTER TABLE `place`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `place_city`
--
ALTER TABLE `place_city`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `place_state`
--
ALTER TABLE `place_state`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `reservation_guest`
--
ALTER TABLE `reservation_guest`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `reservation_payment`
--
ALTER TABLE `reservation_payment`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `roomNo`
--
ALTER TABLE `roomNo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `rooms_ratio_yearly`
--
ALTER TABLE `rooms_ratio_yearly`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `room_type`
--
ALTER TABLE `room_type`
  MODIFY `room_type_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT for table `user_place`
--
ALTER TABLE `user_place`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `place_city`
--
ALTER TABLE `place_city`
  ADD CONSTRAINT `StateId Foreign Key` FOREIGN KEY (`state_id`) REFERENCES `place_state` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `place_state`
--
ALTER TABLE `place_state`
  ADD CONSTRAINT `place_state_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `place` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
