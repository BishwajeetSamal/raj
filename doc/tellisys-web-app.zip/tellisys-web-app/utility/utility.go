package utility

import (
	"bytes"
	"encoding/json"
	"log"
	"net/http"
	"net/smtp"
	"os"
	"strconv"
	"strings"

	// "html/template" replace with "text/template" reason tmpl security error solov
	"text/template"
	"time"

	"github.com/gorilla/sessions"
	"github.com/jmoiron/sqlx"
)

// Template Pool
var View *template.Template

// Session Store
var Store *sessions.CookieStore

// DB Connections
var Db *sqlx.DB

type Session struct {
	Key   string
	Value string
}
type AjaxResponse struct {
	Status string
	Data   interface{}
}

func RedirectTo(w http.ResponseWriter, r *http.Request, url string) {
	http.Redirect(w, r, url, 302)
}

func SessionSet(w http.ResponseWriter, r *http.Request, data []Session) {
	session, _ := Store.Get(r, os.Getenv("SESSION_NAME"))
	// Set some session values.
	session.Options = &sessions.Options{
		Path:     "/",
		MaxAge:   1800,
		HttpOnly: true,
	}
	for _, dataSingle := range data {
		session.Values[dataSingle.Key] = dataSingle.Value
	}
	// Save it before we write to the response/return from the handler.
	err := session.Save(r, w)
	if err != nil {
		log.Println(err)
	}
}

func SessionGet(r *http.Request, key string) interface{} {
	session, _ := Store.Get(r, os.Getenv("SESSION_NAME"))
	// Set some session values.
	return session.Values[key]
}

func fetchSession(r *http.Request) map[interface{}]interface{} {
	session, _ := Store.Get(r, os.Getenv("SESSION_NAME"))
	return session.Values
}

func CheckACL(w http.ResponseWriter, r *http.Request, minLevel int) bool {
	userType := SessionGet(r, "type")
	var level int = 0
	switch userType {
	case "user":
		level = 1
	case "admin":
		level = 2
	default:
		level = 0
	}
	if level >= minLevel {
		return true
	} else {
		RedirectTo(w, r, os.Getenv("APPURL"))
		AddFlash("Failure", "Access Denied.", w, r)
		return false
	}
}

func AddFlash(flavour string, message string, w http.ResponseWriter, r *http.Request) {
	session, err := Store.Get(r, "flash-session")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
	flash := make(map[string]string)
	flash["Flavour"] = flavour
	flash["Message"] = message
	session.AddFlash(flash, "message")
	session.Save(r, w)
}

func viewFlash(w http.ResponseWriter, r *http.Request) interface{} {
	session, err := Store.Get(r, "flash-session")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
	fm := session.Flashes("message")
	if fm == nil {
		return nil
	}
	session.Save(r, w)
	return fm
}

func RenderTemplate(w http.ResponseWriter, r *http.Request, template string, data interface{}) {
	tmplData := make(map[string]interface{})
	tmplData["data"] = data
	tmplData["flash"] = viewFlash(w, r)
	tmplData["session"] = fetchSession(r)
	View.ExecuteTemplate(w, template, tmplData)
}

func HandlePanic(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			r := recover()
			// Marshall r and log
			//http.Error(w, "", http.StatusInternalServerError)

			if r != nil {
				json, _ := json.Marshal(r)
				log.Println("Recoverd in HandlePanic - ", string(json))
				w.WriteHeader(500)
				View.ExecuteTemplate(w, "500_error", nil)
			}
		}()
		h.ServeHTTP(w, r)
	})
}

/* smtp send email*/
func SendEmailSMTP(to []string, subject string, body string) (bool, error) {
	//Sender data.
	from := os.Getenv("FROM_EMAIL")
	// Set up email information.
	header := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\n"
	msg := []byte("From: " + from + "\n" + "To: " + strings.Join(to, ",") + "\n" + "Subject: " + subject + "\r\n" + header + body)
	// Sending email.
	// fmt.Println("From: " + from + "\n" + "To: " + strings.Join(to, ",") + "\n" + "Subject: " + subject + "\r\n" + header + "\r\n" + body)
	err := smtp.SendMail(os.Getenv("SMTP_HOST")+":"+os.Getenv("SMTP_PORT"), smtp.PlainAuth("", os.Getenv("FROM_USER"), os.Getenv("PASSWORD"), os.Getenv("SMTP_HOST")), from, to, msg)
	if err != nil {
		return false, err
	}
	return true, nil
}

/** main function to call for send mail
#input
	to : string array
	template : tempatePath
	data : associative array of data which is set on template, by-default app_url and app_name is set
*/
func SendEmail(to []string, template string, data map[string]string) (bool, error) {
	buf := new(bytes.Buffer)
	//extra information on email
	data["app_url"] = os.Getenv("APPURL")
	data["app_name"] = os.Getenv("APPNAME")
	// Set up email information.
	err := View.ExecuteTemplate(buf, template, data)
	if err != nil {
		return false, err
	}
	return SendEmailSMTP(to, data["subject"], buf.String())
}

/* Form string Date to timestamp
#input string date ie: (30-12-2021)
#output int64 timestamp
*/

func DateParser_unix(date string) int64 {
	dateVal, err := time.Parse("2006-01-02", date)
	if err != nil {
		log.Println(err)
		return 0
	}
	return dateVal.Unix()
}

/* Form timestamp to date
#input int64 timestamp
#output string date ie: (30-12-2021)
*/
func EpochToDate(timestamp string) (string, error) {
	dateVal, err := strconv.ParseInt(timestamp, 10, 64)
	if err != nil {
		return "", err
	}
	return time.Unix(dateVal, 0).Format("2006-01-02"), nil
}

func StrToInt64(num string) int64 {
	num64, err := strconv.ParseInt(num, 10, 64)
	if err != nil {
		return 0
	}
	return num64
}
func StrToFloat64(num string) float64 {
	Vfloat64, err := strconv.ParseFloat(num, 64)
	if err != nil {
		return Vfloat64
	}
	return Vfloat64
}

/** form Parse and check required and un-required filed
#input
	fields := make(map[string][]string)
	formType string
	fields["required"] = []string{"required1", "required2"}
	fields["other"] = []string{"otherfield1", "otherfiled2"}

#output
	formValue, isValid:= checkFormValidation(r, fields)
*/
func CheckFormValidation(r *http.Request, fields map[string][]string, formType string) (map[string]string, bool) {
	data := make(map[string]string)
	var err error

	if formType == "multiPart" {
		err = r.ParseMultipartForm(10 << 20)
	} else {
		err = r.ParseForm()
	}

	if err != nil {
		log.Println(err)
		return data, false
	}
	//all un-required,
	for _, field := range fields["other"] {
		data[field] = r.FormValue(field)
	}
	//all required,
	for _, field := range fields["required"] {
		if r.FormValue(field) != "" {
			data[field] = r.FormValue(field)
		} else {
			log.Println("Field " + field + " is required")
			return data, false
		}
	}
	return data, true
}

func ConvertToInt64(data string) int64 {
	val, _ := strconv.ParseInt(data, 10, 64)
	return val
}

func ReturnDaybyDate(year, month, day int) time.Time {
	return time.Date(year, time.Month(month), day, 0, 0, 0, 0, time.UTC)
}

func ParseToInt(str string) int {
	data, err := strconv.Atoi(str)
	if err != nil {
		log.Println(err)
	} else {
		return data
	}
	return 0
}
func TestRandom(NumbVal string, isBg bool) string {
	answers := []string{"gray-", "red-", "yellow-", "green-", "blue-"}
	color := answers[int(StrToInt64(NumbVal))%len(answers)]
	NumbVal1 := int(StrToInt64(NumbVal)) % 5
	if NumbVal1 <= 0 {
		NumbVal1 = 2
	}
	if isBg {
		return " bg-" + color + strconv.Itoa(NumbVal1) + "00 hover:" + color + strconv.Itoa(NumbVal1+1) + "00 dark:" + color + strconv.Itoa(NumbVal1+4) + "00  dark:hover:" + color + strconv.Itoa(NumbVal1+3) + "00 "
	} else {
		return "text-" + color + strconv.Itoa(NumbVal1+4) + "00  dark:text-" + color + strconv.Itoa(NumbVal1+2) + "00 "
	}
}

func SplitDate(date string) string {
	splitword := strings.Split(date, "-")
	return splitword[2] + splitword[1] + splitword[0]
}

//This func helps to remove the item at given index
func RemoveIndex(s []string, index int) []string {
	return append(s[:index], s[index+1:]...)
}

//Change String Array to IntArray
func ChangeArraytoInt(t []string) []int {

	var t2 = []int{}
	for _, i := range t {
		j, err := strconv.Atoi(i)
		if err != nil {
			// panic(err)
			log.Println(err)
		}
		t2 = append(t2, j)
	}
	return t2
}
func MysqlRealEscapeString(value string) string {
	var sb strings.Builder
	for i := 0; i < len(value); i++ {
		c := value[i]
		switch c {
		case '\\', 0, '\n', '\r', '\'', '"':
			sb.WriteByte('\\')
			sb.WriteByte(c)
		case '\032':
			sb.WriteByte('\\')
			sb.WriteByte('Z')
		default:
			sb.WriteByte(c)
		}
	}
	return sb.String()
}

func SessionDestroy(w http.ResponseWriter, r *http.Request) bool {

	session, err := Store.Get(r, os.Getenv("SESSION_NAME"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return false
	}
	session.Options.MaxAge = -1
	err = session.Save(r, w)
	if err != nil {
		log.Println(err)
		return false
	}
	return true
}

func Check_hotelId(w http.ResponseWriter, r *http.Request) bool {
	hotelId := SessionGet(r, "hotel_id")
	if hotelId != "" {
		return true
	} else {
		AddFlash("Failure", "Please Provide Hotel Name To Continue.", w, r)
		RedirectTo(w, r, os.Getenv("APPURL")+"dashboard")
		//RenderTemplate(w, r, "dashboard", nil)
		return false
	}
}

//TaxCalculation: returnval = rate * (percent * %) where % is 0.01
func TaxCalculation(rate float64, percent float64) float64 {
	returnVal := float64(rate) * (float64(percent) * float64(0.01))
	return returnVal
}
