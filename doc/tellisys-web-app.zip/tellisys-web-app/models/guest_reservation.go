package models

import (
	"database/sql"
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type Guest_reservation struct {
	Id         int64
	First_name string
	Last_name  string
	Email      string
	Phone      sql.NullString
	Address    sql.NullString
	City       sql.NullString
	State      sql.NullString
	Country    sql.NullString
	Zip_code   sql.NullInt64
	User_id    string
	F_name     string
	L_name     string
	Guest_id   int64
	Res_Id     int64
}

type Get_guestinfo struct {
	Guest_reservation
	Reservation
	AddGuestId     sql.NullInt64
	GuestId        int64
	Reservation_Id int64
	AddF_name      sql.NullString
	AddL_name      sql.NullString
}

type AddName struct {
	Fname string
	LName string
}
type Guest_ReservationModel struct {
	DB *sqlx.DB
}

func (res Guest_ReservationModel) GetEdit_GuestDataById(resIdOfCollect Guest_reservation) ([]Get_guestinfo, error) {
	var guestRows []Get_guestinfo
	var guest Get_guestinfo
	var err error
	rows, err := utility.Db.Queryx("SELECT DISTINCT add_guest.id,guest.id,guest.first_name,guest.last_name,guest.email,guest.phone,guest.address,guest.city,guest.state,guest.country,guest.zip_code,add_guest.f_name,add_guest.l_name,collect.adult,collect.child FROM reservation_collect as collect INNER JOIN reservation_guest as guest ON guest.id=collect.guest_id LEFT JOIN additional_guest as add_guest ON add_guest.res_id=collect.id WHERE collect.id = ?", resIdOfCollect.Res_Id)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&guest.AddGuestId, &guest.GuestId, &guest.First_name, &guest.Last_name, &guest.Email, &guest.Phone, &guest.Address, &guest.City, &guest.State, &guest.Country, &guest.Zip_code, &guest.AddF_name, &guest.AddL_name, &guest.Adult, &guest.Child)
			if err != nil {
				log.Println(err)
			} else {
				guestRows = append(guestRows, guest)
			}
		}
	}
	return guestRows, err
}

func (res Guest_ReservationModel) InsertGuestInfo(guestData Guest_reservation) (int64, bool) {
	rows, err := utility.Db.Prepare("INSERT INTO reservation_guest(first_name,last_name,email,phone ,address,city,state,country,zip_code,user_id) VALUES(?,?,?,?,?,?,?,?,?,?)")
	if err != nil {
		return 0, false
	} else {
		regisForm, err := rows.Exec(guestData.First_name, guestData.Last_name, guestData.Email, guestData.Phone, guestData.Address, guestData.City, guestData.State, guestData.Country, guestData.Zip_code, guestData.User_id)
		if err != nil {
			log.Println(err)
		} else {
			id, err := regisForm.LastInsertId()
			if err != nil {
				log.Println(err)
			} else {
				defer rows.Close() // Prepared statements take up server resources and should be closed after use.
				return id, true
			}

		}
	}
	return 0, false
}

func (res Guest_ReservationModel) SearchGuestData(guest_name Guest_reservation) ([]Guest_reservation, error) {
	var guestRows []Guest_reservation
	var guest Guest_reservation
	rows, err := utility.Db.Queryx("SELECT * FROM reservation_guest WHERE first_name LIKE ? OR last_name LIKE ?", guest_name.F_name+"%", guest_name.L_name+"%")
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.StructScan(&guest)
			if err != nil {
				log.Println(err)
			} else {
				guestRows = append(guestRows, guest)
			}
		}

	}
	return guestRows, err
}

func (res Guest_ReservationModel) Get_guest_dataById(guest_id string) ([]Guest_reservation, error) {
	var guestRows []Guest_reservation
	var guest Guest_reservation
	rows, err := utility.Db.Queryx("SELECT * FROM reservation_guest WHERE id = ?", guest_id)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.StructScan(&guest)
			if err != nil {
				log.Println(err)
			} else {
				guestRows = append(guestRows, guest)
			}
		}

	}
	return guestRows, err
}

func (res Guest_ReservationModel) UpdateGuestInfo(Guestdata Get_guestinfo, tx *sql.Tx) bool {
	rows, err := tx.Prepare("UPDATE reservation_guest SET first_name=?,last_name=?,email=?,phone=?,address=?,city=?,state=?,country=?,zip_code=?,user_id=? WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(Guestdata.First_name, Guestdata.Last_name, Guestdata.Email, Guestdata.Phone, Guestdata.Address, Guestdata.City, Guestdata.State, Guestdata.Country, Guestdata.Zip_code, Guestdata.User_id, Guestdata.GuestId)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true
		}
	}
	return false
}

func (res Guest_ReservationModel) DeleteNamesandInsertForUpdate(Addnames Guest_reservation) bool {
	query, err := utility.Db.Prepare("DELETE FROM additional_guest  WHERE res_id = ? AND guest_id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err = query.Exec(Addnames.Res_Id, Addnames.Guest_id)
		if err != nil {
			log.Println(err)
			return false
		} else {
			return true
		}
	}
	return false
}

func (res Guest_ReservationModel) InsertAdditionalname(guest Guest_reservation, tx *sql.Tx) bool {
	rows, err := tx.Prepare("INSERT INTO additional_guest(f_name,l_name,guest_id,res_id) VALUES(?,?,?,?)")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(guest.F_name, guest.L_name, guest.Guest_id, guest.Res_Id)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true
		}
	}
	return false
}

func (res Guest_ReservationModel) InsertGuestFromList(guest Guest_reservation) bool {
	rows, err := utility.Db.Prepare("INSERT INTO reservation_guest(first_name,last_name,email,phone,address,city,state,country,zip_code,user_id) VALUES(?,?,?,?,?,?,?,?,?,?)")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(guest.First_name, guest.Last_name, guest.Email, guest.Phone, guest.Address, guest.City, guest.State, guest.Country, guest.Zip_code, guest.User_id)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true
		}
	}
	return false
}

func (res Guest_ReservationModel) UpdateGuestIndivdual(Guestdata Guest_reservation) bool {
	rows, err := utility.Db.Prepare("UPDATE reservation_guest SET first_name=?,last_name=?,email=?,phone=?,address=?,city=?,state=?,country=?,zip_code=?,user_id=? WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(Guestdata.First_name, Guestdata.Last_name, Guestdata.Email, Guestdata.Phone, Guestdata.Address, Guestdata.City, Guestdata.State, Guestdata.Country, Guestdata.Zip_code, Guestdata.User_id, Guestdata.Guest_id)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true
		}
	}
	return false
}

func (res Guest_ReservationModel) Delete_guest_dataById(Guestdata Guest_reservation) (bool, error) {
	query, err := utility.Db.Prepare("DELETE FROM reservation_guest  WHERE  id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err = query.Exec(Guestdata.Guest_id)
		if err == nil {
			return true, err
		}
	}
	return false, err
}

func (res Guest_ReservationModel) Get_guest_dataByResId(reservation_Id string) string {
	var guest_name string
	err := utility.Db.QueryRow("SELECT CONCAT(`first_name`,`last_name`) FROM `reservation_guest` WHERE id= (SELECT guest_id FROM `reservation_collect` WHERE id = ?) ", reservation_Id).Scan(&guest_name)
	if err != nil {
		log.Println(err)
	} else {
		return guest_name
	}
	return ""
}
