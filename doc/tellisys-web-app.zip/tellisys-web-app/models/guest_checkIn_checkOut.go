package models

import (
    "log"
    "github.com/jmoiron/sqlx"
    "reakgo/utility"
)

type GuestCheckInCheckOut struct {
    id int64
    ResId int64
    CheckIn int64
    CheckOut int64
}

type GuestCheckInCheckOutModel struct {
    DB * sqlx.DB
}

func(data GuestCheckInCheckOutModel) InsertCheckIn(time GuestCheckInCheckOut)(bool, error) {
    rows, err := utility.Db.Prepare("INSERT INTO guest_checkIn_checkOut (res_id, check_in) VALUES(?,?)")
    if err != nil {
       log.Println(err)
        return false, err
    }
    _, err = rows.Exec(time.ResId, time.CheckIn)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}

func(data GuestCheckInCheckOutModel) UpdateCheckOut(time GuestCheckInCheckOut)(bool, error, int64) {
	var count int64
	query, err := utility.Db.Prepare("UPDATE guest_checkIn_checkOut set check_out=? where res_id =?")
    if err != nil {
        log.Println(err)
        return false, err, count
    }
    rows, err := query.Exec(time.CheckOut, time.ResId)
    if err != nil {
        log.Println(err)
        return false, err, count
    }
	count, err = rows.RowsAffected()
    if err != nil {
        log.Println(err)
	}
    //log.Println(count)

    return true, nil, count
}