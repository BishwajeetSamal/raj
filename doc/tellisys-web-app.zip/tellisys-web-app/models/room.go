package models

import (
    "log"
    "github.com/jmoiron/sqlx"
    "database/sql"
)

type Room struct {
    Room_id int32
    Room_type_id int64
    Room_type string
    Quantity int64
}

type RoomModel struct {
    DB * sqlx.DB
}

func(data RoomModel) InsertRoom(tx * sql.Tx, room Room)(bool, error) {
    rows, err  := tx.Prepare("INSERT INTO room (room_type_id, room_type, quantity) VALUES(?,?,?)")
    if err != nil {
        log.Println(err)
        return false, err
    }
    _, err = rows.Exec(room.Room_type_id, room.Room_type, room.Quantity)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}