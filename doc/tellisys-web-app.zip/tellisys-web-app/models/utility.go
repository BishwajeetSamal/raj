package models

import (
	"encoding/json"
	"log"
	"net/http"
	"net/url"
	"os"
	"reakgo/utility"
	"strconv"
	"strings"

	"github.com/jmoiron/sqlx"
)

type UtilityModel struct {
	DB *sqlx.DB
}

type QueryDetails struct {
	AllRecords       int64
	StartLimit       int64
	LimitRows        int64
	Num_Rows         int64
	Middle_Condition string
	Condition        string
	Schema           string
	Columns          []string
}

type ResponsePagination struct {
	Records      []interface{}
	QueryDetails QueryDetails
}

type Dashboard struct {
	Reservation_today int64
	Current_occupany  int64
	Empty_rooms       int64
	Guest_arrival     int64
	Guest_departure   int64
}
type SystemSuggested struct {
	DateTime      string
	SystemGenRate int64
}

func (utility_model UtilityModel) GetPaginationRecords(QryDetails QueryDetails) (ResponsePagination, error) {
	var data []interface{}
	var Response ResponsePagination
	Response.QueryDetails.StartLimit = QryDetails.StartLimit
	Response.QueryDetails.LimitRows = QryDetails.LimitRows

	err := utility.Db.QueryRow("SELECT COUNT(*) as num_rows FROM " + QryDetails.Schema + " " + QryDetails.Middle_Condition + " where " + QryDetails.Condition).Scan(&Response.QueryDetails.AllRecords)
	if err != nil {
		log.Println(err)
		return Response, err
	}
	rows, err := utility.Db.Queryx("SELECT distinct "+strings.Join(QryDetails.Columns[:], ",")+" FROM "+QryDetails.Schema+" "+QryDetails.Middle_Condition+" where "+QryDetails.Condition+" limit ?, ?", QryDetails.StartLimit, QryDetails.LimitRows)

	// log.Println("SELECT distinct "+strings.Join(QryDetails.Columns[:], ",")+" FROM "+QryDetails.Schema+" "+QryDetails.Middle_Condition+" where "+QryDetails.Condition+" limit ", QryDetails.StartLimit, ",", QryDetails.LimitRows)

	if err != nil {
		log.Println(err)
		return Response, err
	}
	counter := 0
	for rows.Next() {
		counter = counter + 1

		var err error

		switch QryDetails.Schema {
		case "room_type":
			var singleRow RoomTypeExtra
			// todo: with given column on Scan
			err = rows.Scan(&singleRow.Roomtype.Room_type_id, &singleRow.Roomtype.Name, &singleRow.Roomtype.Abbreviation, &singleRow.Roomtype.Max_adult, &singleRow.Roomtype.Max_children, &singleRow.Roomtype.Base_price, &singleRow.Images)
			data = append(data, singleRow)

		case "reservation_payment", "guest_checkIn_checkOut":
			var singleRow ReservationsDetails
			err = rows.Scan(&singleRow.ReservationId, &singleRow.GuestName, &singleRow.ReservationDate, &singleRow.CheckIn, &singleRow.CheckOut, &singleRow.Adults, &singleRow.Children, &singleRow.RoomType, &singleRow.RoomNumber, &singleRow.CheckInMiss)
			data = append(data, singleRow)

		case "reservation_collect":
			var singleRow ReservationsDetails
			err = rows.Scan(&singleRow.ReservationId, &singleRow.GuestName, &singleRow.ReservationDate, &singleRow.CheckIn, &singleRow.CheckOut, &singleRow.Adults, &singleRow.Children, &singleRow.RoomType, &singleRow.RoomNumber, &singleRow.PaymentStatus)
			data = append(data, singleRow)

		case "reservation_guest":
			var singleRow Guest_reservation
			err = rows.Scan(&singleRow.Id, &singleRow.First_name, &singleRow.Last_name, &singleRow.Email, &singleRow.Phone, &singleRow.Address, &singleRow.City, &singleRow.State, &singleRow.Country, &singleRow.Zip_code)
			data = append(data, singleRow)
		}

		if err != nil {
			log.Println(err)
			return Response, err
		}

	}

	Response.Records = data
	Response.QueryDetails.Num_Rows = int64(counter)

	return Response, nil
}

func (utility_model UtilityModel) Get_rooms_data(requestfilter Reservation, withrecords string, userid string) []RoomTypeExtra {
	var data []RoomTypeExtra
	var rows *sqlx.Rows
	var err error
	Condition := "DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%Y%m%d') BETWEEN ? and ? AND DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%Y%m%d') BETWEEN ? and ? "
	if requestfilter.Adult != 0 {
		Condition = Condition + " AND reservation.adult <= " + strconv.Itoa(int(requestfilter.Adult))
	}
	if requestfilter.Child != 0 {
		Condition = Condition + " AND reservation.child <= " + strconv.Itoa(int(requestfilter.Child))
	}
	if withrecords == "roomtype" || withrecords == "roomtypeonly" {
		rows, err = utility.Db.Queryx("SELECT room.room_type_id, room.name, room.abbreviation, room.base_price,(room.room_type_id+room.base_price) num FROM room_type room where user_id = ?", userid)
		if err != nil {
			log.Println(err)
		}
	}
	if withrecords == "roomno" {
		Query := "SELECT room.`room_type_id`, room.`name`,room.`abbreviation`,room.`base_price`, roomnum.room_no FROM room_type room left JOIN roomNo roomnum on roomnum.room_type_id = room.room_type_id INNER join reservation_collect reservation on reservation.room_no = roomnum.id where " + Condition + " ORDER BY `room`.`room_type_id` ASC"
		rows, err = utility.Db.Queryx(Query, requestfilter.CheckIn, requestfilter.CheckOut, requestfilter.CheckIn, requestfilter.CheckOut)
		if err != nil {
			log.Println(err)
		}
	}
	if withrecords == "assign" {
		Query := "SELECT (DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%d-%m-%Y')) AS 'CheckInTime' , max(DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%d-%m-%Y')) AS 'CheckOutTime' ,max(rno.room_type_id) as roomno, count(rno.room_type_id) as book FROM `reservation_collect` as reservation left JOIN roomNo rno on rno.id = reservation.room_no WHERE " + Condition + " group by CheckInTime"
		rows, err = utility.Db.Queryx(Query, requestfilter.CheckIn, requestfilter.CheckOut, requestfilter.CheckIn, requestfilter.CheckOut)
		if err != nil {
			log.Println(err)
		}
	}

	if withrecords == "roomtype" {
		var unassign RoomTypeExtra
		unassign.Roomtype.Name = "unassign"
		unassign.Roomtype.Description = "unassign"
		data = append(data, unassign)
	}

	for rows.Next() {
		var singleRow RoomTypeExtra
		if withrecords == "price" {
			err := rows.Scan(&singleRow.Roomtype.Room_type_id, &singleRow.Roomtype.Name, &singleRow.Roomtype.Abbreviation, &singleRow.Roomtype.Base_price)
			if err != nil {
				log.Println(err)
			}
			data = append(data, singleRow)
		}
		if withrecords == "roomtype" || withrecords == "roomtypeonly" {
			err := rows.Scan(&singleRow.Roomtype.Room_type_id, &singleRow.Roomtype.Name, &singleRow.Roomtype.Abbreviation, &singleRow.Roomtype.Base_price, &singleRow.CheckIn)
			if err != nil {
				log.Println(err)
			}
			if withrecords != "roomtypeonly" {
				singleRow.Themes = utility.TestRandom(singleRow.CheckIn, false)
			}
			data = append(data, singleRow)
		}
		if withrecords == "roomno" {
			err := rows.Scan(&singleRow.Roomtype.Room_type_id, &singleRow.Roomtype.Name, &singleRow.Roomtype.Abbreviation, &singleRow.Roomtype.Base_price, &singleRow.UnNoOfRoom)
			if err != nil {
				log.Println(err)
			}
			data = append(data, singleRow)
		}
		if withrecords == "assign" {
			err := rows.Scan(&singleRow.Roomtype.Room_type_id, &singleRow.Roomtype.Name, &singleRow.Roomtype.Abbreviation, &singleRow.Roomtype.Base_price, &singleRow.UnNoOfRoom)
			if err != nil {
				log.Println(err)
			}
			data = append(data, singleRow)
		}

	}
	return data
}

func (utility_model UtilityModel) CountAll(table string) AssginUnassignRoom {
	var singleRow AssginUnassignRoom
	rows := utility.Db.QueryRow("SELECT COUNT(*) as counter from " + table)
	err := rows.Scan(&singleRow.Counting)
	if err != nil {
		log.Println(err)
	}
	return singleRow

}

func (utility_model UtilityModel) GetHotelDetails(QryDetails QueryDetails) string {
	var singleRow string
	rows := utility.Db.QueryRow("SELECT distinct "+QryDetails.Columns[0]+" FROM "+QryDetails.Schema+" where "+QryDetails.Columns[1]+" = ?", QryDetails.Condition)
	err := rows.Scan(&singleRow)
	if err != nil {
		log.Println(err)
	}
	return singleRow
}

func (utility_model UtilityModel) GetSystemSuggestedPrice(requestfilter Reservation, userID string) map[string]interface{} {
	var QryDetails QueryDetails
	QryDetails.Schema = "hotels"
	QryDetails.Columns = []string{"hotel_name", "user_id"}
	QryDetails.Condition = (userID)
	hotelName := utility_model.GetHotelDetails(QryDetails)
	data := url.Values{
		"hotel":    {hotelName},
		"fromdate": {requestfilter.CheckIn},
		"todate":   {requestfilter.CheckOut},
	}
	log.Println(hotelName)
	resp, err := http.PostForm(os.Getenv("APIURL")+"getHistorical", data)
	var res map[string]interface{}
	if err != nil {
		log.Println("Error: [API server ]", err)
		res = nil
	} else {
		json.NewDecoder(resp.Body).Decode(&res)
	}
	return res
}

func (utility_model UtilityModel) CalculateReservationToday(time int64, hotel_id int64) (int64, error) {
	var reservation_today int64
	rows := utility.Db.QueryRow("select COUNT(pay.resid) as reservation_today from reservation_payment pay inner join reservation_collect coll on pay.resid = coll.id inner join authentication  auth on coll.userid=auth.id && auth.hotel_id=? where curr_timestamp >=?", hotel_id, time)
	err := rows.Scan(&reservation_today)
	if err != nil {
		log.Println(err)
		return reservation_today, err
	}
	return reservation_today, nil
}

func (utility_model UtilityModel) CalculateTotalRooms(hotel_id int64) (int64, error) {
	var total_rooms int64
	rows := utility.Db.QueryRow("SELECT count(roomNo.id) FROM `room_type` room inner join authentication  auth on room.user_id=auth.id && auth.hotel_id=? inner join roomNo on roomNo.room_type_id= room.room_type_id", hotel_id)
	err := rows.Scan(&total_rooms)
	if err != nil {
		log.Println(err)
		return total_rooms, err
	}
	return total_rooms, nil
}

func (utility_model UtilityModel) CalculateGuestArrival(time int64, hotel_id int64) (int64, error) {
	var guest_arr int64
	rows := utility.Db.QueryRow("select COUNT(coll.id) as guest_arr from reservation_collect coll inner join reservation_payment pay on coll.id = pay.resid inner join authentication auth on coll.userid = auth.id && auth.hotel_id=? where  coll.checkin=?", hotel_id, time)
	err := rows.Scan(&guest_arr)
	if err != nil {
		log.Println(err)
		return guest_arr, err
	}
	return guest_arr, nil
}

func (utility_model UtilityModel) CalculateGuestDeparture(time int64, hotel_id int64) (int64, error) {
	var guest_dep int64
	rows := utility.Db.QueryRow("select COUNT(coll.id) as guest_dep from reservation_collect coll inner join reservation_payment pay on coll.id = pay.resid inner join authentication auth on coll.userid = auth.id && auth.hotel_id=? where  coll.checkout=?", hotel_id, time)
	err := rows.Scan(&guest_dep)
	if err != nil {
		log.Println(err)
		return guest_dep, err
	}
	return guest_dep, nil
}
