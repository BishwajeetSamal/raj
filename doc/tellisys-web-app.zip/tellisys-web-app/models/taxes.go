package models

import (
	"database/sql"
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type RoomTax struct {
	RoomTaxId     int64
	RoomId        int64
	ReservationId int64
	RoomTax1      float64
	RoomTax2      float64
}

type RoomServiceTax struct {
	RoomServiceTaxId int64
	RoomServiceId    int64
	ReservationId    int64
	RoomServiceTax1  float64
	RoomServiceTax2  float64
}

type VATTax struct {
	VATTaxId      int64
	VATId         int64
	ReservationId int64
	VATTax1       float64
	VATTax2       float64
}
type TAX struct {
	RoomTax        RoomTax
	RoomServiceTax RoomServiceTax
	VatTax         VATTax
}

type TaxesModel struct {
	DB *sqlx.DB
}

func (tax TaxesModel) GetTaxOfUser(userId string) TAX {
	var taxes TAX
	rows := utility.Db.QueryRow("SELECT  `room_tax_1`, `room_tax_2`, `room_service_tax_1`, `room_service_tax_2`, `vat_tax_1`, `vat_tax_2` FROM `user_setting` WHERE `user_id` = ?", userId)
	err := rows.Scan(&taxes.RoomTax.RoomTax1, &taxes.RoomTax.RoomTax2, &taxes.RoomServiceTax.RoomServiceTax1, &taxes.RoomServiceTax.RoomServiceTax2, &taxes.VatTax.VATTax1, &taxes.VatTax.VATTax2)
	if err != nil {
		log.Println(err)
	}
	return taxes
}

func (tax TaxesModel) SetRoomTax(tx *sql.Tx, room_id int64, reservation_id int64, room_tax_1 float64, room_tax_2 float64) bool {
	rows, err := tx.Prepare("INSERT INTO `room_tax`(`room_id`,`reservation_id`, `room_tax_1`, `room_tax_2`) VALUES (?,?,?,?)")
	if err != nil {
		log.Println(err)
	} else {
		_, err = rows.Exec(room_id, reservation_id, room_tax_1, room_tax_2)
		if err != nil {
			log.Println(err)
		}
		return true
	}
	return false
}

func (tax TaxesModel) SetRoomServiceTax(tx *sql.Tx, reservation_id int64, room_service_id int64, room_service_tax_1 float64, room_service_tax_2 float64) bool {
	rows, err := tx.Prepare("INSERT INTO room_service_tax (`reservation_id`,`room_service_id`,`room_service_tax_1`,`room_service_tax_2`) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE room_service_tax_1= ?, room_service_tax_2= ? ")
	if err != nil {
		log.Println(err)
	} else {
		_, err = rows.Exec(reservation_id, room_service_id, room_service_tax_1, room_service_tax_2, room_service_tax_1, room_service_tax_2)
		if err != nil {
			log.Println(err)
		}
		return true
	}
	return false
}

func (tax TaxesModel) SetVATTax(tx *sql.Tx, reservation_id int64, vat_tax_1 float64, vat_tax_2 float64) bool {
	rows, err := tx.Prepare("INSERT INTO vat_tax (`reservation_id`,`vat_tax_1`,`vat_tax_2`) VALUES (?,?,?) ON DUPLICATE KEY UPDATE `vat_tax_1`= ?, `vat_tax_2`= ?")
	if err != nil {
		log.Println(err)
	} else {
		_, err = rows.Exec(reservation_id, vat_tax_1, vat_tax_2, vat_tax_1, vat_tax_2)
		if err != nil {
			log.Println(err)
		}
		return true
	}
	return false
}

//Fetching all data from all tables to show in confirm page
func (tax TaxesModel) GetRoomTax(reservation_id string) RoomTax {
	var taxes RoomTax
	rows := utility.Db.QueryRow("SELECT `room_tax_1`, `room_tax_2` FROM `room_tax` Where reservation_id = ?", reservation_id)
	err := rows.Scan(&taxes.RoomTax1, &taxes.RoomTax2)
	if err != nil {
		log.Println(err)
	}
	return taxes
}

//Fetching all data from all tables to show in confirm page
func (tax TaxesModel) GetVATTax(reservation_id string) VATTax {
	var taxes VATTax
	rows := utility.Db.QueryRow("SELECT `vat_tax_1`, `vat_tax_2`  FROM `vat_tax` Where reservation_id = ?", reservation_id)
	err := rows.Scan(&taxes.VATTax1, &taxes.VATTax2)
	if err != nil {
		log.Println(err)
	}
	return taxes
}

func (tax TaxesModel) RemoveTax(tx *sql.Tx, removeid int64, typeOfTable string) bool {
	if typeOfTable == "service" {
		rows, err := tx.Prepare("DELETE FROM `room_service_tax` WHERE `room_service_tax`.`room_service_id` = ?")
		if err != nil {
			log.Println(err)
		} else {
			_, err = rows.Exec(removeid)
			if err != nil {
				log.Println(err)
			}
		}
	}
	return true
}
