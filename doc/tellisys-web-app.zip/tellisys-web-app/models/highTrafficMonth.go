package models

import (
    "log"
    "github.com/jmoiron/sqlx"
    "database/sql"
)

type HighTrafficMonth struct {
    Id int64
    Hotel_id int64
    Month sql.NullString
}

type HighTrafficMonthModel struct {
    DB * sqlx.DB
}


func(data HighTrafficMonthModel) InsertHighTrafficMonth(tx * sql.Tx, months HighTrafficMonth)(bool, error) {
    rows, err := tx.Prepare("INSERT INTO high_traffic_month(hotel_id, month) VALUES(?,?)")
    if err != nil {
        log.Println(err)
        return false, err
    }
    _, err = rows.Exec(months.Hotel_id, months.Month)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}

func(data HighTrafficMonthModel) DeleteHighTrafficMonth(tx * sql.Tx, hotel_id int64)(bool, error) {
    query, err  := tx.Prepare("DELETE FROM high_traffic_month where hotel_id=?")
    if err != nil {
        log.Println(err)
        return false, err
    }
    _, err = query.Exec(hotel_id)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}