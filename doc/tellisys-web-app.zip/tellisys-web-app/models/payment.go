package models

import (
	"database/sql"
	"log"

	"github.com/jmoiron/sqlx"
)

type Payments struct {
	Payment_id      int64
	ResId           int64
	CashPayDate     sql.NullInt64
	TransactionId   sql.NullString
	TransactionDate sql.NullInt64
	PaymentType     string
	Due_deposit     string
	Curr_timestamp  int64
}
type PaymentModel struct {
	DB *sqlx.DB
}

//Insert payment data
func (res PaymentModel) InsertCash(payment Payments, tx *sql.Tx) bool {
	rows, err := tx.Prepare("INSERT INTO reservation_payment(resId,cashPayDate,transactionId,transactionDate,paymentType,curr_timestamp) VALUES(?,?,?,?,?,?)")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(payment.ResId, payment.CashPayDate, payment.TransactionId, payment.TransactionDate, payment.PaymentType, payment.Curr_timestamp)
		if err != nil {
			log.Println(err)
		} else {
			if err != nil {
				log.Println(err)
			} else {
				defer rows.Close() // Prepared statements take up server resources and should be closed after use.
				return true
			}
		}
	}
	return false
}

//Update Due deposit in Reservation Collect table
func (res PaymentModel) UpdateCollect_dueDepo(payment Payments, tx *sql.Tx) bool {
	rows, err := tx.Prepare("UPDATE reservation_collect SET due_depo=? WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(payment.Due_deposit, payment.ResId)
		if err != nil {
			log.Println(err)
		} else {
			if err != nil {
				log.Println(err)
			} else {
				defer rows.Close() // Prepared statements take up server resources and should be closed after use.
				return true
			}
		}
	}
	return false
}
