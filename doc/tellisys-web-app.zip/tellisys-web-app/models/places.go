package models

import (
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type Places struct {
	Id      int64
	Country string
	State   string
	City    string
}

type PlacesModel struct {
	DB *sqlx.DB
}

func (plc PlacesModel) FetchAllCountry() ([]Places, bool) {
	var country []Places
	var count Places
	rows, err := utility.Db.Queryx("SELECT id,country From place")
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&count.Id, &count.Country)
			if err != nil {
				log.Println(err)
			} else {
				country = append(country, count)
			}
		}
	}
	return country, true
}

func (plc PlacesModel) GetAllStatesByCountry(CountryID int64) ([]Places, bool) {
	var states []Places
	var state Places
	rows, err := utility.Db.Queryx("SELECT id,state From place_state WHERE country_id=?", CountryID)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&state.Id, &state.State)
			if err != nil {
				log.Println(err)
			} else {
				states = append(states, state)
			}
		}
	}
	return states, true
}
func (plc PlacesModel) FetchCities_name(StateID int64) ([]Places, bool) {
	var cities []Places
	var city Places
	rows, err := utility.Db.Queryx("SELECT id,city From place_city WHERE state_id=?", StateID)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&city.Id, &city.City)
			if err != nil {
				log.Println(err)
			} else {
				cities = append(cities, city)
			}
		}
	}
	return cities, true
}
