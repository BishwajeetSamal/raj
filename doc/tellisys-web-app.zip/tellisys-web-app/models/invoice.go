package models

import (
	"database/sql"
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type Invoice struct {
	InvId           int64
	Time            int64
	Items           string
	Quantity        int64
	Unit_price      float64
	Total_price     float64
	Res_id          int64
	GetTime_kitchen string
	GetTime_date    string
	TotalSum        float64
	FirstName       string
	LastName        string
	ServiceTax1     float64
	ServiceTax2     float64
}
type FinalInvoiceStruct struct {
	InvStr  Invoice
	GuesStr Guest_reservation
	ColStr  Reservation
	HotStr  Setting
	RoomImg RoomTypeInReservation
}
type InvoiceModel struct {
	DB *sqlx.DB
}

func (inv InvoiceModel) Final_InvoiceData(getResreId FinalInvoiceStruct) ([]FinalInvoiceStruct, error) {
	var finIinvRows []FinalInvoiceStruct
	rows, err := utility.Db.Queryx("SELECT collect.Id,guest.first_name,guest.last_name,invoice.time,invoice.items,invoice.quantity,invoice.unit_price,invoice.total_price,img.path,collect.room_charges,collect.trip_total,collect.due_depo FROM authentication as auth INNER JOIN reservation_collect as collect INNER JOIN reservation_guest as guest ON collect.guest_id=guest.id INNER JOIN image as img ON collect.room_type_id=img.room_type_id INNER JOIN invoice_table as invoice ON invoice.res_id=collect.id WHERE collect.id=?", getResreId.InvStr.Res_id)
	if err != nil {
		log.Println(err)
	} else {
		var finIinv FinalInvoiceStruct
		for rows.Next() {
			err = rows.Scan(&finIinv.ColStr.Id, &finIinv.GuesStr.First_name, &finIinv.GuesStr.Last_name, &finIinv.InvStr.Time, &finIinv.InvStr.Items, &finIinv.InvStr.Quantity, &finIinv.InvStr.Unit_price, &finIinv.InvStr.Total_price, &finIinv.RoomImg.Images, &finIinv.ColStr.Room_charges, &finIinv.ColStr.Trip_total, &finIinv.ColStr.Due_depo)
			if err != nil {
				log.Println(err)
			} else {
				finIinvRows = append(finIinvRows, finIinv)
			}
		}
	}
	return finIinvRows, err
}

func (inv InvoiceModel) GetInvoiceTable_data(invoiceData Invoice) ([]Invoice, error) {
	var invoiceRows []Invoice
	rows, err := utility.Db.Queryx("SELECT inv.id, DATE_FORMAT(FROM_UNIXTIME(inv.time), '%Y-%m-%d') as `date`, DATE_FORMAT(FROM_UNIXTIME(inv.time), '%h:%i %p') as `timekitchen`, inv.items,inv.quantity,inv.unit_price,inv.total_price, inv.res_id,tax.room_service_tax_1, tax.room_service_tax_2 FROM invoice_table as inv Inner join room_service_tax as tax on tax.room_service_id = inv.id WHERE inv.res_id=?", invoiceData.Res_id)
	if err != nil {
		log.Println(err)
	} else {
		var invoice Invoice
		for rows.Next() {
			err = rows.Scan(&invoice.InvId, &invoice.GetTime_date, &invoice.GetTime_kitchen, &invoice.Items, &invoice.Quantity, &invoice.Unit_price, &invoice.Total_price, &invoice.Res_id, &invoice.ServiceTax1, &invoice.ServiceTax2)
			if err != nil {
				log.Println(err)
			} else {
				invoiceRows = append(invoiceRows, invoice)
			}
		}

	}
	return invoiceRows, err
}

func (inv InvoiceModel) InsertInvoiceData(tx *sql.Tx, invoiceData Invoice) (bool, int64) {
	rows, err := tx.Prepare("INSERT INTO invoice_table(time,items,quantity,unit_price,total_price,res_id) VALUES(?,?,?,?,?,?)")
	if err != nil {
		log.Println(err)
	} else {
		collectRow, err := rows.Exec(invoiceData.Time, invoiceData.Items, invoiceData.Quantity, invoiceData.Unit_price, invoiceData.Total_price, invoiceData.Res_id)
		if err != nil {
			log.Println(err)
			return false, -1
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			collectId, _ := collectRow.LastInsertId()
			return true, collectId
		}
	}
	return false, -1
}

func (inv InvoiceModel) UpdateInvoiceData(tx *sql.Tx, updateInvoice Invoice) bool {
	rows, err := tx.Prepare("UPDATE invoice_table SET time=?,items=?,quantity=?,unit_price=?,total_price=? WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(updateInvoice.Time, updateInvoice.Items, updateInvoice.Quantity, updateInvoice.Unit_price, updateInvoice.Total_price, updateInvoice.InvId)
		if err != nil {
			log.Println(err)
		} else {
			return true
		}
	}
	return false
}

func (inv InvoiceModel) DeleteInvoiceData(tx *sql.Tx, invoiceId Invoice) bool {
	deleteInvoice, _ := tx.Prepare("Delete FROM invoice_table WHERE id=?")
	_, err := deleteInvoice.Exec(invoiceId.InvId)
	if err != nil {
		log.Println(err)
	} else {
		return true
	}
	return false
}
