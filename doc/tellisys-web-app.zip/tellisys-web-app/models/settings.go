package models

import (
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type UserSetting struct {
	SettingsId      int64
	RoomTax1        float64
	RoomTax2        float64
	RoomServiceTax1 float64
	RoomServiceTax2 float64
	VATTax1         float64
	VATTax2         float64
}

type UserSettingModel struct {
	DB *sqlx.DB
}

//fmt.Sprintf("%v", utility.SessionGet(r, "id")
func (setting UserSettingModel) GetSettings(userId string) UserSetting {
	singleRow := UserSetting{RoomTax1: 1, RoomTax2: 1, RoomServiceTax1: 1, RoomServiceTax2: 1, VATTax1: 1, VATTax2: 1}
	rows := utility.Db.QueryRow("SELECT `room_tax_1`, `room_tax_2`, `room_service_tax_1`, `room_service_tax_2`, `vat_tax_1`, `vat_tax_2` FROM `user_setting` WHERE `user_id` = ?", userId)
	err := rows.Scan(&singleRow.RoomTax1, &singleRow.RoomTax2, &singleRow.RoomServiceTax1, &singleRow.RoomServiceTax2, &singleRow.VATTax1, &singleRow.VATTax2)
	if err != nil {
		log.Println(err)
	}
	return singleRow
}

func (setting UserSettingModel) SetSettings(Userid string, SettingColumn string, SettingValue int64) bool {
	query, err := utility.Db.Prepare("INSERT INTO user_setting (user_id, " + SettingColumn + ") VALUES (?,?) ON DUPLICATE KEY UPDATE " + SettingColumn + " =?")
	if err != nil {
		if err != nil {
			log.Println(err)
		}
		return false
	}
	_, err = query.Exec(Userid, SettingValue, SettingValue)
	if err != nil {
		if err != nil {
			log.Println(err)
		}
		return false
	}
	return true
}
