package models

import (
    "log"
    "github.com/jmoiron/sqlx"
    "database/sql"
)

type Image struct {
    image_id int32
    Room_type_id int64
    Path string
}

type ImageModel struct {
    DB * sqlx.DB
}

func(data ImageModel) InsertImage(tx * sql.Tx, image Image)(bool, error) {
    rows, err := tx.Prepare("INSERT INTO image(room_type_id, path) VALUES(?,?)")
    if err != nil {
        log.Println(err)
        return false, err
    }
    _, err = rows.Exec(image.Room_type_id, image.Path)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}