package models

import (
	"crypto/rand"
	"database/sql"
	"log"
	"math/big"
	"os"
	"reakgo/utility"
	"strconv"
	"time"

	"github.com/jmoiron/sqlx"
	"golang.org/x/crypto/bcrypt"
)

type Authentication struct {
	Id             int64
	First_name     string
	Last_name      string
	Email          string
	Phone          string
	Password       string
	Token          string
	TokenTimestamp int64
	Hotel_id       string
	CityId         int64
	City           string
	Status         int64
}

type AuthenticationModel struct {
	DB *sqlx.DB
}

type UserPlace struct {
	City    string
	Country string
	State   string
}

//InsertData is the func which is resposible for the data insertion and send email verification to user email in Signup/Register Page.
func (auth AuthenticationModel) InsertDatatoAuthTable(register Authentication, tx *sql.Tx) (bool, int64, error) {
	rows, err := tx.Prepare("INSERT INTO authentication(first_name,last_name,email,password,phone,hotel_id,token,tokenTimestamp,status) VALUES(?,?,?,?,?,?,?,?,?)")
	if err != nil {
		return false, 0, err
	} else {
		newPasswordHash, err := bcrypt.GenerateFromPassword([]byte(register.Password), 10)
		if err != nil {
			log.Println(err)
		} else {
			getUserId, err := rows.Exec(register.First_name, register.Last_name, register.Email, newPasswordHash, register.Phone, register.Hotel_id, register.Token, register.TokenTimestamp, 0)
			if err == nil {
				defer rows.Close() // Prepared statements take up server resources and should be closed after use.
				userId, _ := getUserId.LastInsertId()
				return true, userId, nil
			} else {
				return false, 0, err
			}
		}
	}
	defer rows.Close() // Prepared statements take up server resources and should be closed after use.
	return false, 0, err
}

func (auth AuthenticationModel) InsertUserPlaceData(area Authentication, tx *sql.Tx) (bool, error) {
	rows, err := tx.Prepare("INSERT INTO user_place(city_id,user_id) VALUES(?,?)")
	if err != nil {
		return false, err
	} else {
		_, err := rows.Exec(area.CityId, area.Id)
		if err == nil {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true, nil
		} else {
			return false, err
		}
	}
}

func (auth AuthenticationModel) CheckExistEmail(email string) (bool, error) {
	var count_row int
	var isExist bool
	rows := utility.Db.QueryRow("SELECT COUNT(*) as count FROM authentication WHERE email = ?", email)
	err := rows.Scan(&count_row)
	if err != nil {
		log.Println(err)
	} else {
		if count_row == 0 {
			isExist = false
		} else {
			isExist = true
		}
	}
	return isExist, err //isExist is here true if email is already present and false if email is not present

}

func (auth AuthenticationModel) GetUserByEmail(email string) (Authentication, error) {
	var selectedRow Authentication
	rows := utility.Db.QueryRow("SELECT id,hotel_id,email,password,token,tokenTimestamp,first_name FROM authentication WHERE email = ?", email)
	err := rows.Scan(&selectedRow.Id, &selectedRow.Hotel_id, &selectedRow.Email, &selectedRow.Password, &selectedRow.Token, &selectedRow.TokenTimestamp, &selectedRow.First_name)
	if err != nil {
		log.Println(err)
	}
	return selectedRow, err
}

func (auth AuthenticationModel) ForgotPassword(id int64) (string, error) {
	Token, err := GenerateRandomString(60)
	if err != nil {
		return "", err
	}
	TokenTimestamp := time.Now().Unix()
	query, err := utility.Db.Prepare("UPDATE authentication SET Token = ?, TokenTimestamp = ? WHERE id = ?")
	if err != nil {
		return "", err
	}
	_, err = query.Exec(Token, TokenTimestamp, id)
	if err != nil {
		return "", err
	}
	return Token, nil
}

func (auth AuthenticationModel) GenTokenForVerification(id int64) (string, error) {
	Token, err := GenerateRandomString(65)
	if err != nil {
		return "", err
	}
	TokenTimestamp := time.Now().Unix()
	query, err := utility.Db.Prepare("UPDATE authentication SET Token = ?, TokenTimestamp = ? WHERE id = ?")
	if err != nil {
		return "", err
	}
	_, err = query.Exec(Token, TokenTimestamp, id)
	if err != nil {
		return "", err
	}
	return Token, nil
}

func GenerateRandomString(n int) (string, error) {
	const letters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-"
	ret := make([]byte, n)
	for i := 0; i < n; i++ {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(letters))))
		if err != nil {
			return "", err
		}
		ret[i] = letters[num.Int64()]
	}

	return string(ret), nil
}

func (auth AuthenticationModel) TokenVerify(email, token string, newPassword string) (bool, bool, error) {
	var selectedRow Authentication
	//times now -  token that expires in 24 hours by-default.
	email_expire_time, err := strconv.ParseInt(os.Getenv("EMAIL_TOKEN_EXPIRE"), 10, 64)
	if err != nil {
		email_expire_time = 86400
	}
	rows := utility.Db.QueryRow("SELECT id, tokentimestamp FROM authentication WHERE `email` = ? AND `token` = ?", email, token)
	err = rows.Scan(&selectedRow.Id, &selectedRow.TokenTimestamp)
	if err != nil {
		return false, false, err
	}
	if selectedRow.TokenTimestamp >= (time.Now().Unix() - email_expire_time) {
		if newPassword == "" {
			rows, err := utility.Db.Prepare("UPDATE authentication SET status = ? WHERE id = ?")
			if err != nil {
				log.Println(err)
			} else {
				_, err = rows.Exec(1, selectedRow.Id)
				if err != nil {
					log.Println(err)
					return false, false, nil
				} else {
					return true, false, nil
				}
			}
		} else {
			_, err := auth.ChangePassword(newPassword, selectedRow.Id)
			if err != nil {
				return false, false, err
			}
		}

	} else {
		return false, true, nil
	}
	return true, false, nil
}

func (auth AuthenticationModel) CheckStatus(email, token string) int64 {
	var selectedRow Authentication
	rows := utility.Db.QueryRow("SELECT id,status FROM authentication WHERE `email` = ? AND `token` = ?", email, token)
	err := rows.Scan(&selectedRow.Id, &selectedRow.Status)
	if err != nil {
		log.Println(err)
	} else {
		return selectedRow.Status

	}
	return selectedRow.Status
}

func (auth AuthenticationModel) ChangePassword(newPassword string, id int64) (bool, error) {
	query, err := utility.Db.Prepare("UPDATE authentication SET password = ? WHERE id = ?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	newPasswordHash, err := bcrypt.GenerateFromPassword([]byte(newPassword), 10)
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(newPasswordHash, id)
	if err != nil {
		log.Println(err)
		return false, err
	}
	return true, nil
}

func (auth AuthenticationModel) GetUserPlace(id int) (UserPlace, error) {
	var selectedRow UserPlace
	rows := utility.Db.QueryRow("SELECT pc.city, ps.state, p.country FROM user_place up inner join place_city pc on up.city_id=pc.id inner join place_state ps on pc.state_id=ps.id inner join place p on ps.country_id=p.id WHERE user_id = ?", id)
	err := rows.Scan(&selectedRow.City, &selectedRow.Country, &selectedRow.State)
	if err != nil {
		log.Println(err)
	}
	return selectedRow, err
}

func (auth AuthenticationModel) DelAuthandUserPlace(user_id int64) bool {
	deleteuser_place, _ := utility.Db.Prepare("Delete FROM user_place WHERE id=?")
	_, err := deleteuser_place.Exec(user_id)
	if err != nil {
		log.Println(err)
	} else {
		deleteAuth, _ := utility.Db.Prepare("Delete FROM authentication WHERE id=?")
		_, err := deleteAuth.Exec(user_id)
		if err != nil {
			log.Println(err)
		} else {
			return true
		}
	}
	return false
}
