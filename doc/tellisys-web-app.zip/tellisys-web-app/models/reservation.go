package models

import (
	"database/sql"
	"log"
	"reakgo/utility"
	"strconv"

	"github.com/jmoiron/sqlx"
)

type Reservation struct {
	Id                string
	CheckIn           string
	CheckOut          string
	Adult             int64
	Child             int64
	Collect_rack_rate string
	Room_type_id      int64
	Room_no_id        sql.NullInt64
	Room_number       string
	Userid            int64
	Room_charges      string
	Trip_total        string
	Due_depo          string
	Guest_id          sql.NullInt64
	Balance           int64
	Res_Id            int64
	Room_no           string
	Timestamp         int64
}

type AssginUnassignRoom struct {
	CheckIn      string
	CheckOut     string
	Counting     string
	Room_type_id string
	Themes       string
}

type ReservationsDetails struct {
	ReservationId   int64
	GuestName       sql.NullString
	ReservationDate sql.NullString
	CheckIn         string
	CheckOut        string
	Adults          int64
	Children        int64
	RoomType        sql.NullString
	RoomNumber      sql.NullString
	PaymentStatus   string
	CheckInMiss     string
}

type ReservationAndTax struct {
	Reserv Reservation
	Taxes  TAX
}
type ReservationModel struct {
	DB *sqlx.DB
}

//Fetching all data from all tables to show in confirm page
func (res ReservationModel) GetAllDataFinal(res_id string, log_id string) (CollectAll, error) {
	var fetchalldata CollectAll
	rows, err := utility.Db.Queryx("SELECT DATE_FORMAT(FROM_UNIXTIME(collect.checkin), '%Y-%m-%d') AS 'CheckIn',DATE_FORMAT(FROM_UNIXTIME(collect.checkout), '%Y-%m-%d') AS 'checkOut',collect.adult,collect.child,collect.room_charges,collect.trip_total,collect.room_type_id,guest.first_name,guest.last_name,guest.email,guest.phone,guest.address,payment.id,payment.resid,hotel.hotel_name, hotel_list.hotel_address,room.check_in_hour,room.check_in_minu,room.check_in_ampm,room.check_out_hour,room.check_out_minu,room.check_out_ampm,img.path,room.name, collect.userid FROM reservation_collect as collect LEFT JOIN reservation_guest as guest ON collect.guest_id=guest.id LEFT JOIN reservation_payment as payment ON collect.id=payment.resid INNER JOIN room_type as room ON room.room_type_id=collect.room_type_id INNER JOIN image as img ON room.room_type_id=img.room_type_id INNER JOIN hotels as hotel ON hotel.user_id = collect.userid INNER JOIN hotel_list as hotel_list ON hotel.uniqueId = hotel_list.hotel_id WHERE collect.id= ? AND collect.userid = ?", res_id, log_id)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&fetchalldata.CheckIn, &fetchalldata.CheckOut, &fetchalldata.Reservation.Adult, &fetchalldata.Reservation.Child, &fetchalldata.Room_charges, &fetchalldata.Trip_total, &fetchalldata.Room_type_id, &fetchalldata.First_name, &fetchalldata.Last_name, &fetchalldata.Email, &fetchalldata.Phone, &fetchalldata.Address, &fetchalldata.Payment_id, &fetchalldata.ResId, &fetchalldata.Hotel_name, &fetchalldata.Hotel_address, &fetchalldata.Check_in_hour, &fetchalldata.Check_in_minu, &fetchalldata.Check_in_ampm, &fetchalldata.Check_out_hour, &fetchalldata.Check_out_minu, &fetchalldata.Check_out_ampm, &fetchalldata.Images, &fetchalldata.Name, &fetchalldata.Userid)
		}
	}
	return fetchalldata, err
}
func (res ReservationModel) InsertUserCollectData(tx *sql.Tx, register Reservation) (bool, int64, error) {
	if register.Room_number != "unassigned" {
		get_room_noId := tx.QueryRow("SELECT id FROM roomNo WHERE room_no = ?", register.Room_number)
		err := get_room_noId.Scan(&register.Room_no_id)
		if err != nil {
			log.Println(err)
		}
	}
	rows, err := tx.Prepare("INSERT INTO reservation_collect(checkin,checkout,adult,child,collect_rack_rate,room_no_id,room_type_id,userid,room_charges,trip_total,due_depo,timestamp) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
	if err != nil {
		log.Println(err)
	} else {
		collectRow, err := rows.Exec(register.CheckIn, register.CheckOut, register.Adult, register.Child, register.Collect_rack_rate, register.Room_no_id, register.Room_type_id, register.Userid, register.Room_charges, register.Trip_total, register.Due_depo, register.Timestamp)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			collectId, _ := collectRow.LastInsertId()
			return true, collectId, nil
		}
	}
	return false, -1, err
}

func (auth ReservationModel) CheckExistEmailforGuest(email string) (int64, bool) {
	var count_row int
	var id int64
	var isExist bool
	rows := utility.Db.QueryRow("SELECT COUNT(*) as count,id FROM reservation_guest WHERE email = ? GROUP BY id", email)
	err := rows.Scan(&count_row, &id)
	if err == sql.ErrNoRows {
		isExist = false
		return id, isExist
	} else {
		if count_row != 0 {
			isExist = true
			return id, isExist
		}
	}
	return id, isExist //isExist is here true if email is already present and false if email is not present/new

}

//This func update the reservation collect table if geust if reservation is doing through the existing user and just update the
//guest_id column by reservation id.
func (res ReservationModel) UpdateCollect_guestId(id int64, reservation_id int64, tx *sql.Tx) bool {
	rows, err := tx.Prepare("UPDATE reservation_collect SET guest_id=? WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(id, reservation_id)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true
		}
	}
	return false
}

func (res ReservationModel) FetchPriceData(collectId int64) (ReservationAndTax, error) {
	var price ReservationAndTax
	rows, err := utility.Db.Queryx("SELECT res.checkin,res.checkout, res.adult, res.child, res.collect_rack_rate, res.room_no_id, res.room_type_id, res.userid, res.room_charges,res.trip_total,res.due_depo,  rt.room_tax_1, rt.room_tax_2, vt.vat_tax_1, vt.vat_tax_2 FROM reservation_collect as res INNER JOIN room_tax as rt ON rt.reservation_id = res.id INNER JOIN vat_tax as vt ON vt.reservation_id WHERE id = ?", collectId)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&price.Reserv.CheckIn, &price.Reserv.CheckOut, &price.Reserv.Adult, &price.Reserv.Child, &price.Reserv.Collect_rack_rate, &price.Reserv.Room_no_id, &price.Reserv.Room_type_id, &price.Reserv.Userid, &price.Reserv.Room_charges, &price.Reserv.Trip_total, &price.Reserv.Due_depo, &price.Taxes.RoomTax.RoomTax1, &price.Taxes.RoomTax.RoomTax2, &price.Taxes.VatTax.VATTax1, &price.Taxes.VatTax.VATTax2)
			if err != nil {
				log.Println(err)
			}
		}
	}
	return price, err
}

func (reservation ReservationModel) Reservation_timeline(res_reserve Reservation) []RoomTypeExtra {
	var data []RoomTypeExtra
	Query := "SELECT room.room_type_id, room.name, room.abbreviation, guest.firstName,guest.lastName, DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%d-%m-%Y') AS 'checkin', DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%d-%m-%Y') AS 'checkout', reservation.checkin, reservation.trip_total, reservation.due_depo,reservation.adult,reservation.child, guest.address, guest.city, guest.state, guest.country FROM `reservation_collect` reservation inner JOIN room_type room on room.room_type_id = reservation.room_type_id inner join reservation_guest guest on guest.id= reservation.guest_id WHERE DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%Y%m%d') BETWEEN ? and ? OR DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%Y%m%d') BETWEEN ? and ? ORDER BY `room`.`room_type_id` ASC"
	rows, err := utility.Db.Queryx(Query, res_reserve.CheckIn, res_reserve.CheckOut, res_reserve.CheckIn, res_reserve.CheckOut)
	if err != nil {
		log.Println(err)
	}
	for rows.Next() {
		var singleRow RoomTypeExtra
		err := rows.Scan(&singleRow.Room_type_id, &singleRow.Roomtype.Name, &singleRow.Roomtype.Abbreviation, &singleRow.First_name, &singleRow.Last_name, &singleRow.CheckIn, &singleRow.CheckOut, &singleRow.CheckInTimeTimeStamp, &singleRow.Trip_total, &singleRow.Due_depo, &singleRow.Adult, &singleRow.Child, &singleRow.Address, &singleRow.City, &singleRow.State, &singleRow.Country)
		if err != nil {
			log.Println(err)
		}
		singleRow.Themes = utility.TestRandom(singleRow.CheckInTimeTimeStamp, true)
		data = append(data, singleRow)
	}
	return data
}

func (reservation ReservationModel) AssignUnassignRoom(requestfilter Reservation, IsAssign bool) []AssginUnassignRoom {
	var data []AssginUnassignRoom
	var Query string
	Condition := "DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%Y%m%d') BETWEEN ? and ? AND DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%Y%m%d') BETWEEN ? and ?"
	if requestfilter.Adult != 0 {
		Condition = Condition + " AND reservation.adult <= " + strconv.Itoa(int(requestfilter.Adult))
	}
	if requestfilter.Child != 0 {
		Condition = Condition + " AND reservation.child <= " + strconv.Itoa(int(requestfilter.Child))
	}
	if IsAssign {
		Query = "SELECT (DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%d-%m-%Y')) AS 'CheckInTime' , max(DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%d-%m-%Y')) AS 'CheckOutTime', count(rno.room_type_id) as book, IFNULL(max(rno.room_type_id),'') as room_type_id FROM `reservation_collect` as reservation left JOIN roomNo rno on rno.id = reservation.room_no WHERE " + Condition + " group by CheckInTime"
	} else {
		Query = "SELECT DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%d-%m-%Y') AS 'CheckInTime' , MAX( DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%d-%m-%Y')) AS 'CheckOutTime' , sum(CASE WHEN reservation.`room_no` !=0 AND reservation.`room_no` IS NOT NULL THEN 1 ELSE 0 END) as reserv FROM `reservation_collect` as reservation WHERE " + Condition + " group by CheckInTime ORDER BY CheckInTime ASC"
	}
	rows, err := utility.Db.Queryx(Query, requestfilter.CheckIn, requestfilter.CheckOut, requestfilter.CheckIn, requestfilter.CheckOut)
	if err != nil {
		log.Println(err)
	}
	for rows.Next() {
		var singleRow AssginUnassignRoom
		var err error
		if IsAssign {
			err = rows.Scan(&singleRow.CheckIn, &singleRow.CheckOut, &singleRow.Counting, &singleRow.Room_type_id)
			if err != nil {
				log.Println(err)
			}
		} else {
			err = rows.Scan(&singleRow.CheckIn, &singleRow.CheckOut, &singleRow.Counting)
			if err != nil {
				log.Println(err)
			}
			singleRow.Themes = "unassign"
		}
		data = append(data, singleRow)
	}
	return data
}

func (res ReservationModel) GetDataCollectEdit(collectResId int64) (Reservation, error) {
	var getGenData Reservation
	rows, err := utility.Db.Queryx("SELECT * FROM reservation_collect INNER JOIN roomNo as room ON reservation_collect.room_no_id=room.id  WHERE reservation_collect.id = ?", collectResId)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.StructScan(&getGenData)
			if err != nil {
				log.Println(err)
			}
		}
	}
	return getGenData, err
}

func (res ReservationModel) UpdateUserCollectData(updateData Reservation) bool {
	if updateData.Room_number != "unassigned" {
		get_room_noId := utility.Db.QueryRow("SELECT id FROM roomNo WHERE room_no = ?", updateData.Room_number)
		err := get_room_noId.Scan(&updateData.Room_no_id)
		if err != nil {
			log.Println(err)
		}
	}
	rows, err := utility.Db.Prepare("UPDATE reservation_collect SET checkin=?,checkout=?,adult=?,child=?,collect_rack_rate=?,room_type_id=?,userid=?,room_charges=?,room_no_id=?,trip_total=?,due_depo=? WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err := rows.Exec(updateData.CheckIn, updateData.CheckOut, updateData.Adult, updateData.Child, updateData.Collect_rack_rate, updateData.Room_type_id, updateData.Userid, updateData.Room_charges, updateData.Room_no_id, updateData.Trip_total, updateData.Due_depo, updateData.Res_Id)
		if err != nil {
			log.Println(err)
		} else {
			defer rows.Close() // Prepared statements take up server resources and should be closed after use.
			return true
		}
	}
	return false
}

func (res ReservationModel) Delete_reservationdataById(resservation Reservation) (bool, error) {
	query, err := utility.Db.Prepare("DELETE FROM reservation_collect WHERE id=?")
	if err != nil {
		log.Println(err)
	} else {
		_, err = query.Exec(resservation.Res_Id)
		if err == nil {
			return true, err
		}
	}
	return false, err
}
