package models

import (
	"database/sql"
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type Hotels struct {
	Id                 int64
	User_id            int64
	Hotel_name         sql.NullString
	Primary_customer   sql.NullString
	Nearest_competitor sql.NullString
	Years_in_operation sql.NullInt64
	Hotel_rating       sql.NullInt64
	Status             int64
	HotelsUniqueId     sql.NullString
}

type HotelsModel struct {
	DB *sqlx.DB
}

type Hotel struct {
	FirstName string
	Status    bool
	Hotel     Hotels
	Months    []HighTrafficMonth
	Dashboard Dashboard
}

func (data HotelsModel) InsertHotel(tx *sql.Tx, hotel Hotels) (int64, error) {
	var id int64
	rows, err := tx.Prepare("INSERT INTO hotels (user_id,hotel_name,primary_customer,nearest_competitor,years_in_operation,hotel_rating,status,uniqueId) VALUES(?,?,?,?,?,?,?,?)")
	if err != nil {
		log.Println(err)
		return id, err
	}
	res, err := rows.Exec(hotel.User_id, hotel.Hotel_name, hotel.Primary_customer, hotel.Nearest_competitor, hotel.Years_in_operation, hotel.Hotel_rating, hotel.Status, hotel.HotelsUniqueId)
	if err != nil {
		log.Println(err)
		return id, err
	}
	id, err = res.LastInsertId()
	if err != nil {
		log.Println(err)
		return id, err
	}
	return id, nil
}

func (modal HotelsModel) FetchHotel(user_id int64) (Hotel, error) {
	var data Hotel
	rows := utility.Db.QueryRow("SELECT id, hotel_name, primary_customer, nearest_competitor, years_in_operation, hotel_rating, status, uniqueId FROM `hotels` WHERE user_id =?", user_id)
	err := rows.Scan(&data.Hotel.Id, &data.Hotel.Hotel_name, &data.Hotel.Primary_customer, &data.Hotel.Nearest_competitor, &data.Hotel.Years_in_operation, &data.Hotel.Hotel_rating, &data.Hotel.Status, &data.Hotel.HotelsUniqueId)
	if err != nil {
		log.Println(err)
		return data, err
	}
	rows1, err := utility.Db.Queryx("SELECT month.month  FROM `high_traffic_month` month WHERE month.hotel_id =?", data.Hotel.Id)
	if err != nil {
		log.Println(err)
		return data, err
	}
	for rows1.Next() {
		var singleRow HighTrafficMonth
		err = rows1.Scan(&singleRow.Month)
		if err != nil {
			log.Println(err)
			return data, err
		}
		data.Months = append(data.Months, singleRow)
	}
	data.Status = true
	return data, nil
}

func (data HotelsModel) UpdateHotel(tx *sql.Tx, hotel Hotels) (bool, error) {
	query, err := tx.Prepare("UPDATE hotels set hotel_name=?, primary_customer=?, nearest_competitor=?, years_in_operation=?, hotel_rating=?, status=?, uniqueId=? where id =? && user_id=?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(hotel.Hotel_name, hotel.Primary_customer, hotel.Nearest_competitor, hotel.Years_in_operation, hotel.Hotel_rating, hotel.Status, hotel.HotelsUniqueId, hotel.Id, hotel.User_id)
	if err != nil {
		log.Println(err)
		return false, err
	}
	return true, nil
}

func (data HotelsModel) UpdateHotelIdtoAuth(tx *sql.Tx, userId int64, hotelId int64) bool {
	query, err := tx.Prepare("UPDATE authentication set hotel_id=? where id=?")
	if err != nil {
		log.Println(err)
		return false
	}
	_, err = query.Exec(hotelId, userId)
	if err != nil {
		log.Println(err)
		return false
	} else {
		return true
	}
}
