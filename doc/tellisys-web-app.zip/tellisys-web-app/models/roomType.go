package models

import (
	"database/sql"
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type RoomType struct {
	Room_type_id                int64
	User_id                     int64
	Name                        string
	Abbreviation                string
	Max_adult                   int64
	Max_children                int64
	Check_in_hour               int64
	Check_in_minu               int64
	Check_in_ampm               string
	Check_out_hour              int64
	Check_out_minu              int64
	Check_out_ampm              string
	Base_price                  int64
	Pet_allowed                 int64
	Total_rooms                 int64
	Status                      int64
	Smoking_allowed             int64
	Description                 string
	Permit_tax_id               string
	Check_in_method             string
	Check_in_instruction        string
	Children_infant_restriction string
	Cancellation_policy         string
}
type RoomTypeExtra struct {
	Roomtype RoomType
	Reservation
	Guest_reservation
	Images               string
	CheckInTimeTimeStamp string
	UnNoOfRoom           string
	Themes               string
}

type RoomTypeInReservation struct {
	RoomType
	Images               sql.NullString
	CheckInTime          string
	CheckInTimeTimeStamp string
	CheckOutTime         string
	Adult                int64
	Child                int64
	Total                int64
}

type RoomTypeData struct {
	Roomtype RoomType
	Bed      []Bed
	Room     []Room
	RoomNo   []RoomNo
	Image    []Image
}

type RoomTypeModel struct {
	DB *sqlx.DB
}

func (data RoomTypeModel) InsertRoomType(tx *sql.Tx, room_type RoomType) (int64, error) {
	var id int64
	rows, err := tx.Prepare("INSERT INTO room_type (user_id,name,abbreviation,max_adult_allowed,max_children_allowed,check_in_hour,check_in_minu,check_in_ampm,check_out_hour,check_out_minu,check_out_ampm,base_price,pet_allowed,status,total_rooms,smoking_allowed,description,permit_tax_id,check_in_method,check_in_instruction,children_infant_restriction,cancellation_policy) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
	if err != nil {
		log.Println(err)
		return id, err
	}
	res, err := rows.Exec(room_type.User_id, room_type.Name, room_type.Abbreviation, room_type.Max_adult, room_type.Max_children, room_type.Check_in_hour, room_type.Check_in_minu, room_type.Check_in_ampm, room_type.Check_out_hour, room_type.Check_out_minu, room_type.Check_out_ampm, room_type.Base_price, room_type.Pet_allowed, room_type.Status, room_type.Total_rooms, room_type.Smoking_allowed, room_type.Description, room_type.Permit_tax_id, room_type.Check_in_method, room_type.Check_in_instruction, room_type.Children_infant_restriction, room_type.Cancellation_policy)
	if err != nil {
		log.Println(err)
		return id, err
	}
	id, err = res.LastInsertId()
	if err != nil {
		log.Println(err)
		return id, err
	}
	return id, nil
}
func (data RoomTypeModel) FetchRoomType(id int64) (RoomTypeData, error) {
	var room_type RoomTypeData

	//fetching Details from room_type table
	rows := utility.Db.QueryRow("SELECT room_type_id,name,abbreviation,max_adult_allowed,max_children_allowed,check_in_hour,check_in_minu,check_in_ampm,check_out_hour,check_out_minu,check_out_ampm,base_price,pet_allowed,status,total_rooms,smoking_allowed,description,permit_tax_id,check_in_method,check_in_instruction,children_infant_restriction,cancellation_policy FROM `room_type` WHERE room_type_id =?", id)
	err := rows.Scan(&room_type.Roomtype.Room_type_id, &room_type.Roomtype.Name, &room_type.Roomtype.Abbreviation, &room_type.Roomtype.Max_adult, &room_type.Roomtype.Max_children, &room_type.Roomtype.Check_in_hour, &room_type.Roomtype.Check_in_minu, &room_type.Roomtype.Check_in_ampm, &room_type.Roomtype.Check_out_hour, &room_type.Roomtype.Check_out_minu, &room_type.Roomtype.Check_out_ampm, &room_type.Roomtype.Base_price, &room_type.Roomtype.Pet_allowed, &room_type.Roomtype.Status, &room_type.Roomtype.Total_rooms, &room_type.Roomtype.Smoking_allowed, &room_type.Roomtype.Description, &room_type.Roomtype.Permit_tax_id, &room_type.Roomtype.Check_in_method, &room_type.Roomtype.Check_in_instruction, &room_type.Roomtype.Children_infant_restriction, &room_type.Roomtype.Cancellation_policy)
	if err != nil {
		log.Println(err)
		return room_type, err
	}

	//fetching Details from bed table
	records, err := utility.Db.Queryx("SELECT bed_type, quantity  FROM `bed` WHERE room_type_id =?", id)
	if err != nil {
		log.Println(err)
		return room_type, err
	}
	for records.Next() {
		var singleRow Bed
		err = records.Scan(&singleRow.Bed_type, &singleRow.Quantity)
		if err != nil {
			log.Println(err)
			return room_type, err
		}
		room_type.Bed = append(room_type.Bed, singleRow)
	}

	//fetching Details from room table
	records, err = utility.Db.Queryx("SELECT room_type, quantity  FROM `room` WHERE room_type_id=?", id)
	if err != nil {
		log.Println(err)
		return room_type, err
	}
	for records.Next() {
		var singleRow Room
		err = records.Scan(&singleRow.Room_type, &singleRow.Quantity)
		if err != nil {
			log.Println(err)
			return room_type, err
		}
		room_type.Room = append(room_type.Room, singleRow)
	}

	//fetching Details from roomNo table
	records, err = utility.Db.Queryx("SELECT room_no  FROM `roomNo` WHERE room_type_id=?", id)
	if err != nil {
		log.Println(err)
		return room_type, err
	}
	for records.Next() {
		var singleRow RoomNo
		err = records.Scan(&singleRow.Room_no)
		if err != nil {
			log.Println(err)
			return room_type, err
		}
		room_type.RoomNo = append(room_type.RoomNo, singleRow)
	}

	//fetching Details from image table
	records, err = utility.Db.Queryx("SELECT path FROM `image` WHERE room_type_id=?", id)
	if err != nil {
		log.Println(err)
		return room_type, err
	}
	for records.Next() {
		var singleRow Image
		err = records.Scan(&singleRow.Path)

		if err != nil {
			log.Println(err)
			return room_type, err
		}
		room_type.Image = append(room_type.Image, singleRow)
	}
	//log.Println(room_type);
	return room_type, nil
}

func (data RoomTypeModel) UpdateRoomType(tx *sql.Tx, room_type RoomType) (bool, error) {

	query, err := tx.Prepare("UPDATE room_type set name=?, abbreviation=?, max_adult_allowed=?, max_children_allowed=? ,check_in_hour=? ,check_in_minu=? ,check_in_ampm=? ,check_out_hour=? ,check_out_minu=? ,check_out_ampm=? ,base_price=?, pet_allowed=?, status=?, total_rooms=?,smoking_allowed=?, description=?, permit_tax_id=?, check_in_method=?, check_in_instruction=?,children_infant_restriction=?, cancellation_policy=? where room_type_id =?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(room_type.Name, room_type.Abbreviation, room_type.Max_adult, room_type.Max_children, room_type.Check_in_hour, room_type.Check_in_minu, room_type.Check_in_ampm, room_type.Check_out_hour, room_type.Check_out_minu, room_type.Check_out_ampm, room_type.Base_price, room_type.Pet_allowed, room_type.Status, room_type.Total_rooms, room_type.Smoking_allowed, room_type.Description, room_type.Permit_tax_id, room_type.Check_in_method, room_type.Check_in_instruction, room_type.Children_infant_restriction, room_type.Cancellation_policy, room_type.Room_type_id)
	if err != nil {
		log.Println(err)
		return false, err
	}

	//Delete records from Bed table
	query, err = tx.Prepare("DELETE FROM bed where room_type_id=?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(room_type.Room_type_id)
	if err != nil {
		log.Println(err)
		return false, err
	}

	//Delete records from Room table
	query, err = tx.Prepare("DELETE FROM room where room_type_id=?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(room_type.Room_type_id)
	if err != nil {
		log.Println(err)
		return false, err
	}

	//Delete records from RoomNo table
	query, err = tx.Prepare("DELETE FROM roomNo where room_type_id=?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(room_type.Room_type_id)
	if err != nil {
		log.Println(err)
		return false, err
	}

	//Delete records from Image table
	query, err = tx.Prepare("DELETE FROM image where room_type_id=?")
	if err != nil {
		log.Println(err)
		return false, err
	}
	_, err = query.Exec(room_type.Room_type_id)
	if err != nil {
		log.Println(err)
		return false, err
	}
	return true, nil
}
