package models

import (
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type CollectAll struct {
	Reservation
	Guest_reservation
	Payments
	RoomTypeInReservation
	Setting
	CreatedOn   string
	Totalrooms  int64
	RoomTypeId  int64
	Reserv      int64
	Room_nos    string
	Room_nos1   []string
	RoomNumber  string
	UserSetting UserSetting
}

type Setting struct {
	S_id          int64
	Hotel_name    string
	Hotel_email   string
	Hotel_phone   string
	Hotel_address string
	User_id       string
	Hotel_id      string
	Current       string
}

type CollectAllModel struct {
	DB *sqlx.DB
}

func (data1 CollectAllModel) GetRoomsData() []CollectAll {
	var data []CollectAll
	var getRoomData CollectAll
	rows, err := utility.Db.Queryx("SELECT count(*) As totalrooms , (roomNo.room_type_id) As room_type_id, GROUP_CONCAT(roomNo.room_no) As Rooms, room_type.name,room_type.base_price,(SELECT img.path from image as img WHERE img.room_type_id = room_type.room_type_id LIMIT 1 ) as img FROM `roomNo` inner join room_type on room_type.room_type_id = roomNo.room_type_id group by roomNo.room_type_id order by roomNo.room_type_id")
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&getRoomData.Totalrooms, &getRoomData.RoomTypeId, &getRoomData.Room_nos, &getRoomData.Hotel_name, &getRoomData.Base_price, &getRoomData.Images)
			if err != nil {
				log.Println(err)
			} else {
				data = append(data, getRoomData)
			}
		}
	}
	return data
}

func (data CollectAllModel) GetReservedData(requestfilter Reservation) []CollectAll {
	var getReservedData CollectAll
	var pushReservedData []CollectAll
	Query := "SELECT sum(CASE WHEN reservation.`room_no_id` !=0 AND reservation.`room_no_id` IS NOT NULL THEN 1 ELSE 0 END) as reserv,GROUP_CONCAT(roomNo.room_no) as room_no, max(roomNo.`room_type_id` ) as reserv_roomtypeId FROM `reservation_collect` as reservation INNER join roomNo on reservation.room_no_id = roomNo.id WHERE DATE_FORMAT(FROM_UNIXTIME(reservation.checkin), '%Y%m%d') BETWEEN ? and ? AND DATE_FORMAT(FROM_UNIXTIME(reservation.checkout), '%Y%m%d') BETWEEN ? and ? GROUP BY `roomNo`.`room_type_id` ORDER BY `roomNo`.`room_type_id` ASC"
	rows, err := utility.Db.Queryx(Query, requestfilter.CheckIn, requestfilter.CheckOut, requestfilter.CheckIn, requestfilter.CheckOut)
	if err != nil {
		log.Println(err)
	} else {
		for rows.Next() {
			err = rows.Scan(&getReservedData.Reserv, &getReservedData.Room_nos, &getReservedData.RoomTypeId)
			if err != nil {
				log.Println(err)
			} else {
				pushReservedData = append(pushReservedData, getReservedData)
			}
		}
	}
	return pushReservedData
}
