package models

import (
	"log"
	"reakgo/utility"

	"github.com/jmoiron/sqlx"
)

type RoomPrice struct {
	RoomTypeId        int64
	DateTime          string
	Price             float64
	RatePlan          string
	DateTimeTimeStamp int64
}

type RoomPriceModel struct {
	DB *sqlx.DB
}

func (price RoomPriceModel) Inventory_price(inventory Reservation, ratePlan string, userid string) ([]RoomPrice, error) {
	var data []RoomPrice
	rows, err := utility.Db.Queryx("SELECT room.room_type_id, rprice.price, DATE_FORMAT(FROM_UNIXTIME(rprice.dateTime), '%d-%m-%Y') AS 'timestamp', IFNULL(rprice.rateplan, '') as rateplan, rprice.dateTime FROM `room_type` room INNER JOIN room_price rprice on room.room_type_id = rprice.roomTypeId WHERE room.user_id =?", userid)
	if err != nil {
		log.Println(err)
	}
	for rows.Next() {
		var singleRow RoomPrice
		err := rows.Scan(&singleRow.RoomTypeId, &singleRow.Price, &singleRow.DateTime, &singleRow.RatePlan, &singleRow.DateTimeTimeStamp)
		if err != nil {
			log.Println(err)
		}
		data = append(data, singleRow)
	}
	return data, nil
}

func (price RoomPriceModel) Inventory_price_is_exist(inventory RoomPrice) bool {
	var counter int
	rows := utility.Db.QueryRow("SELECT count(dateTime) as count FROM `room_price` WHERE roomTypeId =? and dateTime= ?", inventory.RoomTypeId, inventory.DateTimeTimeStamp)
	err := rows.Scan(&counter)
	if err != nil {
		log.Println(err)
	}
	if counter != 0 {
		return true
	}
	return false
}

func (price RoomPriceModel) Inventory_price_insert_update(inventory RoomPrice, purpose string) (bool, error) {
	var query_string string
	if purpose == "insert" {
		query_string = "INSERT INTO room_price (`price`, `roomTypeId`,`dateTime`, `rateplan`) VALUES (?,?,?,?)"
	}
	if purpose == "update" {
		query_string = "UPDATE room_price set price = ? where roomTypeId =? AND dateTime = ? and rateplan = ?"
	}
	query, err := utility.Db.Prepare(query_string)
	if err != nil {
		return false, err
	}
	_, err = query.Exec(inventory.Price, inventory.RoomTypeId, inventory.DateTimeTimeStamp, inventory.RatePlan)
	if err != nil {
		return false, err
	}
	return true, nil
}

func (price RoomPriceModel) Inventory_price_set(inventory RoomPrice) (bool, error) {
	result := false
	var err error
	if price.Inventory_price_is_exist(inventory) {
		result, err = price.Inventory_price_insert_update(inventory, "update")
	} else {
		result, err = price.Inventory_price_insert_update(inventory, "insert")
	}
	return result, err
}
