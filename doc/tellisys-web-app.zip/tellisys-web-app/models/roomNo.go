package models

import (
    "log"
    "github.com/jmoiron/sqlx"
    "database/sql"
)

type RoomNo struct {
    Room_no_id int32
    Room_type_id int64
    Room_no string
}

type RoomNoModel struct {
    DB * sqlx.DB
}

func(data RoomNoModel) InsertRoomNo(tx * sql.Tx, roomNo RoomNo)(bool, error) {
    rows, err  := tx.Prepare("INSERT INTO roomNo(room_type_id, room_no) VALUES(?,?)")
    if err != nil {
        log.Println(err)
        return false, err
    }
    _, err = rows.Exec(roomNo.Room_type_id, roomNo.Room_no)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}