package models

import (
    "log"
    "github.com/jmoiron/sqlx"
    "database/sql"
)

type Bed struct {
    Bed_id int32
    Room_type_id int64
    Bed_type string
    Quantity int64
}

type BedModel struct {
    DB * sqlx.DB
}

func(data BedModel) InsertBed(tx * sql.Tx, bed Bed)(bool, error) {
    rows, err := tx.Prepare("INSERT INTO bed (room_type_id, bed_type, quantity) VALUES(?,?,?)")
    if err != nil {
       log.Println(err)
        return false, err
    }
    _, err = rows.Exec(bed.Room_type_id, bed.Bed_type, bed.Quantity)
    if err != nil {
        log.Println(err)
        return false, err
    }
    return true, nil
}