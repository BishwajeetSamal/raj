## *Who* is the bug affecting?
<!-- Ex. All supervisors, Sally Supervisor, Level 1 CCs -->

## *What* is affected by this bug?
<!-- Ex. supervision, sending messages, texter profiles -->

## *When* does this occur?
<!-- Ex. After ending a conversation, every night at 3pm, when I sign off -->

## *Where* on the platform does it happen?
<!-- Ex. In the a Supervisor chat box, on the conversation profile page, on the two-factor screen -->


## *How* do we replicate the issue?
<!-- Please be specific as possible. Use dashes (-) or numbers (1.) to create a list of steps -->


## Expected behavior (i.e. solution)
<!-- What should have happened? -->


## Other Comments
