from fbs_runtime.application_context.PySide2 import ApplicationContext
import sys

from PySide2 import QtXml
from PySide2 import QtUiTools

from PySide2.QtCore import QObject, Signal, Property, QUrl, QStringListModel, QAbstractListModel, Qt, QCoreApplication,QModelIndex,Slot
from PySide2.QtGui import QGuiApplication
from PySide2.QtQml import QQmlApplicationEngine,QQmlComponent
import subprocess, time, os
#import pyautogui
import requests
#import configparser
import uuid
from datetime import datetime
terminalPath = ''
import backend
#import platform
import os
from multiprocessing.pool import ThreadPool
pool = ThreadPool(processes=3)

# filePath= backend.get_config_path()
config_path1 = pool.apply_async(backend.get_config_path, ()) # tuple of args for foo
filePath = config_path1.get()

# COMMANDS = backend.CommandListController()
COMMANDS1 = pool.apply_async(backend.CommandListController, ()) # tuple of args for foo
COMMANDS = COMMANDS1.get()

system1 = pool.apply_async(backend.systemName, ()) # tuple of args for foo
systemName = system1.get()

terminalList2d =[]
def fileWrite(textWrite):
    try:    
        global filePath
        print('textWrite on config file : ',textWrite)
        f= open(filePath,"w+")
        f.write(textWrite)
        f.close()
    except:
        pass
    return True

def fileCheck():
    global filePath
    try:
        f= open(filePath,"r")
        content = f.read()
        statusVal= content.split("|")
        if statusVal[1] == None:
            statusVal.insert(1,'')
        # print(value_file)
    except:
        statusVal=('','')
    print('fileReadResponce : ',statusVal)
    return statusVal

# def resource_path(relative_path):
#     """Returns the path of where to find a file, both when and when it
#     isn't compiled, given a relative path
#     """
#     try:
#         # PyInstaller creates a temp folder and stores path in _MEIPASS
#         base_path = sys._MEIPASS
#     except Exception:
#         base_path = os.path.abspath(".")

#     return os.path.join(base_path, relative_path)

i=0
TERMINAL = None

def attachedToTerminal():
    
    global TERMINAL
    global terminalPath
    global systemName
    try:
        if systemName == "Windows":
            system1 = pool.apply_async(backend.WindowsTerminal, (0,terminalPath)) # tuple of args for foo
            TERMINAL = system1.get()
        elif systemName == "Darwin":
            system1 = pool.apply_async(backend.MacTerminal, (0,terminalPath)) # tuple of args for foo
            TERMINAL = system1.get()
            #TERMINAL = backend.MacTerminal()
        else:
            warngin_massage("open","Unknown OS system")
        closeTer()
    except RuntimeError:
        warngin_massage("open","No terminals could be found")
    except IndexError:
        # backend.add_to_terminalfile("/usr/bin/xfce4-terminal")
        '''need to add executable terminal path '''
        warngin_massage("open","No terminals could be found")
    except Exception as e:
        print(e)
        print('UnKnown Error...')

class Data(object):
    def __init__(self, test_one=''):
        self._test_one = test_one
    
    def test_one(self):
        return self._test_one

class Model(QAbstractListModel):

    test_oneRole = Qt.UserRole + 1
    _roles = {test_oneRole: b"test_one"}

    def __init__(self, parent=None):
        QAbstractListModel.__init__(self, parent)

        self._datas = []

    def addData(self, data):
        self.beginInsertRows(QModelIndex(), self.rowCount(), self.rowCount())
        self._datas.append(data)
        self.endInsertRows()

    def rowCount(self, parent=QModelIndex()):
        return len(self._datas)

    def data(self, index, role=Qt.DisplayRole):
        try:
            data = self._datas[index.row()]
        except IndexError:
            return QVariant()

        if role == self.test_oneRole:
            return data.test_one()

        return QVariant()

    def roleNames(self):
        return self._roles

    def removeData(self, row):
        self.beginRemoveRows(QModelIndex(), self.rowCount(), self.rowCount())
        # del self._datas[row]
        self._datas.pop(row)
        self.endRemoveRows()
        return True
    
    @Slot(int)
    def removeData(self, index: int) -> None:
        self.beginRemoveRows(QModelIndex(), index, index)
        del self._datas[index]
        self.endRemoveRows()

class ModelTerminal(QAbstractListModel):

    test_oneRole = Qt.UserRole + 1
    _roles = {test_oneRole: b"test_two"}

    def __init__(self, parent=None):
        QAbstractListModel.__init__(self, parent)

        self._datas = []

    def addData(self, data):
        self.beginInsertRows(QModelIndex(), self.rowCount(), self.rowCount())
        self._datas.append(data)
        self.endInsertRows()

    def rowCount(self, parent=QModelIndex()):
        return len(self._datas)

    def data(self, index, role=Qt.DisplayRole):
        try:
            data = self._datas[index.row()]
        except IndexError:
            return QVariant()

        if role == self.test_oneRole:
            return data.test_one()

        return QVariant()

    def roleNames(self):
        return self._roles

            
class TerminalRun(QObject):
    # Slot for command text
    @Slot(int, result=str)
    def runterminal(self, termialRun):
        try :
            global systemName
            terminalName =terminalList2d[termialRun][1]
            global terminalPath
            terminalPath = terminalName
            if systemName == "Darwin":
                subprocess.Popen(['open', '-a', terminalName])
            attachedToTerminal()
            # async_result = pool.apply_async(attachedToTerminal, ()) # tuple of args for foo
            # return_val = async_result.get()
        except AttributeError:
            warngin_massage("open","atteched to terminal error")
        
        ''' wmctrl run command end'''
        return True
    
            
class ExecuteCommand(QObject):
    # Slot for command text
    @Slot(str, result=str)
    def command(self, command_text):
        ''' start subprocess means New terminal open and execute command
        # Windows
        #subprocess.call('start /wait echo "ABC"', shell=True)
        # Linux
        cmd = subprocess.call(["xfce4-terminal"])
        time.sleep(0.3)
        pyautogui.typewrite(command_text)   #TypeText on Terminal
        pyautogui.hotkey("enter")   # same as Keyboard Enter
        '''
        ''' wmctrl run command start'''
        # write on file
        # COMMANDS.add_command('ls')
        # backend.write_credentials('ls')

        # run on Last Opend Terminal or Default terminal
        global TERMINAL
        try :
            # flag change thread
             TERMINAL.send_command(command_text)
            # print('get Excute command',command_text)
            #async_result = pool.apply_async(TERMINAL.send_command, ([command_text])) # tuple of args for foo
            # return_val = async_result.get()

        except AttributeError:
            warngin_massage("open","No terminals could be found")
        
        ''' wmctrl run command end'''
        return command_text
    
    @Slot(int,str, result=str)   
    def delcommand(self,command_index,command_text):
        try :
            delete_command1 = pool.apply_async(COMMANDS.delete_command, ([command_text])) # tuple of args for foo
            return_val = delete_command1.get()
            # model = Model()  Object of removeData
            if return_val == True:
                model.removeData(int(command_index))
                warngin_massage("open","Command, Successfully remove...")
            else:
                warngin_massage("open","Cannot remove command...")
        except :
            warngin_massage("open","Please try again later")

'''
if userType free Return value 'free'
from licence users licence Expire then return value 'free' otherwise 'licence'
'licence' user Input/View/Operate unlimited Command, but 'free' user Input/View/Operate Five Command 
'''

Url_api ='http://18.212.33.109/mul8r/checklicence.php'

def checkUserValidation(userType,licence): 
    if userType == "licence":
        ''' Licence user Need to verify Inputied value of Licence '''
        try:
            # defining the api-endpoint
            API_ENDPOINT = Url_api
            # data to be sent
            HardwareId = hex(uuid.getnode())
            data = {"accessType":"licence","licenceKey":licence,"hardwareid":HardwareId}  
            # sending post request and saving response as response object 
            r = requests.post(url = API_ENDPOINT, data = data) 
            data = r.json() 
            print(data["status"])
            # extracting latitude, longitude and formatted address  
            # of the first matching location 
            if data["status"] == "success":
                ''' licence write on file '''
                textWrite= "licence|"+licence.strip()
                # flag change thread
                # # fileWrite(fileWrite)
                fileWrite1 = pool.apply_async(fileWrite, ([textWrite])) # tuple of args for foo
                # return_val = fileWrite1.get()
            
                '''reak flag FileWrite'''

                statusReturn = ["access"]
            else:
                statusReturn = ["unaccess"]
                
                # extracting response text  
                # pastebin_url = r.text 
                # print("The pastebin URL is:%s"%pastebin_url) 
        except:
            statusReturn = ["unaccess"]

    elif userType == "trial":
        try:
            ''' Trial user Need to verify The System Unique Id valid only first 30 Days Second Time Not Allowed '''
            # flog System Unique id
            API_ENDPOINT = Url_api
            # printing the value of unique MAC 
            # 0xf44d30485295L
            # address using uuid and getnode() function  
            HardwareId = hex(uuid.getnode())
            print("HardwareId",HardwareId)
            data = {"accessType":"trial","hardwareid":HardwareId} 
            r = requests.post(url = API_ENDPOINT, data = data) 
            data = r.json() 
            print("responce ",data["status"])
            if data["status"] == "success":
                ''' trial write on file '''
                textWrite= "trial|"+HardwareId.strip()

                # fileWrite(textWrite)
                fileWrite1 = pool.apply_async(fileWrite, ([textWrite])) # tuple of args for foo

                '''reak flag FileWrite'''

                expire_date = data["expire"]
                statusReturn = ["access",expire_date]
            else:
                expire_date = data["expire"]
                statusReturn = ["unaccess",expire_date]
            # try:
                
            # except:
            #     statusReturn = "unaccess"
        except:
            statusReturn = ["unaccess"]    
    else:
        statusReturn = ["unaccess"]
    
    print(userType,statusReturn)
    return statusReturn

if __name__ == '__main__':
    # check user validation free/licence
    appctxt = ApplicationContext()       # 1. Instantiate ApplicationContext
    fileCheck1 = pool.apply_async(fileCheck, ()) # tuple of args for foo
    value_file = fileCheck1.get() 
    user_val = value_file[0].strip()
    licence_val = value_file[1].strip()
    # userAccessType = checkUserValidation(user_val,licence_val)
    userAccessType1 = pool.apply_async(checkUserValidation, (user_val,licence_val)) # thread use auth.
    userAccessType = userAccessType1.get() 
    # userAccessType =['access']

    QCoreApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    # app = QGuiApplication(sys.argv)
    engine = QQmlApplicationEngine()

    model = Model()
    termiallist = ModelTerminal()
    # add data
    commandList1 = pool.apply_async(COMMANDS.commands.keys, ()) # tuple of args for foo
    commandList = commandList1.get()

    for cmd in list(commandList):
        model.addData(Data(cmd))

    terminalList1 = pool.apply_async(backend.read_terminal_file, ()) # tuple of args for foo
    terminalList = terminalList1.get()

    for terminallst in list(terminalList):
        print(terminallst)
        if os.path.exists(terminallst):
            tList= terminallst.split('/')
            tttt= [tList[-1],terminallst]
            terminalList2d.append(tttt)
            termiallist.addData(Data(tList[-1]))
    
    context = engine.rootContext()
    context.setContextProperty('myModel', model)
    context.setContextProperty('myModelterminal', termiallist)
    
    # Create a excuteCommand object
    executeCommand = ExecuteCommand()
    terminalRun = TerminalRun()
    # And register it in the context of QML
    engine.rootContext().setContextProperty("executeCommand", executeCommand)
    engine.rootContext().setContextProperty("terminalRun", terminalRun)
   
    ''' Qml file description '''
    qmlFIlePath = appctxt.get_resource('test.qml')
    engine.load(QUrl.fromLocalFile(qmlFIlePath))

    ''' Qml Action Trigger function '''
    win = engine.rootObjects()[0]
    dir_path = os.path.dirname(os.path.realpath(__file__))

    # ''' Header Footer Image Set '''
    headerImage = win.findChild(QObject, "headerImage")
    headerImagePath = QUrl.fromLocalFile(os.path.join(dir_path, appctxt.get_resource('MUL8R.svg')))
    headerImage.setProperty("source", headerImagePath)

    button = win.findChild(QObject, "myButton")
    areaOfEvent = win.findChild(QObject, "areaOfEvent")
    foo = win.findChild(QObject, "input_licence")
    button_licence = win.findChild(QObject, "btn_licence")
    button_trial = win.findChild(QObject, "btn_trial")
    authorization = win.findChild(QObject, "authorization")
    box1 = win.findChild(QObject, "box1")
    box2 = win.findChild(QObject, "box2")
    box3 = win.findChild(QObject, "box3")
    purchase = win.findChild(QObject, "purchase")
    
    
    #button_attachedToTerminal = win.findChild(QObject, "attachedToTerminal")

    msg_user=  win.findChild(QObject, "message_user")
    authorization_msg =  win.findChild(QObject, "authorization_msg")
    message_error =  win.findChild(QObject, "message_error")

    def actionOnAuthorization(userAccessType,user_val):
        if userAccessType[0] !="unaccess":
            areaOfEvent.setProperty("visible","true")
            authorization.setProperty("visible","false")
            if user_val == "trial":
                date_format = "%Y/%m/%d"
                b = datetime.strptime(userAccessType[1], date_format)
                a = datetime.today()
                remianing_day =  ((b - a).days)+1 # that's it
                if remianing_day >= 0:
                    msg = "Free Trial remaining " + str(remianing_day )+ ' days.'
                    msg_user.setProperty("text",msg)
                else:
                    areaOfEvent.setProperty("visible","false")
                    authorization.setProperty("visible","true")
                    authorization_msg.setProperty("text","Warning:\n Your Trial expired on "+userAccessType[1] +",\n Please activate licence.")
                # msg_user.setProperty("horizontalAlignment","AlignRight")
                # message_error.setProperty("horizontalAlignment","AlignRight")
            else:
                msg = "Licenced ( Paid Version )"
                msg_user.setProperty("text",msg)
                purchase.setProperty("visible","false")

            '''access '''
        else:
            '''un access '''
            if user_val == "trial":
                areaOfEvent.setProperty("visible","false")
                authorization.setProperty("visible","true")
                print('-------')
                print(userAccessType)
                try :
                    authorization_msg.setProperty("text","Warning:\n Your Trial expired on "+userAccessType[1] +",\n Please activate licence.")
                except:
                    authorization_msg.setProperty("text","Warning:\n Your Trial expired on ")
                
                # msg_user.setProperty("text","Activate licence")
            if user_val == "licence":
                areaOfEvent.setProperty("visible","false")
                authorization.setProperty("visible","true")
                authorization_msg.setProperty("text","Warning:\n Your Licence expired,\n Please activate licence.")
                # msg_user.setProperty("text","Activate licence")
            
    
    def warngin_massage(open,text):
        if open == "open":
            message_error.setProperty("text",text)
            message_error.setProperty("visible","true")
            msg_user.setProperty("visible","false")
        else:
            message_error.setProperty("text","")
            message_error.setProperty("visible","false")
            msg_user.setProperty("visible","true")

        # msg_user.setProperty("text","Activate licence")
    
    if(len(terminalList2d)< 1):
        warngin_massage("open","No terminals could be found")
       
    
    actionOnAuthorization(userAccessType,user_val)

    if user_val == "licence":
        foo.setProperty("text",licence_val)

    '''Function Start '''
    def myFunction():
        # print("handler called")
        cmdInput = win.findChild(QObject, "cmd_input")
        new_cmd = cmdInput.property("text")
        new_cmd = new_cmd.strip()
        # check if command already exist in list then not insert 
        if new_cmd in list(COMMANDS.commands.keys()):
            print("\u2717 " ,new_cmd,' >>> ')
            warngin_massage("open","That command is already added")
        elif new_cmd=='':
            warngin_massage("open","Please enter value...")
        else:
            COMMANDS.add_command(new_cmd)
            model.addData(Data(new_cmd))
            print("\u2713" ,new_cmd,' >>> ')
            cmdInput.setProperty('text','')
            warngin_massage("close","")
        
    def myFunction_licence():
        print("Licence called")
        # foo = win.findChild(QObject, "input_licence")
        licence_val = foo.property("text")
        licence_val = licence_val.strip()
        if licence_val=='':
            print("\u2717 " ,licence_val,'input empty')
            warngin_massage("open","Please enter value...")
        else:
            # message = checkUserValidation("licence",licence_val)
            message1 = pool.apply_async(checkUserValidation, ("licence",licence_val)) # tuple of args for foo
            message = message1.get() 
            # actionOnAuthorization(message,'licence')
            userAccessType2 = pool.apply_async(actionOnAuthorization, (message,'licence')) # tuple of args for foo
            userAccessType3 = userAccessType2.get() 
            warngin_massage("close","")
            
    def myFunction_trial():
        print("trial called")
        # message =  checkUserValidation("trial","")
        message1 = pool.apply_async(checkUserValidation, ("trial",'')) # tuple of args for foo
        message = message1.get() 
        userAccessType2 = pool.apply_async(actionOnAuthorization, (message,'trial')) # tuple of args for foo
        userAccessType3 = userAccessType2.get()
        warngin_massage("close","") 
    
    
    def closeTer():
       box1.setProperty('visible','false')
       box2.setProperty('visible','true')
       return True                 
    '''Function End'''      

    button.clicked.connect(myFunction)
    button_licence.clicked.connect(myFunction_licence)
    button_trial.clicked.connect(myFunction_trial)
    win.show()

    # engine.quit.connect(app.quit)

exit_code = appctxt.app.exec_()      # 2. Invoke appctxt.app.exec_()
sys.exit(exit_code)
