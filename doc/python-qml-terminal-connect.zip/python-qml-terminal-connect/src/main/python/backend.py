import os
import json
import time

# from pynput.mouse import Listener
#import threading
import subprocess
import platform
import pyautogui
# import utils
import time
#import keyboard
import Quartz
#import pyobjc  dependency of pyautogui in macos

SYSTEM = platform.system()
def systemName():
    pyautogui.press('ctrl');
    return SYSTEM

if SYSTEM not in ["Windows", "Linux", "Darwin"]:
    raise Exception("Unsupported OS")

if SYSTEM == "Windows":
    import win32gui
    import win32process
    import win32api
    import wmi

    from pywinauto import application
    import pywinauto

    C = wmi.WMI()

    class WindowsTerminal:
        def __init__(self, handle = None, path = None):
            """Class for interfacing with a terminal in the windows operating system.
            Internal class only, use Terminal in the application. There are two ways
            of joining to a terminal, either launching the application here or joining
            to one which already exists. If you specify a handle (hwnd), it will 
            join to a window with that hwnd. If you specify a path (full path
            of exectuable) it will start it and join to it.
            
            Keyword Arguments:
                handle {str} -- hwnd to join to should be a base 16 int as a string (default: {None})
                path {str} -- Full path to an executable which will be started (default: {None})
            
            Raises:
                TypeError: Thrown if the dev didn't give exactly one argument. 
            """
            self.path = path
            # if (handle is None and path is None) or (handle is not None and path is not None):
            #     raise TypeError("Exactly one of either handle and path should be specified")
            
            #TODO: work out why it says 'not registed' when using inheritance
            
            self.app = application.Application()

            if path is not None:
                self.app.start(path, create_new_console=True, wait_for_idle=False)
                title = path
            else:
                raise RuntimeError('Exactly one path should be specified')

            # if handle is not None:
            #     handle = int(handle, base = 16)
            #     self.app.connect(handle = handle)
            #     title = win32gui.GetWindowText(handle)

            self.window = self.app.window(best_match = title)

        def focus(self):
            self.window.set_focus()

        def send_command(self, command):
            self.focus()
            time.sleep(0.1)
            pyautogui.typewrite(command)
            pyautogui.press("return")
            #keyboard.write("GEEKS FOR GEEKS\n") 


elif SYSTEM == "Darwin":
    # import Quartz
    class MacTerminal:
        def __init__(self, pid = None, path = None):
            """Class for interfacing with a MacTerminal, in the application, use
            Terminal which uses this class to work with all OSs. Joins to a terminal,
            creating it if it isn't open. Can be joined using a pid, or a fill
            exec path. Suggest using path, since it's faster because it doesn't
            have to find the path.
            
            Keyword Arguments:
                pid {str} -- Process ID to join to (default: {None})
                path {str} -- Full path to application to start (default: {None})
            
            Raises:
                TypeError: Thrown if the dev didn't give exactly two args
            """
            '''
            if (pid is None and path is None) or (pid is not None and path is not None):
                raise TypeError("Exactly one of either pid and path should be specified")
            '''
            '''
            if pid is not None:
                self.path = self._get_path(pid)
            else:
                self.path = path

            '''
            self.path = path
            pyautogui.press("return")

        def _get_path(self, pid):
            global terminalPath
            print(terminalPath)
            return terminalPath
            # for i in get_windows():
            #     if i[1] == str(pid):
            #         return i[3]

        def focus(self):
            subprocess.Popen(['open', '-a', self.path])

        def send_command(self, command):
            self.focus()
            time.sleep(0.3)
            pyautogui.typewrite(command)
            pyautogui.press("return")
            #keyboard.write(command+"\n")
            # flag
            print('Command inp: ',command)

else:
    class LinuxTerminal:
        def __init__(self, handle):
            """Class for communicating with a Linux Terminal, given a handle.
            Cannot start the application.
            
            Arguments:
                handle {str} -- handle to join to
            """
            self.handle = handle
        
        def _get_title(self):
            for i in get_windows():
                if i[0] == str(self.handle):
                    return i[2]
            raise RuntimeError("The target terminal was closed")

        def focus(self):
            subprocess.Popen(["wmctrl", "-R", self._get_title()])

        def send_command(self, command):
            self.focus()
            time.sleep(0.1)
            #pyautogui.typewrite("run")
            pyautogui.typewrite(command)
            pyautogui.press("return")

def get_windows():
    """
    Platfrom independant way of getting data about all the open windows
    Returns hwnd (None in MacOS), pid, window title and full exectuable path

    Returns:
        list -- List of lists in the format [[hwnd, pid, title, executable], ...]
    """ 
    out = []
    if SYSTEM == "Linux":
        result = subprocess.run(["wmctrl", "-p", "-l"], stdout = subprocess.PIPE)
        windows = result.stdout.decode("UTF-8").split("\n")[:-1]
        for i in windows:
            s = i.split()
            pid = s[2]
            out.append([s[0], pid, " ".join(s[4:]), get_exec_path_unix(pid)])

    elif SYSTEM == "Windows":
        for hwnd in pywinauto.findwindows.enum_windows():
            if win32gui.IsWindowVisible(hwnd):
                left, top, right, bottom = win32gui.GetWindowRect(hwnd)
                window_title = win32gui.GetWindowText(hwnd)
                if window_title and right-left and bottom-top:
                    pid = win32process.GetWindowThreadProcessId(hwnd)[1]
                    out.append([hex(hwnd), pid, window_title, get_exec_path_win(pid)])

    elif SYSTEM == "Darwin":
        return None
        #https://stackoverflow.com/questions/42018149/get-pids-of-all-open-windows-on-macos
        #cmd = r'''
# osascript -e "tell application \"System Events\" 
#     repeat with proc in (processes where background only is false)
#         set pname to name of proc
#         log pname
#     end repeat
# end tell" 2>&1 |
# while read line
# do
#     echo "process " $line
#     pgrep $line
# done'''
#         result = subprocess.run([cmd], stdout = subprocess.PIPE, shell = True)
#         result = result.stdout.decode('UTF-8').split('\n')

#         out = []
#         for n, i in enumerate(result, 0):
#             if n < len(result) - 1:
#                 pid = result[n + 1]
#             if i.startswith('process') and pid.isdigit():
#                 out.append([None, pid, i.replace('process  ', ''), get_exec_path_unix(pid)])

#     return out
        

def get_exec_path_win(pid):
    #https://stackoverflow.com/questions/14394513/win32gui-get-the-current-active-application-name
    """Returns the full path to an executable given a pid in windows
    
    Returns:
        str -- Path to executable
    """
    try:
        for p in C.query('SELECT ExecutablePath FROM Win32_Process WHERE ProcessId = %s' % pid):
            exe = p.ExecutablePath
            break
    except Exception as e:
        print("[ERROR] %s" % e)
        return None
    else:
        return exe

def get_exec_path_unix(pid):
    """Returns the full path to an execuable in UNIX (both Linux and MacOS) given
    a process id (PID)

    Returns:
        str -- Path to execuable
    """
    cmd = ["ps awx | awk '$1 == %s { print $5 }'" % pid]
    result = subprocess.run(cmd, stdout = subprocess.PIPE, shell = True)
    return result.stdout.decode("UTF-8").replace("\n", "")

# def get_credentials_path():
#     if SYSTEM == "Windows":
#         if not os.path.exists(os.path.join(os.getenv("APPDATA"), "MUL8R")):
#             os.mkdir(os.path.join(os.getenv("APPDATA"), "MUL8R"))

#         return os.path.join(os.getenv("APPDATA"), "MUL8R", "credentials.json")
#     else:
#         if not os.path.exists(os.path.join(os.path.expanduser('~'), ".mul8r")):
#             os.mkdir(os.path.join(os.path.expanduser('~'), ".mul8r"))
#         return os.path.join(os.path.expanduser('~'), ".mul8r", "credentials.json")

def get_config_path():
    if SYSTEM == "Windows":
        if not os.path.exists(os.path.join(os.getenv('APPDATA'), 'mul8r')):
            os.makedirs(os.path.join(os.getenv('APPDATA'), 'mul8r'))
        file = os.path.join(os.getenv('APPDATA'), 'mul8r', 'config.txt')
        return file
    else:
        if not os.path.exists(os.path.join(os.path.expanduser('~'), ".mul8r")):
            os.mkdir(os.path.join(os.path.expanduser('~'), ".mul8r"))
        file = os.path.join(os.path.expanduser('~'), ".mul8r", "config.txt")
        return file

# def check_credentials(show_errors = False):
#     path = get_credentials_path()
#     if os.path.exists(path):
#         try:
#             with open(path, "r") as f:
#                 key = json.load(f)
#                 keycheck = utils.register(key)
#                 if keycheck == True and type(keycheck) is bool:
#                     return True
#                 if show_errors:
#                     return keycheck
#                 else:
#                     return False
#         except:
#             return False
#     else:
#         return False

# def write_credentials(key):
#     try :
#         path = get_credentials_path()

#         if os.path.exists(path):
#             os.remove(path)

#         with open(path, "w") as f:
#             json.dump(key, f)
#     except:
#         pass

def get_terminalfile_path():
    """Returns the path of the file containing terminal paths in
    all operating systems. If it doesn't exist, it automatically
    creates it. 

    Returns:
        str -- Path to terminals.json file
    """
    # flag
    def write_default_data(path):
        try:
            default_data = {"Windows":[
                "C:\\WINDOWS\\system32\\cmd.exe",
                "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            ], "Linux":["/usr/lib/gnome-terminal/gnome-terminal-server","/usr/bin/xfce4-terminal","/usr/bin/x-terminal-emulator","/usr/bin/tilix"], "Darwin":[
                "/Applications/iTerm.app/Contents/MacOS/iTerm2",
                "/Applications/Utilities/Terminal.app/Contents/MacOS/Terminal",
                "/Applications/Upterm.app/Contents/MacOS/Upterm",
            ]}
            with open(path, "w") as file:
                json.dump(default_data, file)
        except:
            pass

    if SYSTEM == "Windows":
        if not os.path.exists(os.path.join(os.getenv('APPDATA'), 'mul8r')):
            os.makedirs(os.path.join(os.getenv('APPDATA'), 'mul8r'))

        file = os.path.join(os.getenv('APPDATA'), 'mul8r', 'terminal.json')

        if not os.path.exists(file):
            write_default_data(file)

    else:
        if not os.path.exists(os.path.join(os.path.expanduser('~'), ".mul8r")):
            os.mkdir(os.path.join(os.path.expanduser('~'), ".mul8r"))
        file = os.path.join(os.path.expanduser('~'), ".mul8r", "terminal.json")
        if not os.path.exists(file):
            write_default_data(file)

    return file

# def add_to_terminalfile(new):
#     try:    
#         """Appends a terminal path to the file of terminals. If the file
#         doesn't exist, it is automatically created.

#         Arguments:
#             new {str} -- the path to the exectuable of a terminal app
#         """
#         path = get_terminalfile_path()
#         with open(path, "r") as file:
#             curdata = json.load(file)

#         curdata[SYSTEM].append(new)

#         with open(path, "w") as file:
#             json.dump(curdata, file)
#     except:
#         pass

def read_terminal_file():
    try:
        """Returns the terminals in the terminalfile
        corrisponding with the current operating system
        
        Returns:
            list -- List of paths in the terminal
        """
        path = get_terminalfile_path()
        
        with open(path, "r") as file:
            return json.load(file)[SYSTEM]
    except:
        pass

# def delete_terminal_from_file(terminal):
#     try:
#         """Deletes a terminal path from the file, with the
#         current operating system.
        
#         Arguments:
#             terminal {str} -- Path to terminal to remove
#         """
#         terminals = read_terminal_file()
#         terminals.remove(terminal)

#         path = get_terminalfile_path()
#         with open(path, "r") as file:
#             wholefile = json.load(file)

#         wholefile[SYSTEM] = terminals
#         with open(path, "w") as file:
#             json.dump(wholefile, file)
#     except:
#         pass
# '''
# class Terminal:
#     path = None
#     def __init__(self, path = None):
#         """Class for communicating with terminal windows in Windows, MacOS, and Linux.
#         If a path is specified as a path to an executable of a terminal program, open
#         the terminal and do commands in this terminal (not avaliable in Linux). Otherwise,
#         try to find a terminal application. Raises RunTime errors if no terminals, or if
#         more than one terminal is found. We know if a window is a terminal application
#         if it's path is in terminal.txt. This is not a comprehensive list, so we can get
#         the user to add to it, or use one of the above functions to do it in the GUI. If
#         the app can't find the file, it's created with a few suggestions. It's stored in
#         the same location as the app in Linux and MacOS, and in %APPDATA%/mul8r in windows
#         (same place as the commands file).
        
#         Keyword Arguments:
#             path {str} -- Path to an executable (optional) to open (default: {None})
        
#         Raises:
#             NotImplementedError: Thrown if the dev tries to use the path arg in Linux
#         """
#         if path is None:
#             terminals = self.get_open_terminals()
#             # flag remove print
#             print('terminals(-1): ',terminals)
#             self.path = terminals[-1]
#             if SYSTEM == "Linux":
#                 '''  Terminal '''
#                 self.terminal = LinuxTerminal(terminals[0])
                
#             elif SYSTEM == "Darwin":
#                 self.terminal = MacTerminal(path = terminals[-1])
#             elif SYSTEM == "Windows":
#                 self.terminal = WindowsTerminal(handle = terminals[0])
#         else:
#             self.path = path
#             if SYSTEM == "Linux":
#                 '''user excutive path and enter then run terminal '''
#                 raise NotImplementedError("Cannot open terminals in Linux")
#             elif SYSTEM == "Darwin":
#                 self.terminal = MacTerminal(path = path)
#             elif SYSTEM == "Windows":
#                 self.terminal = WindowsTerminal(path = path)

#     def get_open_terminals(self):
#         """Returns the open terminal window data
        
#         Raises:
#             RuntimeError: Thrown if the program couldn't find any terminal windows
#             RuntimeError: Thrown if the application found more than one terminal window
        
#         Returns:
#             list -- list of data about the active terminal window
#         """
#         out = []
#         terminals = get_windows()
#         # print("Treminal ", terminals)
#         for i in reversed(terminals):
#             if i[-1] in read_terminal_file():
#                 out.append(i)

#         # flag 0 set
#         if len(out) == 0:
#             raise RuntimeError("No terminals could be found")
#         # if len(out) > 1:
#         #     raise RuntimeError("More than one terminal was found")
#         return out[0]


#     def focus(self):
#         """Bring the terminal window to the front of the screen
#         """
#         self.terminal.focus()

#     def send_command(self, command):
#         """Send a command to the terminal window. Automatically focuses and presses return.
        
#         Arguments:
#             command {str} -- command to send
#         """
#         self.terminal.send_command(command)
# '''

class CommandListController:
    def __init__(self):
        if SYSTEM == "Windows":
            if not os.path.exists(os.path.join(os.getenv('APPDATA'), 'mul8r')):
                os.makedirs(os.path.join(os.getenv('APPDATA'), 'mul8r'))

            self.FILENAME = os.path.join(os.getenv('APPDATA'), 'mul8r', 'command_list.dat')

        else:
            if not os.path.exists(os.path.join(os.path.expanduser('~'), ".mul8r")):
                os.mkdir(os.path.join(os.path.expanduser('~'), ".mul8r"))
            self.FILENAME = os.path.join(os.path.expanduser('~'), ".mul8r", "command_list.dat")
            print('FILENAME',self.FILENAME)

        self.commands = {}
        self.recent_commands = []
        self.load_commands()

    def save(self):
        try:
            with open(self.FILENAME, 'w') as f:
                json.dump(self.commands, f)
        except:
            pass

    def load_commands(self):
        if os.path.isfile(self.FILENAME):
            try:    
                with open(self.FILENAME, 'r') as f:
                    self.commands = json.load(f)
                self.compute_recent_commands()
            except:
                pass

    def add_command(self, command):
        if command not in self.commands:
            self.commands[command] = []
        self.save()

    def delete_command(self, command):
        if command in self.commands:
            del self.commands[command]
            # self.compute_recent_commands()
        self.save()
        return True

    # def use_command(self, command):
    #     self.commands[command].append(time.time())
    #     self.compute_recent_commands()
    #     self.save()

    # def compute_recent_commands(self):
    #     self.recent_commands = [
    #         command
    #         for command, uses in sorted(
    #             self.commands.items(),
    #             key=lambda item: len(item[1]),
    #             reverse=True
    #         )
    #         if uses
    #     ][:10]
