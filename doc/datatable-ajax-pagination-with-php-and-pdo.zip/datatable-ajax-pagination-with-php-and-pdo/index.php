<!doctype html>
<html>

<head>
    <title>Datatable AJAX pagination with PHP and PDO</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
</head>

<body>
    <h3>Pagination with server side</h3>
    <div>
        <!-- Table -->
        <table id='empTable' class='display dataTable'>
            <thead>
                <tr>
                    <th>Avatar</th>
                    <th>Employee name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Salary</th>
                    <th>City</th>
                </tr>
            </thead>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <!-- Script -->
    <script>
        $(document).ready(function() {
            $('#empTable').DataTable({
                'processing': true,
                'serverSide': true,
                // 'serverMethod': 'post',
                'ajax': {
                    'url': 'ajaxfile.php'
                },
                'columns': [{
                        data: null,
                        "render": function(data, type, row) {
                            if (type === 'display') {
                                data = (data['gender'] == "female") ? ("<b style='background-color: blue;padding: 5px 10px;color: white;border-radius: 50%;font-family: monospace;'>"+data['name'][0]+"</b>" ): ("<b style='background-color: gray;padding: 5px 10px;color: white;border-radius: 50%; font-family: monospace;'>" + data['name'][0]+"</b>");
                            }
                            return data;
                        }
                    },
                    {
                        data: 'name'
                    },
                    {
                        data: null,
                        "render": function(data, type, row) {
                            if (type === 'display') {
                                data = "<a href='mailto:"+data['email']+"'>Send mail</a>";
                            }
                            return data;
                        }
                    },
                    {
                        data: 'gender',
                    },
                    {
                        data: 'salary'
                    },
                    {
                        data: 'address'
                    },
                ]
            });
        });
    </script>
</body>

</html>